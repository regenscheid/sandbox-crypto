BEGIN TRANSACTION;
CREATE TABLE "annotation_body_revisions" (
    entry_id TEXT NOT NULL REFERENCES annotation_entries(entry_id),
    revision INTEGER NOT NULL CHECK (revision BETWEEN 1 AND 999999999),
    history_entry TEXT NOT NULL REFERENCES annotation_entries(entry_id),
    body TEXT NOT NULL CHECK (length(CAST(body AS BLOB)) <= 16384),
    sha256 TEXT NOT NULL CHECK (length(sha256) = 64 AND sha256 NOT GLOB '*[^0-9a-f]*'),
    block_map TEXT NOT NULL
        CHECK (json_valid(block_map) AND length(CAST(block_map AS BLOB)) <= 16777216),
    author TEXT NOT NULL
        CHECK (json_valid(author) AND length(CAST(author AS BLOB)) <= 8192),
    owners TEXT NOT NULL
        CHECK (json_valid(owners) AND length(CAST(owners AS BLOB)) <= 16777216),
    next_block INTEGER NOT NULL CHECK (next_block BETWEEN 0 AND 999999999),
    next_span INTEGER NOT NULL CHECK (next_span BETWEEN 0 AND 999999999),
    PRIMARY KEY(entry_id,revision)) STRICT;
INSERT INTO "annotation_body_revisions" VALUES('cmt-924da581199378bcff722140',1,'cmt-924da581199378bcff722140','$\F$','bc77b524efd01ebf2286358d6ca594b228ded4f097152d0bf63edc4a52c79f5f','{"profile":"ss-markdown-2","blocks":[{"id":"b1","kind":"paragraph","parent":null,"lines":[0,1],"start":0,"end":4,"hash":"bc77b524efd01ebf2286358d6ca594b228ded4f097152d0bf63edc4a52c79f5f","status":"added","structural":null,"attrs":{},"spans":[{"id":"m1","kind":"inline","hash":"366584274fbf870007b1f943904f3abeb1009ebf1c4e14e09051b64ed44a96d2","status":"added"}]}],"removed":[],"removed_spans":[],"identity_floor":1}','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}','{"b1":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}}}',1,1);
INSERT INTO "annotation_body_revisions" VALUES('cmt-c4fce9bb05f36a81283a26a4',1,'cmt-c4fce9bb05f36a81283a26a4','$\F + \unknown{c}$','496550ffe147968e6d256bea2d07983848a5de00c020023ea51db07418bbce42','{"profile":"ss-markdown-2","blocks":[{"id":"b1","kind":"paragraph","parent":null,"lines":[0,1],"start":0,"end":18,"hash":"496550ffe147968e6d256bea2d07983848a5de00c020023ea51db07418bbce42","status":"added","structural":null,"attrs":{},"spans":[{"id":"m1","kind":"inline","hash":"d024112b91f88d0b8e14150e7a9618bf818bf31cdd4d6e45c97b6e7a79bea019","status":"added"}]}],"removed":[],"removed_spans":[],"identity_floor":1}','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}','{"b1":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}}}',1,1);
CREATE TABLE "annotation_entries" (
    entry_id TEXT PRIMARY KEY CHECK (length(CAST(entry_id AS BLOB)) BETWEEN 1 AND 128),
    thread_id TEXT NOT NULL REFERENCES annotation_threads(thread_id),
    number INTEGER NOT NULL CHECK (number BETWEEN 1 AND 999999999),
    kind TEXT NOT NULL
        CHECK (kind IN ('create', 'reply', 'edit', 'edit_body', 'resolve', 'reopen')),
    author TEXT NOT NULL
        CHECK (json_valid(author) AND length(CAST(author AS BLOB)) <= 8192),
    body TEXT NOT NULL CHECK (length(CAST(body AS BLOB)) <= 16384),
    payload TEXT NOT NULL CHECK (json_valid(payload)),
    created_at REAL NOT NULL, UNIQUE(thread_id, number)) STRICT;
INSERT INTO "annotation_entries" VALUES('cmt-924da581199378bcff722140','ann-7ecabb131bf6508142c9bd97',1,'create','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}','$\F$','{}',1.79200988511655664e+09);
INSERT INTO "annotation_entries" VALUES('cmt-c4fce9bb05f36a81283a26a4','ann-cdceedd110afad4816ba61f0',1,'create','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}','$\F + \unknown{c}$','{}',1.79200988522843623e+09);
CREATE TABLE "annotation_operations" (
    project_id TEXT NOT NULL, actor TEXT NOT NULL, operation_id TEXT NOT NULL,
    fingerprint TEXT NOT NULL
        CHECK (length(fingerprint) = 64 AND fingerprint NOT GLOB '*[^0-9a-f]*'),
    result TEXT NOT NULL CHECK (json_valid(result)),
    PRIMARY KEY(project_id,actor,operation_id)) STRICT;
INSERT INTO "annotation_operations" VALUES('p','session:s','c1','696b1f2dc836699b9eac61671b935adc58f6bc4b23baf0bbb508af4802b8bbad','{"thread_id":"ann-7ecabb131bf6508142c9bd97","entry_id":"cmt-924da581199378bcff722140","revision":1,"request_id":null,"outcome":"create"}');
INSERT INTO "annotation_operations" VALUES('p','session:s','c2','46cb9a80e703a4f6decc63ac98fb69519f9fef869b477f3c9ba28be49b6fd60c','{"thread_id":"ann-cdceedd110afad4816ba61f0","entry_id":"cmt-c4fce9bb05f36a81283a26a4","revision":1,"request_id":null,"outcome":"create"}');
CREATE TABLE annotation_requests (
    request_id TEXT PRIMARY KEY, project_id TEXT NOT NULL, session_id TEXT NOT NULL,
    thread_id TEXT NOT NULL REFERENCES annotation_threads(thread_id),
    entry_id TEXT NOT NULL REFERENCES annotation_entries(entry_id), state TEXT NOT NULL,
    claimed_run TEXT, claim_until REAL, delivered_run TEXT, delivered_at REAL,
    responded_entry TEXT, UNIQUE(entry_id)) STRICT;
CREATE TABLE "annotation_threads" (
    thread_id TEXT PRIMARY KEY CHECK (length(CAST(thread_id AS BLOB)) BETWEEN 1 AND 128),
    document_id TEXT NOT NULL REFERENCES documents(document_id),
    anchor TEXT NOT NULL CHECK (json_valid(anchor)),
    opener TEXT NOT NULL
        CHECK (json_valid(opener) AND length(CAST(opener AS BLOB)) <= 8192),
    created_at REAL NOT NULL) STRICT;
INSERT INTO "annotation_threads" VALUES('ann-7ecabb131bf6508142c9bd97','doc-1e4f0c5c2e394387ce7165fe','{"revision":1,"block":"b1","math":null,"start":null,"end":null,"kind":"block","quote":"---\nmacros:\n  ''\\F'': ''document''\n---","quote_truncated":false,"sha256":"5ce5a23ecacec39c381690f0b85b13ae285ff7717f5d877b1b06e4de4c422211","block_sha256":"5ce5a23ecacec39c381690f0b85b13ae285ff7717f5d877b1b06e4de4c422211","before":"","after":""}','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',1.79200988511652517e+09);
INSERT INTO "annotation_threads" VALUES('ann-cdceedd110afad4816ba61f0','doc-6d5d225787c1ec2d34b50b21','{"revision":1,"block":"b1","math":null,"start":null,"end":null,"kind":"block","quote":"---\nmacros:\n  ''\\F'': ''first''\n---","quote_truncated":false,"sha256":"1696fec8d4d046330fd902447e84976d206880c1faf1fedeff4f296d04eb7334","block_sha256":"1696fec8d4d046330fd902447e84976d206880c1faf1fedeff4f296d04eb7334","before":"","after":""}','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',1.79200988522840952e+09);
CREATE TABLE "artifact_events" (
    seq INTEGER PRIMARY KEY AUTOINCREMENT, project TEXT NOT NULL,
    record TEXT NOT NULL
        CHECK (json_valid(record) AND length(CAST(record AS BLOB)) <= 16384)) STRICT;
CREATE TABLE "artifact_objects" (
    id TEXT PRIMARY KEY CHECK (length(CAST(id AS BLOB)) BETWEEN 1 AND 128),
    project TEXT NOT NULL, path TEXT NOT NULL,
    head INTEGER NOT NULL CHECK (head >= 0),
    UNIQUE(project,path)) STRICT;
CREATE TABLE "artifact_operations" (
    project TEXT NOT NULL, actor TEXT NOT NULL, operation TEXT NOT NULL,
    digest TEXT NOT NULL CHECK (length(digest) = 64 AND digest NOT GLOB '*[^0-9a-f]*'),
    request TEXT NOT NULL
        CHECK (json_valid(request) AND length(CAST(request AS BLOB)) <= 8192),
    state TEXT NOT NULL CHECK (state IN ('intent', 'transfer', 'done')),
    worker TEXT CHECK (worker IS NULL
        OR (json_valid(worker) AND length(CAST(worker AS BLOB)) <= 16384)),
    receipt TEXT CHECK (receipt IS NULL
        OR (json_valid(receipt) AND length(CAST(receipt AS BLOB)) <= 16384)),
    PRIMARY KEY(project,actor,operation)) STRICT;
CREATE TABLE artifact_revisions(
    artifact TEXT NOT NULL REFERENCES artifact_objects(id),number INTEGER NOT NULL,
    project TEXT NOT NULL,size INTEGER NOT NULL CHECK(size>=0),record TEXT NOT NULL,
    data BLOB NOT NULL,PRIMARY KEY(artifact,number)) STRICT;
CREATE TABLE "comment_math_sources" (
    entry_id TEXT PRIMARY KEY REFERENCES annotation_entries(entry_id),
    document TEXT NOT NULL REFERENCES documents(document_id),
    project TEXT NOT NULL CHECK (length(CAST(project AS BLOB)) BETWEEN 1 AND 128),
    target INTEGER NOT NULL CHECK (target BETWEEN 0 AND 999999999),
    completed INTEGER NOT NULL DEFAULT 0 CHECK (completed BETWEEN 0 AND 999999999),
    macro_revision INTEGER NOT NULL DEFAULT 0 CHECK (macro_revision BETWEEN 0 AND 999999999),
    retry_requested INTEGER NOT NULL DEFAULT 0 CHECK (retry_requested IN (0, 1)),
    blocked TEXT CHECK (blocked IS NULL OR length(CAST(blocked AS BLOB)) <= 4096)) STRICT;
INSERT INTO "comment_math_sources" VALUES('cmt-924da581199378bcff722140','doc-1e4f0c5c2e394387ce7165fe','p',1,1,1,1,NULL);
INSERT INTO "comment_math_sources" VALUES('cmt-c4fce9bb05f36a81283a26a4','doc-6d5d225787c1ec2d34b50b21','p',1,1,2,1,NULL);
CREATE TABLE document_macro_pins (
    document TEXT NOT NULL,revision INTEGER NOT NULL,project_revision INTEGER NOT NULL,
    PRIMARY KEY(document,revision),
    FOREIGN KEY(document,revision) REFERENCES revisions(document_id,number)) STRICT;
INSERT INTO "document_macro_pins" VALUES('doc-58b9197efd52aaaaf2628f77',1,1);
INSERT INTO "document_macro_pins" VALUES('doc-58b9197efd52aaaaf2628f77',2,2);
INSERT INTO "document_macro_pins" VALUES('doc-1e4f0c5c2e394387ce7165fe',1,3);
INSERT INTO "document_macro_pins" VALUES('doc-0f819e0cfea434b82ffc8823',1,3);
INSERT INTO "document_macro_pins" VALUES('doc-adf74e15920f0fb47c0a88f1',1,3);
INSERT INTO "document_macro_pins" VALUES('doc-ed8581e68ef9d205cd12249f',1,3);
INSERT INTO "document_macro_pins" VALUES('doc-f51aef9e079c43038da9b3d0',1,3);
INSERT INTO "document_macro_pins" VALUES('doc-dbd8ffaf1480d8b94d29e9ae',1,3);
INSERT INTO "document_macro_pins" VALUES('doc-6d5d225787c1ec2d34b50b21',1,4);
INSERT INTO "document_macro_pins" VALUES('doc-6d5d225787c1ec2d34b50b21',2,4);
CREATE TABLE documents (
    document_id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL,
    session_id TEXT,
    name TEXT NOT NULL,
    title TEXT NOT NULL,
    created_at TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_session TEXT,
    takes_suggestions INTEGER NOT NULL DEFAULT 0,
    head INTEGER NOT NULL,
    deleted INTEGER NOT NULL DEFAULT 0,
    next_block INTEGER NOT NULL,
    next_span INTEGER NOT NULL
) STRICT;
INSERT INTO "documents" VALUES('doc-58b9197efd52aaaaf2628f77','p','s','a','a','2026-10-14T20:31:25.099883+00:00','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}','s',0,2,0,2,2);
INSERT INTO "documents" VALUES('doc-1e4f0c5c2e394387ce7165fe','p','s','b','b','2026-10-14T20:31:25.115358+00:00','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}','s',0,1,0,2,1);
INSERT INTO "documents" VALUES('doc-0f819e0cfea434b82ffc8823','p','s','c1','c1','2026-10-14T20:31:25.121353+00:00','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}','s',0,1,0,2,0);
INSERT INTO "documents" VALUES('doc-adf74e15920f0fb47c0a88f1','p','s','c2','c2','2026-10-14T20:31:25.122183+00:00','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}','s',0,1,0,2,0);
INSERT INTO "documents" VALUES('doc-ed8581e68ef9d205cd12249f','p','s','d1','d1','2026-10-14T20:31:25.122966+00:00','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}','s',0,1,0,2,0);
INSERT INTO "documents" VALUES('doc-f51aef9e079c43038da9b3d0','p','s','d2','d2','2026-10-14T20:31:25.123717+00:00','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}','s',0,1,0,2,0);
INSERT INTO "documents" VALUES('doc-dbd8ffaf1480d8b94d29e9ae','p','s','e1','e1','2026-10-14T20:31:25.124473+00:00','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}','s',0,1,0,2,0);
INSERT INTO "documents" VALUES('doc-6d5d225787c1ec2d34b50b21','p','s','g','g','2026-10-14T20:31:25.227133+00:00','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}','s',0,2,0,2,1);
CREATE TABLE events (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    time TEXT NOT NULL,
    kind TEXT NOT NULL,
    producer TEXT NOT NULL,
    project_id TEXT NOT NULL,
    session_id TEXT,
    document_id TEXT NOT NULL,
    payload TEXT NOT NULL
) STRICT;
INSERT INTO "events" VALUES(1,'2026-10-14T20:31:25.099952+00:00','document.created','harness','p','s','doc-58b9197efd52aaaaf2628f77','{"name":"a","title":"a","scope":"session","author":{"kind":"agent","session_id":"s","run_id":"r1","role":"main","model":"scripted"}}');
INSERT INTO "events" VALUES(2,'2026-10-14T20:31:25.101039+00:00','document.revision_created','harness','p','s','doc-58b9197efd52aaaaf2628f77','{"revision":1,"base":null,"parent":null,"author":{"kind":"agent","session_id":"s","run_id":"r1","role":"main","model":"scripted"},"author_kind":"agent","changed":[],"added":["b1","b2"],"removed":[],"moved":[],"structural_added":[],"agent_characters":24,"normalized":false,"tombstone":false}');
INSERT INTO "events" VALUES(3,'2026-10-14T20:31:25.108677+00:00','document.revision_created','harness','p','s','doc-58b9197efd52aaaaf2628f77','{"revision":2,"base":1,"parent":1,"author":{"kind":"agent","session_id":"s","run_id":"r1","role":"main","model":"scripted"},"author_kind":"agent","changed":["b1"],"added":[],"removed":[],"moved":[],"structural_added":[],"agent_characters":1,"normalized":false,"tombstone":false,"patch_id":"patch-6c88bc51286db1b1bcceaa9d"}');
INSERT INTO "events" VALUES(4,'2026-10-14T20:31:25.115385+00:00','document.created','harness','p','s','doc-1e4f0c5c2e394387ce7165fe','{"name":"b","title":"b","scope":"session","author":{"kind":"agent","session_id":"s","run_id":"r1","role":"main","model":"scripted"}}');
INSERT INTO "events" VALUES(5,'2026-10-14T20:31:25.115879+00:00','document.revision_created','harness','p','s','doc-1e4f0c5c2e394387ce7165fe','{"revision":1,"base":null,"parent":null,"author":{"kind":"agent","session_id":"s","run_id":"r1","role":"main","model":"scripted"},"author_kind":"agent","changed":[],"added":["b1","b2"],"removed":[],"moved":[],"structural_added":[],"agent_characters":43,"normalized":false,"tombstone":false}');
INSERT INTO "events" VALUES(6,'2026-10-14T20:31:25.116649+00:00','annotation.created','harness','p','s','doc-1e4f0c5c2e394387ce7165fe','{"thread_id":"ann-7ecabb131bf6508142c9bd97","entry_id":"cmt-924da581199378bcff722140","revision":1,"request_id":null,"outcome":"create","author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"action":"create"}');
INSERT INTO "events" VALUES(7,'2026-10-14T20:31:25.121378+00:00','document.created','harness','p','s','doc-0f819e0cfea434b82ffc8823','{"name":"c1","title":"c1","scope":"session","author":{"kind":"agent","session_id":"s","run_id":"r1","role":"main","model":"scripted"}}');
INSERT INTO "events" VALUES(8,'2026-10-14T20:31:25.121854+00:00','document.revision_created','harness','p','s','doc-0f819e0cfea434b82ffc8823','{"revision":1,"base":null,"parent":null,"author":{"kind":"agent","session_id":"s","run_id":"r1","role":"main","model":"scripted"},"author_kind":"agent","changed":[],"added":["b1","b2"],"removed":[],"moved":[],"structural_added":[],"agent_characters":45,"normalized":false,"tombstone":false}');
INSERT INTO "events" VALUES(9,'2026-10-14T20:31:25.122204+00:00','document.created','harness','p','s','doc-adf74e15920f0fb47c0a88f1','{"name":"c2","title":"c2","scope":"session","author":{"kind":"agent","session_id":"s","run_id":"r1","role":"main","model":"scripted"}}');
INSERT INTO "events" VALUES(10,'2026-10-14T20:31:25.122644+00:00','document.revision_created','harness','p','s','doc-adf74e15920f0fb47c0a88f1','{"revision":1,"base":null,"parent":null,"author":{"kind":"agent","session_id":"s","run_id":"r1","role":"main","model":"scripted"},"author_kind":"agent","changed":[],"added":["b1","b2"],"removed":[],"moved":[],"structural_added":[],"agent_characters":45,"normalized":false,"tombstone":false}');
INSERT INTO "events" VALUES(11,'2026-10-14T20:31:25.122985+00:00','document.created','harness','p','s','doc-ed8581e68ef9d205cd12249f','{"name":"d1","title":"d1","scope":"session","author":{"kind":"agent","session_id":"s","run_id":"r1","role":"main","model":"scripted"}}');
INSERT INTO "events" VALUES(12,'2026-10-14T20:31:25.123417+00:00','document.revision_created','harness','p','s','doc-ed8581e68ef9d205cd12249f','{"revision":1,"base":null,"parent":null,"author":{"kind":"agent","session_id":"s","run_id":"r1","role":"main","model":"scripted"},"author_kind":"agent","changed":[],"added":["b1","b2"],"removed":[],"moved":[],"structural_added":[],"agent_characters":42,"normalized":false,"tombstone":false}');
INSERT INTO "events" VALUES(13,'2026-10-14T20:31:25.123737+00:00','document.created','harness','p','s','doc-f51aef9e079c43038da9b3d0','{"name":"d2","title":"d2","scope":"session","author":{"kind":"agent","session_id":"s","run_id":"r1","role":"main","model":"scripted"}}');
INSERT INTO "events" VALUES(14,'2026-10-14T20:31:25.124170+00:00','document.revision_created','harness','p','s','doc-f51aef9e079c43038da9b3d0','{"revision":1,"base":null,"parent":null,"author":{"kind":"agent","session_id":"s","run_id":"r1","role":"main","model":"scripted"},"author_kind":"agent","changed":[],"added":["b1","b2"],"removed":[],"moved":[],"structural_added":[],"agent_characters":42,"normalized":false,"tombstone":false}');
INSERT INTO "events" VALUES(15,'2026-10-14T20:31:25.124492+00:00','document.created','harness','p','s','doc-dbd8ffaf1480d8b94d29e9ae','{"name":"e1","title":"e1","scope":"session","author":{"kind":"agent","session_id":"s","run_id":"r1","role":"main","model":"scripted"}}');
INSERT INTO "events" VALUES(16,'2026-10-14T20:31:25.124908+00:00','document.revision_created','harness','p','s','doc-dbd8ffaf1480d8b94d29e9ae','{"revision":1,"base":null,"parent":null,"author":{"kind":"agent","session_id":"s","run_id":"r1","role":"main","model":"scripted"},"author_kind":"agent","changed":[],"added":["b1","b2"],"removed":[],"moved":[],"structural_added":[],"agent_characters":47,"normalized":false,"tombstone":false}');
INSERT INTO "events" VALUES(17,'2026-10-14T20:31:25.227178+00:00','document.created','harness','p','s','doc-6d5d225787c1ec2d34b50b21','{"name":"g","title":"g","scope":"session","author":{"kind":"agent","session_id":"s","run_id":"r1","role":"main","model":"scripted"}}');
INSERT INTO "events" VALUES(18,'2026-10-14T20:31:25.227797+00:00','document.revision_created','harness','p','s','doc-6d5d225787c1ec2d34b50b21','{"revision":1,"base":null,"parent":null,"author":{"kind":"agent","session_id":"s","run_id":"r1","role":"main","model":"scripted"},"author_kind":"agent","changed":[],"added":["b1","b2"],"removed":[],"moved":[],"structural_added":[],"agent_characters":40,"normalized":false,"tombstone":false}');
INSERT INTO "events" VALUES(19,'2026-10-14T20:31:25.228521+00:00','annotation.created','harness','p','s','doc-6d5d225787c1ec2d34b50b21','{"thread_id":"ann-cdceedd110afad4816ba61f0","entry_id":"cmt-c4fce9bb05f36a81283a26a4","revision":1,"request_id":null,"outcome":"create","author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"action":"create"}');
INSERT INTO "events" VALUES(20,'2026-10-14T20:31:25.236748+00:00','document.revision_created','harness','p',NULL,'doc-6d5d225787c1ec2d34b50b21','{"revision":2,"base":1,"parent":1,"author":{"kind":"user","user":"user"},"author_kind":"user","changed":["b1","b2"],"added":[],"removed":[],"moved":[],"structural_added":[],"agent_characters":0,"normalized":false,"tombstone":false}');
CREATE TABLE job_acknowledged (
    project TEXT, session TEXT, job TEXT, run TEXT,
    PRIMARY KEY(project, session, job));
CREATE TABLE job_origins (
    project TEXT, session TEXT, job TEXT, run TEXT,
    PRIMARY KEY(project, session, job));
CREATE TABLE job_runs (
    project TEXT, session TEXT, run TEXT, heartbeat REAL,
    PRIMARY KEY(project, session, run));
CREATE TABLE job_waits (
    project TEXT, session TEXT, run TEXT, payload TEXT,
    PRIMARY KEY(project, session, run));
CREATE TABLE job_watcher_calls (
    id INTEGER PRIMARY KEY, project TEXT, session TEXT, run TEXT,
    job TEXT, alias TEXT, requested_at REAL, input TEXT,
    outcome TEXT, model TEXT, input_tokens INTEGER, output_tokens INTEGER,
    prompt_provenance TEXT);
CREATE TABLE "math_block_owners" (
    document TEXT NOT NULL REFERENCES documents(document_id), block TEXT NOT NULL,
    revision INTEGER NOT NULL CHECK (revision BETWEEN 1 AND 999999999),
    author TEXT NOT NULL CHECK (json_valid(author)),
    PRIMARY KEY(document,block)) STRICT;
INSERT INTO "math_block_owners" VALUES('doc-58b9197efd52aaaaf2628f77','b1',2,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
INSERT INTO "math_block_owners" VALUES('doc-58b9197efd52aaaaf2628f77','b2',1,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
INSERT INTO "math_block_owners" VALUES('doc-1e4f0c5c2e394387ce7165fe','b1',1,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
INSERT INTO "math_block_owners" VALUES('doc-1e4f0c5c2e394387ce7165fe','b2',1,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
INSERT INTO "math_block_owners" VALUES('doc-0f819e0cfea434b82ffc8823','b1',1,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
INSERT INTO "math_block_owners" VALUES('doc-0f819e0cfea434b82ffc8823','b2',1,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
INSERT INTO "math_block_owners" VALUES('doc-adf74e15920f0fb47c0a88f1','b1',1,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
INSERT INTO "math_block_owners" VALUES('doc-adf74e15920f0fb47c0a88f1','b2',1,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
INSERT INTO "math_block_owners" VALUES('doc-ed8581e68ef9d205cd12249f','b1',1,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
INSERT INTO "math_block_owners" VALUES('doc-ed8581e68ef9d205cd12249f','b2',1,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
INSERT INTO "math_block_owners" VALUES('doc-f51aef9e079c43038da9b3d0','b1',1,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
INSERT INTO "math_block_owners" VALUES('doc-f51aef9e079c43038da9b3d0','b2',1,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
INSERT INTO "math_block_owners" VALUES('doc-dbd8ffaf1480d8b94d29e9ae','b1',1,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
INSERT INTO "math_block_owners" VALUES('doc-dbd8ffaf1480d8b94d29e9ae','b2',1,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
INSERT INTO "math_block_owners" VALUES('doc-6d5d225787c1ec2d34b50b21','b1',2,'{"kind":"user","user":"user","session_id":null,"run_id":null,"role":null,"model":null,"alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
INSERT INTO "math_block_owners" VALUES('doc-6d5d225787c1ec2d34b50b21','b2',2,'{"kind":"user","user":"user","session_id":null,"run_id":null,"role":null,"model":null,"alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
CREATE TABLE "math_comment_jobs" (
    check_id TEXT PRIMARY KEY REFERENCES math_jobs(check_id),
    entry_id TEXT NOT NULL REFERENCES annotation_entries(entry_id),
    macro_revision INTEGER NOT NULL CHECK (macro_revision BETWEEN 0 AND 999999999),
    macro_sha256 TEXT NOT NULL
        CHECK (length(macro_sha256) = 64 AND macro_sha256 NOT GLOB '*[^0-9a-f]*')) STRICT;
INSERT INTO "math_comment_jobs" VALUES('math-e55948cc0e503b27d8e096ba','cmt-924da581199378bcff722140',1,'6c2dc0ee0ced3db7079f1f94ee41a9721245d43cae77a69bec8814c6eb4c91ab');
INSERT INTO "math_comment_jobs" VALUES('math-942d8f9197b742c34c7c3a47','cmt-924da581199378bcff722140',1,'6c2dc0ee0ced3db7079f1f94ee41a9721245d43cae77a69bec8814c6eb4c91ab');
INSERT INTO "math_comment_jobs" VALUES('math-e79382c1c1593b3b340b5757','cmt-c4fce9bb05f36a81283a26a4',1,'79d8e00656390250b526b51dc6b4999ed42b809483609b7572bed89b3bdbb4a9');
INSERT INTO "math_comment_jobs" VALUES('math-1300bb97f6f90b0096106700','cmt-924da581199378bcff722140',1,'6c2dc0ee0ced3db7079f1f94ee41a9721245d43cae77a69bec8814c6eb4c91ab');
INSERT INTO "math_comment_jobs" VALUES('math-7762893baa2559a0c1f6af96','cmt-c4fce9bb05f36a81283a26a4',2,'c56f5531026421f165cf043a7ca89a86bc400cf14d99b02b27bb6e804968b49a');
CREATE TABLE math_finding_state (
    finding_id TEXT PRIMARY KEY REFERENCES review_findings(finding_id),
    document TEXT NOT NULL,block TEXT NOT NULL,span TEXT NOT NULL,
    checked_revision INTEGER NOT NULL,input_sha256 TEXT NOT NULL,
    owner_revision INTEGER NOT NULL,
    checked_check TEXT NOT NULL REFERENCES math_jobs(check_id),excluded TEXT,
    UNIQUE(document,block,span)) STRICT;
INSERT INTO "math_finding_state" VALUES('finding-fc52622e4f87078760aa6f5e','doc-58b9197efd52aaaaf2628f77','b1','m1',2,'c9bb150ba0fde0f6915733e661691649a10a398ba0d81f80c7aa26197718d0a2',2,'math-f4d01318b3533f2235bcf545',NULL);
INSERT INTO "math_finding_state" VALUES('finding-e157e420507d284c5f22e341','doc-58b9197efd52aaaaf2628f77','b1','m2',2,'0ba2c67574982b2c485c75f1579b6ac395b89ad417778e5dd38a71a9c4fc15b1',2,'math-f4d01318b3533f2235bcf545',NULL);
INSERT INTO "math_finding_state" VALUES('finding-917db304507211c7b1843d18','doc-6d5d225787c1ec2d34b50b21','b2','m1',2,'df16f93bbc4257dc5a4ebec380bce4b5f0a9bca3231bb0e742e3c182fea0c47b',1,'math-55a856f2cfa6cdf0dc8ffcc7','Current last-changing block owner is USER, non-author, unknown, or has no established session. Historical evidence remains unresolved.');
INSERT INTO "math_finding_state" VALUES('finding-f65c492ad291fed66c0bebfc','comment:cmt-c4fce9bb05f36a81283a26a4','b1','m1',1,'43038fdfd8bc13935f31e723cda1ee169a4d151c7a9eb07ed2c259fbfc2185d5',1,'math-7762893baa2559a0c1f6af96',NULL);
INSERT INTO "math_finding_state" VALUES('finding-76a488db1f7ed0dbeefce52d','doc-1e4f0c5c2e394387ce7165fe','b2','m1',1,'e3e1990be7435aa854d98682c49dfbdceb00621448ba2157d0e6820a22b9a2cd',1,'math-104a8d905459fea011090c5a',NULL);
INSERT INTO "math_finding_state" VALUES('finding-3cd95b5b437e2f443a804203','comment:cmt-924da581199378bcff722140','b1','m1',1,'13bbcdc55715b4d16879a37ffcc315645b22984bf2d5821243d806d275463a50',1,'math-1300bb97f6f90b0096106700',NULL);
INSERT INTO "math_finding_state" VALUES('finding-dd5709e9bc7427195c843f29','response:finding-da4788c18fb518061f270269:r2:explanation','b1','m1',2,'6f1a5f8744e92e0f5bba512ddf843cb7a3ecf265683d2b372d347362d403cfae',2,'math-b741b94af44bab1010cc993b',NULL);
INSERT INTO "math_finding_state" VALUES('finding-c18690edcf3ea6b28d2346a6','response:finding-440cc2bad6a1de3ea75400d0:r2:explanation','b1','m1',1,'aa76a30001da828ac167a6c8f94a0dd4d2c875c45a6222b0e1535382d2ee4bbc',1,'math-68552ac718d6b1250e181062',NULL);
CREATE TABLE math_ignored (
    finding_id TEXT NOT NULL, revision INTEGER NOT NULL, run TEXT NOT NULL,
    PRIMARY KEY(finding_id,revision)) STRICT;
CREATE TABLE "math_job_owners" (
    check_id TEXT NOT NULL REFERENCES math_jobs(check_id), block TEXT NOT NULL,
    revision INTEGER CHECK (revision IS NULL OR revision BETWEEN 1 AND 999999999),
    author TEXT CHECK (author IS NULL
        OR (json_valid(author) AND length(CAST(author AS BLOB)) <= 8192)),
    bytes INTEGER NOT NULL CHECK (bytes >= 0),
    PRIMARY KEY(check_id,block)) STRICT;
INSERT INTO "math_job_owners" VALUES('math-c58332d069b276776d8206e1','b1',1,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',255);
INSERT INTO "math_job_owners" VALUES('math-50b2cd794ed66f760f8186a0','b1',2,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',255);
INSERT INTO "math_job_owners" VALUES('math-be63c39f5fbc76967857983f','b1',2,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',255);
INSERT INTO "math_job_owners" VALUES('math-e05e53133f4ac63bf05191db','b2',1,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',255);
INSERT INTO "math_job_owners" VALUES('math-ef2c3ae78cbce2dee9b77890','b1',2,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',255);
INSERT INTO "math_job_owners" VALUES('math-7cc44edc39f4c1a348d4bf46','b2',1,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',255);
INSERT INTO "math_job_owners" VALUES('math-b59ccb1495d1d5e8aae71190','b2',1,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',255);
INSERT INTO "math_job_owners" VALUES('math-f4d01318b3533f2235bcf545','b1',2,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',255);
INSERT INTO "math_job_owners" VALUES('math-104a8d905459fea011090c5a','b2',1,'{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',255);
INSERT INTO "math_job_owners" VALUES('math-55a856f2cfa6cdf0dc8ffcc7','b2',2,'{"kind":"user","user":"user","session_id":null,"run_id":null,"role":null,"model":null,"alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',249);
CREATE TABLE "math_jobs" (
    check_id TEXT PRIMARY KEY CHECK (length(CAST(check_id AS BLOB)) BETWEEN 1 AND 128),
    document TEXT REFERENCES documents(document_id),
    revision INTEGER NOT NULL CHECK (revision BETWEEN 1 AND 999999999),
    source_sha256 TEXT NOT NULL
        CHECK (length(source_sha256) = 64 AND source_sha256 NOT GLOB '*[^0-9a-f]*'),
    state TEXT NOT NULL CHECK (state IN ('running', 'finished')),
    owner TEXT CHECK (owner IS NULL OR length(CAST(owner AS BLOB)) <= 128),
    lease_until REAL CHECK (lease_until IS NULL OR lease_until BETWEEN -1e18 AND 1e18),
    cursor INTEGER NOT NULL DEFAULT 0 CHECK (cursor BETWEEN 0 AND 20000),
    spans INTEGER CHECK (spans IS NULL OR spans BETWEEN 0 AND 20000),
    available INTEGER NOT NULL DEFAULT 0 CHECK (available BETWEEN 0 AND 1000000000),
    rejected INTEGER NOT NULL DEFAULT 0 CHECK (rejected BETWEEN 0 AND 1000000000),
    unavailable INTEGER NOT NULL DEFAULT 0 CHECK (unavailable BETWEEN 0 AND 1000000000),
    configuration TEXT CHECK (configuration IS NULL
        OR (json_valid(configuration) AND length(CAST(configuration AS BLOB)) <= 4096)),
    runtime TEXT CHECK (runtime IS NULL OR length(CAST(runtime AS BLOB)) <= 256),
    reason TEXT CHECK (reason IS NULL OR length(CAST(reason AS BLOB)) <= 4096),
    attribution_cursor INTEGER
        CHECK (attribution_cursor IS NULL OR attribution_cursor BETWEEN 0 AND revision),
    created REAL NOT NULL CHECK (created BETWEEN -1e18 AND 1e18),
    ended REAL CHECK (ended IS NULL OR ended BETWEEN -1e18 AND 1e18)) STRICT;
INSERT INTO "math_jobs" VALUES('math-c58332d069b276776d8206e1','doc-58b9197efd52aaaaf2628f77',1,'7fcace58933d4f12f56947f2b6ecadd1f90f62a88419d1efe1735389d1c2d2b9','finished',NULL,NULL,2,2,2,2,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-50b2cd794ed66f760f8186a0','doc-58b9197efd52aaaaf2628f77',2,'ac6576e1e89ad370183e2dea65ddc756024b91f6dcb350cc8639e091be739f6b','finished',NULL,NULL,2,2,2,2,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-be63c39f5fbc76967857983f','doc-58b9197efd52aaaaf2628f77',2,'ac6576e1e89ad370183e2dea65ddc756024b91f6dcb350cc8639e091be739f6b','finished',NULL,NULL,2,2,2,2,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-e05e53133f4ac63bf05191db','doc-1e4f0c5c2e394387ce7165fe',1,'6c2dc0ee0ced3db7079f1f94ee41a9721245d43cae77a69bec8814c6eb4c91ab','finished',NULL,NULL,1,1,1,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-e55948cc0e503b27d8e096ba','doc-1e4f0c5c2e394387ce7165fe',1,'bc77b524efd01ebf2286358d6ca594b228ded4f097152d0bf63edc4a52c79f5f','finished',NULL,NULL,1,1,1,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-725e0c4be9f01e6202edd151','doc-0f819e0cfea434b82ffc8823',1,'165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99','finished',NULL,NULL,0,0,0,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-4e51caaff70e4f4990033cbc','doc-adf74e15920f0fb47c0a88f1',1,'950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635','finished',NULL,NULL,0,0,0,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-ffa8255534cd5212292c57e1','doc-ed8581e68ef9d205cd12249f',1,'cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9','finished',NULL,NULL,0,0,0,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-9fc76a6a27d799da22e4d330','doc-f51aef9e079c43038da9b3d0',1,'4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820','finished',NULL,NULL,0,0,0,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-3f4bf88202a8d0787f10d6b3','doc-dbd8ffaf1480d8b94d29e9ae',1,'1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3','finished',NULL,NULL,0,0,0,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-21aa05cb516db0d8367d4cd2',NULL,1,'7d3423f86984a470f1a769d75230ce802593fd649e3cfd210710edfeee83bf0b','finished',NULL,NULL,1,1,1,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-654724b3c2bfa1b173f978da',NULL,1,'8f81adb3d27478ae3ce0dbc859f644b230e6366968eaab1d34b395fd37fb5fca','finished',NULL,NULL,1,1,0,0,1,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,'macro context unknown or ambiguous',NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-fe9d5e3101b3bb69523754fa',NULL,1,'87456495ae7a5ad905798bc8a5005cf8e8d1389df8a1c48602199acb6fd00a32','finished',NULL,NULL,1,1,0,0,1,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,'macro context unknown or ambiguous',NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-f71b32f4548e92552136c064',NULL,1,'1fdfac3bc7e9978cfa3690af5ff0c07502ed6298f2794f3e5e315c5b4a8b1dfc','finished',NULL,NULL,1,1,1,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-ef2c3ae78cbce2dee9b77890','doc-58b9197efd52aaaaf2628f77',2,'ac6576e1e89ad370183e2dea65ddc756024b91f6dcb350cc8639e091be739f6b','finished',NULL,NULL,2,2,2,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-7cc44edc39f4c1a348d4bf46','doc-1e4f0c5c2e394387ce7165fe',1,'6c2dc0ee0ced3db7079f1f94ee41a9721245d43cae77a69bec8814c6eb4c91ab','finished',NULL,NULL,1,1,1,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-1a8ebabdebcbd8362898f86c','doc-0f819e0cfea434b82ffc8823',1,'165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99','finished',NULL,NULL,0,0,0,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-450892bbe5c5ab0fac83c7e5','doc-adf74e15920f0fb47c0a88f1',1,'950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635','finished',NULL,NULL,0,0,0,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-bc33e7c5407f7311d58cb249','doc-ed8581e68ef9d205cd12249f',1,'cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9','finished',NULL,NULL,0,0,0,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-b2a2d22601de3c2359a26f5b','doc-f51aef9e079c43038da9b3d0',1,'4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820','finished',NULL,NULL,0,0,0,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-77a05068cac499fd9af80bfb','doc-dbd8ffaf1480d8b94d29e9ae',1,'1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3','finished',NULL,NULL,0,0,0,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-942d8f9197b742c34c7c3a47','doc-1e4f0c5c2e394387ce7165fe',1,'bc77b524efd01ebf2286358d6ca594b228ded4f097152d0bf63edc4a52c79f5f','finished',NULL,NULL,1,1,1,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-d0d12b565bdb1ce6da8d04a0',NULL,2,'22521436510afa8d68f19b1a347f23544228a2c0cc22de3f29b4851a4f310af6','finished',NULL,NULL,1,1,1,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-64fe7c86b54dce815cbb1a9b',NULL,1,'8f81adb3d27478ae3ce0dbc859f644b230e6366968eaab1d34b395fd37fb5fca','finished',NULL,NULL,1,1,0,0,1,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,'macro context unknown or ambiguous',NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-771bf61bb9f3edda455d8281',NULL,2,'22521436510afa8d68f19b1a347f23544228a2c0cc22de3f29b4851a4f310af6','finished',NULL,NULL,1,1,0,0,1,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,'macro context unknown or ambiguous',NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-f2a183c656b51c5b92457c9f',NULL,1,'1fdfac3bc7e9978cfa3690af5ff0c07502ed6298f2794f3e5e315c5b4a8b1dfc','finished',NULL,NULL,1,1,1,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-b59ccb1495d1d5e8aae71190','doc-6d5d225787c1ec2d34b50b21',1,'79d8e00656390250b526b51dc6b4999ed42b809483609b7572bed89b3bdbb4a9','finished',NULL,NULL,1,1,1,1,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-e79382c1c1593b3b340b5757','doc-6d5d225787c1ec2d34b50b21',1,'496550ffe147968e6d256bea2d07983848a5de00c020023ea51db07418bbce42','finished',NULL,NULL,1,1,1,1,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-f4d01318b3533f2235bcf545','doc-58b9197efd52aaaaf2628f77',2,'ac6576e1e89ad370183e2dea65ddc756024b91f6dcb350cc8639e091be739f6b','finished',NULL,NULL,2,2,2,2,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-104a8d905459fea011090c5a','doc-1e4f0c5c2e394387ce7165fe',1,'6c2dc0ee0ced3db7079f1f94ee41a9721245d43cae77a69bec8814c6eb4c91ab','finished',NULL,NULL,1,1,1,1,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-9f4b208e7f95aa84a308e7b1','doc-0f819e0cfea434b82ffc8823',1,'165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99','finished',NULL,NULL,0,0,0,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-590f73c3901ee70e6eb71b9a','doc-adf74e15920f0fb47c0a88f1',1,'950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635','finished',NULL,NULL,0,0,0,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-954ca7f3c9afcafdd85fd338','doc-ed8581e68ef9d205cd12249f',1,'cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9','finished',NULL,NULL,0,0,0,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-050520ea29b1158f437284df','doc-f51aef9e079c43038da9b3d0',1,'4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820','finished',NULL,NULL,0,0,0,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-25eb8c0b753beba4f0a85a77','doc-dbd8ffaf1480d8b94d29e9ae',1,'1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3','finished',NULL,NULL,0,0,0,0,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-55a856f2cfa6cdf0dc8ffcc7','doc-6d5d225787c1ec2d34b50b21',2,'c56f5531026421f165cf043a7ca89a86bc400cf14d99b02b27bb6e804968b49a','finished',NULL,NULL,1,1,1,1,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-1300bb97f6f90b0096106700','doc-1e4f0c5c2e394387ce7165fe',1,'bc77b524efd01ebf2286358d6ca594b228ded4f097152d0bf63edc4a52c79f5f','finished',NULL,NULL,1,1,1,1,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-7762893baa2559a0c1f6af96','doc-6d5d225787c1ec2d34b50b21',1,'496550ffe147968e6d256bea2d07983848a5de00c020023ea51db07418bbce42','finished',NULL,NULL,1,1,1,1,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-b741b94af44bab1010cc993b',NULL,2,'22521436510afa8d68f19b1a347f23544228a2c0cc22de3f29b4851a4f310af6','finished',NULL,NULL,1,1,1,1,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-b05363a5fd73028d3c970f17',NULL,1,'8f81adb3d27478ae3ce0dbc859f644b230e6366968eaab1d34b395fd37fb5fca','finished',NULL,NULL,1,1,0,0,1,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,'macro context unknown or ambiguous',NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-285001889502f84ad18493f9',NULL,2,'22521436510afa8d68f19b1a347f23544228a2c0cc22de3f29b4851a4f310af6','finished',NULL,NULL,1,1,0,0,1,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}',NULL,'macro context unknown or ambiguous',NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-68552ac718d6b1250e181062',NULL,1,'1fdfac3bc7e9978cfa3690af5ff0c07502ed6298f2794f3e5e315c5b4a8b1dfc','finished',NULL,NULL,1,1,1,1,0,'{"bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9"}','22.0.0',NULL,NULL,1000.0,1000.0);
INSERT INTO "math_jobs" VALUES('math-7700bf54c54457cd99a84bc9','doc-58b9197efd52aaaaf2628f77',2,'ac6576e1e89ad370183e2dea65ddc756024b91f6dcb350cc8639e091be739f6b','running','owner',1120.0,0,NULL,0,0,0,NULL,NULL,NULL,2,1000.0,NULL);
CREATE TABLE "math_macro_contexts" (
    check_id TEXT PRIMARY KEY REFERENCES math_jobs(check_id),
    definitions TEXT NOT NULL
        CHECK (json_valid(definitions) AND length(CAST(definitions AS BLOB)) <= 65536),
    problems TEXT NOT NULL
        CHECK (json_valid(problems) AND length(CAST(problems AS BLOB)) <= 32768),
    held INTEGER NOT NULL CHECK (held IN (0, 1)),
    context_key TEXT NOT NULL
        CHECK (length(context_key) = 64 AND context_key NOT GLOB '*[^0-9a-f]*')) STRICT;
INSERT INTO "math_macro_contexts" VALUES('math-c58332d069b276776d8206e1','{"\\F":"before","\\G":"g"}','[]',0,'3d10b7bc550d306c0da4a34fff068c7f2a10920ee00515a5c6090eddf841a096');
INSERT INTO "math_macro_contexts" VALUES('math-50b2cd794ed66f760f8186a0','{"\\F":"after","\\G":"g"}','[]',0,'9355a11d491522e12426dc69acb4b8c065a44198b2d941e4eab9bc81d9ebe5ec');
INSERT INTO "math_macro_contexts" VALUES('math-be63c39f5fbc76967857983f','{"\\F":"third"}','[]',0,'bef56af3d5bae9911e06f3497895794f643399ca18d7408a8276f5409a24ee40');
INSERT INTO "math_macro_contexts" VALUES('math-e05e53133f4ac63bf05191db','{"\\F":"document"}','[]',0,'315038025c17ab94979eb18c4221d784e9a421af4e655108c0a4b9bef129d054');
INSERT INTO "math_macro_contexts" VALUES('math-e55948cc0e503b27d8e096ba','{"\\F":"document"}','[]',0,'315038025c17ab94979eb18c4221d784e9a421af4e655108c0a4b9bef129d054');
INSERT INTO "math_macro_contexts" VALUES('math-725e0c4be9f01e6202edd151','{"\\F":"agreed"}','[]',0,'e4d76336021b5476ab16157eb17787dc4957b934c965c147c7825bf390348f0f');
INSERT INTO "math_macro_contexts" VALUES('math-4e51caaff70e4f4990033cbc','{"\\F":"agreed"}','[]',0,'e4d76336021b5476ab16157eb17787dc4957b934c965c147c7825bf390348f0f');
INSERT INTO "math_macro_contexts" VALUES('math-ffa8255534cd5212292c57e1','{"\\F":"one"}','[]',0,'d9eef9dbcf5bb64161a14f7a5c0115493c8223edb48c6a65c68a2435b5ae5d67');
INSERT INTO "math_macro_contexts" VALUES('math-9fc76a6a27d799da22e4d330','{"\\F":"two"}','[]',0,'ce4a0bb419ebbe7e827b5dfd06d8270273891a20670e44bee459ff1b4e753abe');
INSERT INTO "math_macro_contexts" VALUES('math-3f4bf88202a8d0787f10d6b3','{"\\F":"agreed"}','[]',0,'e4d76336021b5476ab16157eb17787dc4957b934c965c147c7825bf390348f0f');
INSERT INTO "math_macro_contexts" VALUES('math-21aa05cb516db0d8367d4cd2','{"\\F":"agreed"}','[]',0,'6912a0bb7ee1dc2eb41763097f0271ad10eca05ccea438978f1f8519cc6f13fb');
INSERT INTO "math_macro_contexts" VALUES('math-654724b3c2bfa1b173f978da','{"\\F":"third"}','["Conflicting anchored document macro contexts; checks are held"]',1,'e456b35f7177c92652342779d530b53044b0118114d93821d0a9a704b8f30d51');
INSERT INTO "math_macro_contexts" VALUES('math-fe9d5e3101b3bb69523754fa','{"\\F":"third"}','["Anchored macro context is unknown; checks are held"]',1,'ce41bd1d8b21cae32e47256cbfc09d50a2d90409a4427d7535ebec07eb7b8887');
INSERT INTO "math_macro_contexts" VALUES('math-f71b32f4548e92552136c064','{"\\F":"agreed"}','[]',0,'84d0dcfc39e30fe6dcabead17a2864983f561edbd025f06a20f2ec9a81a3006e');
INSERT INTO "math_macro_contexts" VALUES('math-ef2c3ae78cbce2dee9b77890','{"\\F":"fourth","\\G":"g4"}','[]',0,'956bbaeaab3a71ada9e2317ecec4f5ba2f242275b5f98c46c979c44d69b843a4');
INSERT INTO "math_macro_contexts" VALUES('math-7cc44edc39f4c1a348d4bf46','{"\\F":"document","\\G":"g4"}','[]',0,'e1221d8962819bed59decc67d9a603a928bd0c656c6299664f2971f31b63dbb5');
INSERT INTO "math_macro_contexts" VALUES('math-1a8ebabdebcbd8362898f86c','{"\\F":"agreed","\\G":"g4"}','[]',0,'7fec8fb9af317aeafd8bd0e30f0ef4e094b934ff5cc15ae041f244d5412e6a6e');
INSERT INTO "math_macro_contexts" VALUES('math-450892bbe5c5ab0fac83c7e5','{"\\F":"agreed","\\G":"g4"}','[]',0,'7fec8fb9af317aeafd8bd0e30f0ef4e094b934ff5cc15ae041f244d5412e6a6e');
INSERT INTO "math_macro_contexts" VALUES('math-bc33e7c5407f7311d58cb249','{"\\F":"one","\\G":"g4"}','[]',0,'a536b0bf0ecab31edf5b9b67e57d85d1ce50968519f8c64a85d839ae941652c7');
INSERT INTO "math_macro_contexts" VALUES('math-b2a2d22601de3c2359a26f5b','{"\\F":"two","\\G":"g4"}','[]',0,'3223c3b11152234b243c70fd4f6197b10e32a7bcd7b3675ef68f21726ddfca6e');
INSERT INTO "math_macro_contexts" VALUES('math-77a05068cac499fd9af80bfb','{"\\F":"agreed","\\G":"g4"}','[]',0,'7fec8fb9af317aeafd8bd0e30f0ef4e094b934ff5cc15ae041f244d5412e6a6e');
INSERT INTO "math_macro_contexts" VALUES('math-942d8f9197b742c34c7c3a47','{"\\F":"document","\\G":"g4"}','[]',0,'e1221d8962819bed59decc67d9a603a928bd0c656c6299664f2971f31b63dbb5');
INSERT INTO "math_macro_contexts" VALUES('math-d0d12b565bdb1ce6da8d04a0','{"\\F":"agreed","\\G":"g4"}','[]',0,'25e41f7467cb1309e9d504f0f0e0fb8e2718fae81f89a422710309f39e4e6827');
INSERT INTO "math_macro_contexts" VALUES('math-64fe7c86b54dce815cbb1a9b','{"\\F":"fourth","\\G":"g4"}','["Conflicting anchored document macro contexts; checks are held"]',1,'bb3cf155a7707bf4d9e83bca166a4fa94576cff04e1991b48912d19fe3eca920');
INSERT INTO "math_macro_contexts" VALUES('math-771bf61bb9f3edda455d8281','{"\\F":"fourth","\\G":"g4"}','["Anchored macro context is unknown; checks are held"]',1,'6087d4e3dbfa3ffd6fbb7380d28066d3e9a5a27dc69a66a7bf110a921d5ac078');
INSERT INTO "math_macro_contexts" VALUES('math-f2a183c656b51c5b92457c9f','{"\\F":"agreed","\\G":"g4"}','[]',0,'8e95e06b78876b3d2cfe9310d1363d6c972131acffe5c76cf1c0d8f3ae1409ae');
INSERT INTO "math_macro_contexts" VALUES('math-b59ccb1495d1d5e8aae71190','{"\\F":"first","\\G":"g4"}','[]',0,'508b6a921beea0501615f8a74400ca155479fc423d9150551d711948e143d5e8');
INSERT INTO "math_macro_contexts" VALUES('math-e79382c1c1593b3b340b5757','{"\\F":"first","\\G":"g4"}','[]',0,'508b6a921beea0501615f8a74400ca155479fc423d9150551d711948e143d5e8');
INSERT INTO "math_macro_contexts" VALUES('math-f4d01318b3533f2235bcf545','{"\\F":"sixth","\\H":"h"}','[]',0,'3ee5e4e4f940325ee51b46b47002690e1140bdc5e4ff28e56a48e40e27bc9948');
INSERT INTO "math_macro_contexts" VALUES('math-104a8d905459fea011090c5a','{"\\F":"document","\\H":"h"}','[]',0,'b9bf63ea030b47469140bbaeac1136f6c70d5f1af9c6e8ad6de87bf8a0cdc310');
INSERT INTO "math_macro_contexts" VALUES('math-9f4b208e7f95aa84a308e7b1','{"\\F":"agreed","\\H":"h"}','[]',0,'696fe8254508e9633c89c8599917ed5829987ab16128d5d6fdf36096fe33b534');
INSERT INTO "math_macro_contexts" VALUES('math-590f73c3901ee70e6eb71b9a','{"\\F":"agreed","\\H":"h"}','[]',0,'696fe8254508e9633c89c8599917ed5829987ab16128d5d6fdf36096fe33b534');
INSERT INTO "math_macro_contexts" VALUES('math-954ca7f3c9afcafdd85fd338','{"\\F":"one","\\H":"h"}','[]',0,'d3ad5e6653cd35f9c46da4e53f70c99942a38071f7dce8623f801c29ffc9484c');
INSERT INTO "math_macro_contexts" VALUES('math-050520ea29b1158f437284df','{"\\F":"two","\\H":"h"}','[]',0,'590188edbe6c0aab16b7e15d0b3faf2e0321fd61373c4fb03e6fdae6e71c1835');
INSERT INTO "math_macro_contexts" VALUES('math-25eb8c0b753beba4f0a85a77','{"\\F":"agreed","\\H":"h"}','[]',0,'696fe8254508e9633c89c8599917ed5829987ab16128d5d6fdf36096fe33b534');
INSERT INTO "math_macro_contexts" VALUES('math-55a856f2cfa6cdf0dc8ffcc7','{"\\F":"second","\\H":"h"}','[]',0,'af412a817ab18db84446f13cdc15bedd594dcf5b226fa3341032ef36a328d277');
INSERT INTO "math_macro_contexts" VALUES('math-1300bb97f6f90b0096106700','{"\\F":"document","\\H":"h"}','[]',0,'b9bf63ea030b47469140bbaeac1136f6c70d5f1af9c6e8ad6de87bf8a0cdc310');
INSERT INTO "math_macro_contexts" VALUES('math-7762893baa2559a0c1f6af96','{"\\F":"second","\\H":"h"}','[]',0,'af412a817ab18db84446f13cdc15bedd594dcf5b226fa3341032ef36a328d277');
INSERT INTO "math_macro_contexts" VALUES('math-b741b94af44bab1010cc993b','{"\\F":"agreed","\\H":"h"}','[]',0,'54ce5a3d41f0d5f22800c67ffab5937ca9ade11ace540e27a0c97f0b11a0967b');
INSERT INTO "math_macro_contexts" VALUES('math-b05363a5fd73028d3c970f17','{"\\F":"sixth","\\H":"h"}','["Conflicting anchored document macro contexts; checks are held"]',1,'f51215db35e35628bad41961a73dcd4e6c8b653514efe3eeb268c9968d043e5f');
INSERT INTO "math_macro_contexts" VALUES('math-285001889502f84ad18493f9','{"\\F":"sixth","\\H":"h"}','["Anchored macro context is unknown; checks are held"]',1,'fdaf8812aeafc8c20494815bc0903294f182a9ff8c87db04cf53dc2c31096f2f');
INSERT INTO "math_macro_contexts" VALUES('math-68552ac718d6b1250e181062','{"\\F":"agreed","\\H":"h"}','[]',0,'5c6ecd7c9330a2d5ccd8303f6558e01a3adf1a0cac20132e48d7fbfa65901417');
CREATE TABLE "math_macro_pins" (
    check_id TEXT PRIMARY KEY REFERENCES math_jobs(check_id),
    project TEXT NOT NULL CHECK (length(CAST(project AS BLOB)) BETWEEN 1 AND 128),
    revision INTEGER NOT NULL CHECK (revision BETWEEN 0 AND 999999999),
    sha256 TEXT NOT NULL CHECK (length(sha256) = 64 AND sha256 NOT GLOB '*[^0-9a-f]*'),
    anchors TEXT NOT NULL
        CHECK (json_valid(anchors) AND length(CAST(anchors AS BLOB)) <= 16384)) STRICT;
INSERT INTO "math_macro_pins" VALUES('math-c58332d069b276776d8206e1','p',1,'3f7e170e38f582d93104d7334a16e98aa56d349eb2bddce1502e653fccf58d0a','[]');
INSERT INTO "math_macro_pins" VALUES('math-50b2cd794ed66f760f8186a0','p',2,'93a9ac94c13b2fd3068b3ecb395aa68cbd46ddeaf15ef07e2978039b35ec32fb','[]');
INSERT INTO "math_macro_pins" VALUES('math-be63c39f5fbc76967857983f','p',3,'30eea47795ab01b9ae6346dc9e2725cf3e3ae71651fab537301d397257eb41c7','[]');
INSERT INTO "math_macro_pins" VALUES('math-e05e53133f4ac63bf05191db','p',3,'30eea47795ab01b9ae6346dc9e2725cf3e3ae71651fab537301d397257eb41c7','[]');
INSERT INTO "math_macro_pins" VALUES('math-e55948cc0e503b27d8e096ba','p',3,'30eea47795ab01b9ae6346dc9e2725cf3e3ae71651fab537301d397257eb41c7','[]');
INSERT INTO "math_macro_pins" VALUES('math-725e0c4be9f01e6202edd151','p',3,'30eea47795ab01b9ae6346dc9e2725cf3e3ae71651fab537301d397257eb41c7','[]');
INSERT INTO "math_macro_pins" VALUES('math-4e51caaff70e4f4990033cbc','p',3,'30eea47795ab01b9ae6346dc9e2725cf3e3ae71651fab537301d397257eb41c7','[]');
INSERT INTO "math_macro_pins" VALUES('math-ffa8255534cd5212292c57e1','p',3,'30eea47795ab01b9ae6346dc9e2725cf3e3ae71651fab537301d397257eb41c7','[]');
INSERT INTO "math_macro_pins" VALUES('math-9fc76a6a27d799da22e4d330','p',3,'30eea47795ab01b9ae6346dc9e2725cf3e3ae71651fab537301d397257eb41c7','[]');
INSERT INTO "math_macro_pins" VALUES('math-3f4bf88202a8d0787f10d6b3','p',3,'30eea47795ab01b9ae6346dc9e2725cf3e3ae71651fab537301d397257eb41c7','[]');
INSERT INTO "math_macro_pins" VALUES('math-21aa05cb516db0d8367d4cd2','p',3,'30eea47795ab01b9ae6346dc9e2725cf3e3ae71651fab537301d397257eb41c7','[{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99"},{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635"}]');
INSERT INTO "math_macro_pins" VALUES('math-654724b3c2bfa1b173f978da','p',3,'30eea47795ab01b9ae6346dc9e2725cf3e3ae71651fab537301d397257eb41c7','[{"document":"doc-ed8581e68ef9d205cd12249f","revision":1,"sha256":"cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9"},{"document":"doc-f51aef9e079c43038da9b3d0","revision":1,"sha256":"4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820"}]');
INSERT INTO "math_macro_pins" VALUES('math-fe9d5e3101b3bb69523754fa','p',3,'30eea47795ab01b9ae6346dc9e2725cf3e3ae71651fab537301d397257eb41c7','[{"unknown":true}]');
INSERT INTO "math_macro_pins" VALUES('math-f71b32f4548e92552136c064','p',3,'30eea47795ab01b9ae6346dc9e2725cf3e3ae71651fab537301d397257eb41c7','[{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635"},{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3"}]');
INSERT INTO "math_macro_pins" VALUES('math-ef2c3ae78cbce2dee9b77890','p',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb','[]');
INSERT INTO "math_macro_pins" VALUES('math-7cc44edc39f4c1a348d4bf46','p',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb','[]');
INSERT INTO "math_macro_pins" VALUES('math-1a8ebabdebcbd8362898f86c','p',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb','[]');
INSERT INTO "math_macro_pins" VALUES('math-450892bbe5c5ab0fac83c7e5','p',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb','[]');
INSERT INTO "math_macro_pins" VALUES('math-bc33e7c5407f7311d58cb249','p',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb','[]');
INSERT INTO "math_macro_pins" VALUES('math-b2a2d22601de3c2359a26f5b','p',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb','[]');
INSERT INTO "math_macro_pins" VALUES('math-77a05068cac499fd9af80bfb','p',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb','[]');
INSERT INTO "math_macro_pins" VALUES('math-942d8f9197b742c34c7c3a47','p',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb','[]');
INSERT INTO "math_macro_pins" VALUES('math-d0d12b565bdb1ce6da8d04a0','p',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb','[{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99"},{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635"}]');
INSERT INTO "math_macro_pins" VALUES('math-64fe7c86b54dce815cbb1a9b','p',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb','[{"document":"doc-ed8581e68ef9d205cd12249f","revision":1,"sha256":"cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9"},{"document":"doc-f51aef9e079c43038da9b3d0","revision":1,"sha256":"4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820"}]');
INSERT INTO "math_macro_pins" VALUES('math-771bf61bb9f3edda455d8281','p',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb','[{"unknown":true}]');
INSERT INTO "math_macro_pins" VALUES('math-f2a183c656b51c5b92457c9f','p',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb','[{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635"},{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3"}]');
INSERT INTO "math_macro_pins" VALUES('math-b59ccb1495d1d5e8aae71190','p',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb','[]');
INSERT INTO "math_macro_pins" VALUES('math-e79382c1c1593b3b340b5757','p',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb','[]');
INSERT INTO "math_macro_pins" VALUES('math-f4d01318b3533f2235bcf545','p',5,'6b86f5562310ef17edfdbb3129a5f698168be43b58d21f27fe48a2792d028ae2','[]');
INSERT INTO "math_macro_pins" VALUES('math-104a8d905459fea011090c5a','p',5,'6b86f5562310ef17edfdbb3129a5f698168be43b58d21f27fe48a2792d028ae2','[]');
INSERT INTO "math_macro_pins" VALUES('math-9f4b208e7f95aa84a308e7b1','p',5,'6b86f5562310ef17edfdbb3129a5f698168be43b58d21f27fe48a2792d028ae2','[]');
INSERT INTO "math_macro_pins" VALUES('math-590f73c3901ee70e6eb71b9a','p',5,'6b86f5562310ef17edfdbb3129a5f698168be43b58d21f27fe48a2792d028ae2','[]');
INSERT INTO "math_macro_pins" VALUES('math-954ca7f3c9afcafdd85fd338','p',5,'6b86f5562310ef17edfdbb3129a5f698168be43b58d21f27fe48a2792d028ae2','[]');
INSERT INTO "math_macro_pins" VALUES('math-050520ea29b1158f437284df','p',5,'6b86f5562310ef17edfdbb3129a5f698168be43b58d21f27fe48a2792d028ae2','[]');
INSERT INTO "math_macro_pins" VALUES('math-25eb8c0b753beba4f0a85a77','p',5,'6b86f5562310ef17edfdbb3129a5f698168be43b58d21f27fe48a2792d028ae2','[]');
INSERT INTO "math_macro_pins" VALUES('math-55a856f2cfa6cdf0dc8ffcc7','p',5,'6b86f5562310ef17edfdbb3129a5f698168be43b58d21f27fe48a2792d028ae2','[]');
INSERT INTO "math_macro_pins" VALUES('math-1300bb97f6f90b0096106700','p',5,'6b86f5562310ef17edfdbb3129a5f698168be43b58d21f27fe48a2792d028ae2','[]');
INSERT INTO "math_macro_pins" VALUES('math-7762893baa2559a0c1f6af96','p',5,'6b86f5562310ef17edfdbb3129a5f698168be43b58d21f27fe48a2792d028ae2','[]');
INSERT INTO "math_macro_pins" VALUES('math-b741b94af44bab1010cc993b','p',5,'6b86f5562310ef17edfdbb3129a5f698168be43b58d21f27fe48a2792d028ae2','[{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99"},{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635"}]');
INSERT INTO "math_macro_pins" VALUES('math-b05363a5fd73028d3c970f17','p',5,'6b86f5562310ef17edfdbb3129a5f698168be43b58d21f27fe48a2792d028ae2','[{"document":"doc-ed8581e68ef9d205cd12249f","revision":1,"sha256":"cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9"},{"document":"doc-f51aef9e079c43038da9b3d0","revision":1,"sha256":"4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820"}]');
INSERT INTO "math_macro_pins" VALUES('math-285001889502f84ad18493f9','p',5,'6b86f5562310ef17edfdbb3129a5f698168be43b58d21f27fe48a2792d028ae2','[{"unknown":true}]');
INSERT INTO "math_macro_pins" VALUES('math-68552ac718d6b1250e181062','p',5,'6b86f5562310ef17edfdbb3129a5f698168be43b58d21f27fe48a2792d028ae2','[{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635"},{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3"}]');
INSERT INTO "math_macro_pins" VALUES('math-7700bf54c54457cd99a84bc9','p',6,'d42ccf79826b21962e26d456dd3cb5ae21b8d52cd1e7bfb2b8ee70a33df80b33','[]');
CREATE TABLE math_notices (
    finding_id TEXT NOT NULL, revision INTEGER NOT NULL, project TEXT NOT NULL,
    session TEXT NOT NULL, authored_run TEXT, claimed_run TEXT, claim_until REAL,
    delivered_run TEXT, PRIMARY KEY(finding_id,revision)) STRICT;
INSERT INTO "math_notices" VALUES('finding-fc52622e4f87078760aa6f5e',1,'p','s','r1',NULL,NULL,NULL);
INSERT INTO "math_notices" VALUES('finding-e157e420507d284c5f22e341',1,'p','s','r1',NULL,NULL,NULL);
INSERT INTO "math_notices" VALUES('finding-fc52622e4f87078760aa6f5e',2,'p','s','r1',NULL,NULL,NULL);
INSERT INTO "math_notices" VALUES('finding-e157e420507d284c5f22e341',2,'p','s','r1',NULL,NULL,NULL);
INSERT INTO "math_notices" VALUES('finding-fc52622e4f87078760aa6f5e',3,'p','s','r1',NULL,NULL,NULL);
INSERT INTO "math_notices" VALUES('finding-e157e420507d284c5f22e341',3,'p','s','r1',NULL,NULL,NULL);
INSERT INTO "math_notices" VALUES('finding-917db304507211c7b1843d18',1,'p','s','r1',NULL,NULL,NULL);
INSERT INTO "math_notices" VALUES('finding-f65c492ad291fed66c0bebfc',1,'p','s','r1',NULL,NULL,NULL);
INSERT INTO "math_notices" VALUES('finding-fc52622e4f87078760aa6f5e',5,'p','s','r1',NULL,NULL,NULL);
INSERT INTO "math_notices" VALUES('finding-e157e420507d284c5f22e341',5,'p','s','r1',NULL,NULL,NULL);
INSERT INTO "math_notices" VALUES('finding-76a488db1f7ed0dbeefce52d',1,'p','s','r1',NULL,NULL,NULL);
INSERT INTO "math_notices" VALUES('finding-3cd95b5b437e2f443a804203',1,'p','s','r1',NULL,NULL,NULL);
INSERT INTO "math_notices" VALUES('finding-f65c492ad291fed66c0bebfc',2,'p','s','r1',NULL,NULL,NULL);
INSERT INTO "math_notices" VALUES('finding-dd5709e9bc7427195c843f29',1,'p','s','r1',NULL,NULL,NULL);
INSERT INTO "math_notices" VALUES('finding-c18690edcf3ea6b28d2346a6',1,'p','s','r1',NULL,NULL,NULL);
CREATE TABLE "math_observations" (
    check_id TEXT NOT NULL REFERENCES math_jobs(check_id),
    ordinal INTEGER NOT NULL CHECK (ordinal >= 0),
    block TEXT NOT NULL, span TEXT NOT NULL,
    input_sha256 TEXT NOT NULL,
    status TEXT NOT NULL,
    payload TEXT NOT NULL
        CHECK (json_valid(payload) AND length(CAST(payload AS BLOB)) <= 32768),
    bytes INTEGER NOT NULL CHECK (bytes >= 0),
    PRIMARY KEY(check_id,ordinal)) STRICT;
INSERT INTO "math_observations" VALUES('math-c58332d069b276776d8206e1',0,'b1','m1','9fca59468bb50d041730c1ab6b7eb32656829a0f8149cde1b4ddfc83c74039c7','rejected','{"block":"b1","span":"m1","owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"rejected","error":"Unknown command","remedy":"x","input_sha256":"9fca59468bb50d041730c1ab6b7eb32656829a0f8149cde1b4ddfc83c74039c7","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',680);
INSERT INTO "math_observations" VALUES('math-c58332d069b276776d8206e1',1,'b1','m2','affc5f33affc0196e17c952d697d83a75596980fa3970c08dfaf1bd342781ae5','rejected','{"block":"b1","span":"m2","owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m2","status":"rejected","error":"Unknown command","remedy":"x","input_sha256":"affc5f33affc0196e17c952d697d83a75596980fa3970c08dfaf1bd342781ae5","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',680);
INSERT INTO "math_observations" VALUES('math-50b2cd794ed66f760f8186a0',0,'b1','m1','9ed02823654eb680e4595c11bc72502fd55ed41171f6ca146f2a694c2717bb99','rejected','{"block":"b1","span":"m1","owner":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"rejected","error":"Unknown command","remedy":"x","input_sha256":"9ed02823654eb680e4595c11bc72502fd55ed41171f6ca146f2a694c2717bb99","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',680);
INSERT INTO "math_observations" VALUES('math-50b2cd794ed66f760f8186a0',1,'b1','m2','2e9aca2b0f9dd83c10f218a99c945365157ad3c51b61c81539b0eae6c0410d26','rejected','{"block":"b1","span":"m2","owner":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m2","status":"rejected","error":"Unknown command","remedy":"x","input_sha256":"2e9aca2b0f9dd83c10f218a99c945365157ad3c51b61c81539b0eae6c0410d26","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',680);
INSERT INTO "math_observations" VALUES('math-be63c39f5fbc76967857983f',0,'b1','m1','e0c338a2b0761336496b87d69d19bedba301527421b3688126413be563152191','rejected','{"block":"b1","span":"m1","owner":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"rejected","error":"Unknown command","remedy":"x","input_sha256":"e0c338a2b0761336496b87d69d19bedba301527421b3688126413be563152191","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',680);
INSERT INTO "math_observations" VALUES('math-be63c39f5fbc76967857983f',1,'b1','m2','5526b848eea6baffd71cbea1c32ae0322a95d2ba312cc2883ef51ba6a58cdba6','rejected','{"block":"b1","span":"m2","owner":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m2","status":"rejected","error":"Unknown command","remedy":"x","input_sha256":"5526b848eea6baffd71cbea1c32ae0322a95d2ba312cc2883ef51ba6a58cdba6","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',680);
INSERT INTO "math_observations" VALUES('math-e05e53133f4ac63bf05191db',0,'b2','m1','f317a71bd1ab3c797f924a0838cc3d962706833649af88bce7db99489785e607','accepted','{"block":"b2","span":"m1","owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"accepted","error":null,"remedy":null,"input_sha256":"f317a71bd1ab3c797f924a0838cc3d962706833649af88bce7db99489785e607","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',668);
INSERT INTO "math_observations" VALUES('math-e55948cc0e503b27d8e096ba',0,'b1','m1','31561acdc95043af244e425c9775bc4e6396f3568e45bec9b6c5983bf7654ac3','accepted','{"block":"b1","span":"m1","owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"accepted","error":null,"remedy":null,"input_sha256":"31561acdc95043af244e425c9775bc4e6396f3568e45bec9b6c5983bf7654ac3","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',668);
INSERT INTO "math_observations" VALUES('math-21aa05cb516db0d8367d4cd2',0,'b1','m1','2ac35daef02a692b0b0f4e4222f169db8c295c075f04975247f37d4dcc8dcc36','accepted','{"block":"b1","span":"m1","owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"accepted","error":null,"remedy":null,"input_sha256":"2ac35daef02a692b0b0f4e4222f169db8c295c075f04975247f37d4dcc8dcc36","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',668);
INSERT INTO "math_observations" VALUES('math-654724b3c2bfa1b173f978da',0,'b1','m1','28f45406539841bb532a44f741694239e191300702da3da3acd6728ffc0fe40e','unavailable','{"block":"b1","span":"m1","owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"unavailable","error":"macro context unknown or ambiguous","remedy":null,"input_sha256":"28f45406539841bb532a44f741694239e191300702da3da3acd6728ffc0fe40e","bundle_sha256":null,"launcher_sha256":null,"engine":null,"runtime":null}}',571);
INSERT INTO "math_observations" VALUES('math-fe9d5e3101b3bb69523754fa',0,'b1','m1','28f45406539841bb532a44f741694239e191300702da3da3acd6728ffc0fe40e','unavailable','{"block":"b1","span":"m1","owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"unavailable","error":"macro context unknown or ambiguous","remedy":null,"input_sha256":"28f45406539841bb532a44f741694239e191300702da3da3acd6728ffc0fe40e","bundle_sha256":null,"launcher_sha256":null,"engine":null,"runtime":null}}',571);
INSERT INTO "math_observations" VALUES('math-f71b32f4548e92552136c064',0,'b1','m1','2ac35daef02a692b0b0f4e4222f169db8c295c075f04975247f37d4dcc8dcc36','accepted','{"block":"b1","span":"m1","owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"accepted","error":null,"remedy":null,"input_sha256":"2ac35daef02a692b0b0f4e4222f169db8c295c075f04975247f37d4dcc8dcc36","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',668);
INSERT INTO "math_observations" VALUES('math-ef2c3ae78cbce2dee9b77890',0,'b1','m1','a798dd08c26c23ac7570bd94d68a4015206427686bedddfba8e438566815c5b0','accepted','{"block":"b1","span":"m1","owner":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"accepted","error":null,"remedy":null,"input_sha256":"a798dd08c26c23ac7570bd94d68a4015206427686bedddfba8e438566815c5b0","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',668);
INSERT INTO "math_observations" VALUES('math-ef2c3ae78cbce2dee9b77890',1,'b1','m2','495e1050884b02d28b596d7e9ab25b355cf34b9231caacc01bb89f384f88eb53','accepted','{"block":"b1","span":"m2","owner":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m2","status":"accepted","error":null,"remedy":null,"input_sha256":"495e1050884b02d28b596d7e9ab25b355cf34b9231caacc01bb89f384f88eb53","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',668);
INSERT INTO "math_observations" VALUES('math-7cc44edc39f4c1a348d4bf46',0,'b2','m1','d41df215eb5764c06767ddd6c93bf9d9fed9b39b459a6b2703a5382db28ee2e8','accepted','{"block":"b2","span":"m1","owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"accepted","error":null,"remedy":null,"input_sha256":"d41df215eb5764c06767ddd6c93bf9d9fed9b39b459a6b2703a5382db28ee2e8","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',668);
INSERT INTO "math_observations" VALUES('math-942d8f9197b742c34c7c3a47',0,'b1','m1','b215a6139c0c5ff298af202dba628db98d62dc24afa1f816b425de7a8cb3ce55','accepted','{"block":"b1","span":"m1","owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"accepted","error":null,"remedy":null,"input_sha256":"b215a6139c0c5ff298af202dba628db98d62dc24afa1f816b425de7a8cb3ce55","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',668);
INSERT INTO "math_observations" VALUES('math-d0d12b565bdb1ce6da8d04a0',0,'b1','m1','8705959d6bb9f8bb7b15f8059c21d84a38f51a7437d85eeb29113d86b889cecb','accepted','{"block":"b1","span":"m1","owner":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"accepted","error":null,"remedy":null,"input_sha256":"8705959d6bb9f8bb7b15f8059c21d84a38f51a7437d85eeb29113d86b889cecb","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',668);
INSERT INTO "math_observations" VALUES('math-64fe7c86b54dce815cbb1a9b',0,'b1','m1','4c985080fa5a090512c8ab9d4f921da0fbcb714cb5e2632d0c2ef85b96b556f5','unavailable','{"block":"b1","span":"m1","owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"unavailable","error":"macro context unknown or ambiguous","remedy":null,"input_sha256":"4c985080fa5a090512c8ab9d4f921da0fbcb714cb5e2632d0c2ef85b96b556f5","bundle_sha256":null,"launcher_sha256":null,"engine":null,"runtime":null}}',571);
INSERT INTO "math_observations" VALUES('math-771bf61bb9f3edda455d8281',0,'b1','m1','c4d6c2a134dab359546543580cee176177fda16af2a6bd025ccd3853299ff344','unavailable','{"block":"b1","span":"m1","owner":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"unavailable","error":"macro context unknown or ambiguous","remedy":null,"input_sha256":"c4d6c2a134dab359546543580cee176177fda16af2a6bd025ccd3853299ff344","bundle_sha256":null,"launcher_sha256":null,"engine":null,"runtime":null}}',571);
INSERT INTO "math_observations" VALUES('math-f2a183c656b51c5b92457c9f',0,'b1','m1','25a47eecda6298b9d1fe165e9b6b782f4f227c0ac6563d9dfcd27bb9606394e0','accepted','{"block":"b1","span":"m1","owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"accepted","error":null,"remedy":null,"input_sha256":"25a47eecda6298b9d1fe165e9b6b782f4f227c0ac6563d9dfcd27bb9606394e0","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',668);
INSERT INTO "math_observations" VALUES('math-b59ccb1495d1d5e8aae71190',0,'b2','m1','abc00b174b9fcf95cf69b498eca74dddf76904cd26d954a68b08f21af7b43c77','rejected','{"block":"b2","span":"m1","owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"rejected","error":"Unknown command","remedy":"x","input_sha256":"abc00b174b9fcf95cf69b498eca74dddf76904cd26d954a68b08f21af7b43c77","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',680);
INSERT INTO "math_observations" VALUES('math-e79382c1c1593b3b340b5757',0,'b1','m1','cfec0d013a27b55993eb4aaf469da50cdfbd561b329fb642634b490159b59704','rejected','{"block":"b1","span":"m1","owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"rejected","error":"Unknown command","remedy":"x","input_sha256":"cfec0d013a27b55993eb4aaf469da50cdfbd561b329fb642634b490159b59704","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',680);
INSERT INTO "math_observations" VALUES('math-f4d01318b3533f2235bcf545',0,'b1','m1','50bcae3d15131f840beb8ff69195af635d1004318adcbb2c933b46ce633ce405','rejected','{"block":"b1","span":"m1","owner":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"rejected","error":"Unknown command","remedy":"x","input_sha256":"50bcae3d15131f840beb8ff69195af635d1004318adcbb2c933b46ce633ce405","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',680);
INSERT INTO "math_observations" VALUES('math-f4d01318b3533f2235bcf545',1,'b1','m2','88657fac26e0373e0938758cf703d394b50659db696a79e24fc3b252ce40fb57','rejected','{"block":"b1","span":"m2","owner":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m2","status":"rejected","error":"Unknown command","remedy":"x","input_sha256":"88657fac26e0373e0938758cf703d394b50659db696a79e24fc3b252ce40fb57","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',680);
INSERT INTO "math_observations" VALUES('math-104a8d905459fea011090c5a',0,'b2','m1','76592bff58fd06318ae2b98420c119e8bb3335a62749aa630e6fe2ba87b57699','rejected','{"block":"b2","span":"m1","owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"rejected","error":"Unknown command","remedy":"x","input_sha256":"76592bff58fd06318ae2b98420c119e8bb3335a62749aa630e6fe2ba87b57699","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',680);
INSERT INTO "math_observations" VALUES('math-55a856f2cfa6cdf0dc8ffcc7',0,'b2','m1','bff92f5bc215af1a9ed1650357fac084dc9ca203c17564dd57a160c2c8b1b068','rejected','{"block":"b2","span":"m1","owner":{"revision":2,"author":{"kind":"user","user":"user","session_id":null,"run_id":null,"role":null,"model":null,"alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"rejected","error":"Unknown command","remedy":"x","input_sha256":"bff92f5bc215af1a9ed1650357fac084dc9ca203c17564dd57a160c2c8b1b068","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',674);
INSERT INTO "math_observations" VALUES('math-1300bb97f6f90b0096106700',0,'b1','m1','cb15b3dc5ff1239fcc0eac1b0845abf66299ba7387758c569ee12e021195e03c','rejected','{"block":"b1","span":"m1","owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"rejected","error":"Unknown command","remedy":"x","input_sha256":"cb15b3dc5ff1239fcc0eac1b0845abf66299ba7387758c569ee12e021195e03c","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',680);
INSERT INTO "math_observations" VALUES('math-7762893baa2559a0c1f6af96',0,'b1','m1','0ed7d468b5b0092060dd99f988837bf628d784d27a2b9cd5b2f48af7e5a1eeca','rejected','{"block":"b1","span":"m1","owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"rejected","error":"Unknown command","remedy":"x","input_sha256":"0ed7d468b5b0092060dd99f988837bf628d784d27a2b9cd5b2f48af7e5a1eeca","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',680);
INSERT INTO "math_observations" VALUES('math-b741b94af44bab1010cc993b',0,'b1','m1','6e334d938d322b0f52c8d09c17fb9993a03d45c6e4a00d60d3666a9d375dab54','rejected','{"block":"b1","span":"m1","owner":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"rejected","error":"Unknown command","remedy":"x","input_sha256":"6e334d938d322b0f52c8d09c17fb9993a03d45c6e4a00d60d3666a9d375dab54","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',680);
INSERT INTO "math_observations" VALUES('math-b05363a5fd73028d3c970f17',0,'b1','m1','a3fbc2a45e13e4ca47e6b6791841ec473eb8a1632700c7cc51af1b764b1aa8fc','unavailable','{"block":"b1","span":"m1","owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"unavailable","error":"macro context unknown or ambiguous","remedy":null,"input_sha256":"a3fbc2a45e13e4ca47e6b6791841ec473eb8a1632700c7cc51af1b764b1aa8fc","bundle_sha256":null,"launcher_sha256":null,"engine":null,"runtime":null}}',571);
INSERT INTO "math_observations" VALUES('math-285001889502f84ad18493f9',0,'b1','m1','7963dc182d4fcfb4c9b4bb1f09f870466da7faeba37b1d20323c92c9d7fa407c','unavailable','{"block":"b1","span":"m1","owner":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"unavailable","error":"macro context unknown or ambiguous","remedy":null,"input_sha256":"7963dc182d4fcfb4c9b4bb1f09f870466da7faeba37b1d20323c92c9d7fa407c","bundle_sha256":null,"launcher_sha256":null,"engine":null,"runtime":null}}',571);
INSERT INTO "math_observations" VALUES('math-68552ac718d6b1250e181062',0,'b1','m1','7bf4bfe090decdd55f38a4f3e187206bd47e12097914d77e663d6aa600b179e4','rejected','{"block":"b1","span":"m1","owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"check":{"id":"m1","status":"rejected","error":"Unknown command","remedy":"x","input_sha256":"7bf4bfe090decdd55f38a4f3e187206bd47e12097914d77e663d6aa600b179e4","bundle_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","launcher_sha256":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","engine":"0.18.9","runtime":"22.0.0"}}',680);
CREATE TABLE "math_response_jobs" (
    check_id TEXT PRIMARY KEY REFERENCES math_jobs(check_id),
    source TEXT NOT NULL REFERENCES response_math_sources(source)) STRICT;
INSERT INTO "math_response_jobs" VALUES('math-21aa05cb516db0d8367d4cd2','response:finding-da4788c18fb518061f270269:r2:explanation');
INSERT INTO "math_response_jobs" VALUES('math-654724b3c2bfa1b173f978da','response:finding-5b46fc960bd07409ddc5e6d6:r2:explanation');
INSERT INTO "math_response_jobs" VALUES('math-fe9d5e3101b3bb69523754fa','response:finding-2035ab2709c5671355e3f59f:r2:explanation');
INSERT INTO "math_response_jobs" VALUES('math-f71b32f4548e92552136c064','response:finding-440cc2bad6a1de3ea75400d0:r2:explanation');
INSERT INTO "math_response_jobs" VALUES('math-d0d12b565bdb1ce6da8d04a0','response:finding-da4788c18fb518061f270269:r2:explanation');
INSERT INTO "math_response_jobs" VALUES('math-64fe7c86b54dce815cbb1a9b','response:finding-5b46fc960bd07409ddc5e6d6:r2:explanation');
INSERT INTO "math_response_jobs" VALUES('math-771bf61bb9f3edda455d8281','response:finding-2035ab2709c5671355e3f59f:r2:explanation');
INSERT INTO "math_response_jobs" VALUES('math-f2a183c656b51c5b92457c9f','response:finding-440cc2bad6a1de3ea75400d0:r2:explanation');
INSERT INTO "math_response_jobs" VALUES('math-b741b94af44bab1010cc993b','response:finding-da4788c18fb518061f270269:r2:explanation');
INSERT INTO "math_response_jobs" VALUES('math-b05363a5fd73028d3c970f17','response:finding-5b46fc960bd07409ddc5e6d6:r2:explanation');
INSERT INTO "math_response_jobs" VALUES('math-285001889502f84ad18493f9','response:finding-2035ab2709c5671355e3f59f:r2:explanation');
INSERT INTO "math_response_jobs" VALUES('math-68552ac718d6b1250e181062','response:finding-440cc2bad6a1de3ea75400d0:r2:explanation');
CREATE TABLE "math_sources" (
    document TEXT PRIMARY KEY REFERENCES documents(document_id),
    project TEXT NOT NULL CHECK (length(CAST(project AS BLOB)) BETWEEN 1 AND 128),
    target INTEGER NOT NULL CHECK (target BETWEEN 0 AND 999999999),
    completed INTEGER NOT NULL DEFAULT 0 CHECK (completed BETWEEN 0 AND 999999999),
    blocked TEXT CHECK (blocked IS NULL OR length(CAST(blocked AS BLOB)) <= 4096),
    retry_requested INTEGER NOT NULL DEFAULT 0 CHECK (retry_requested IN (0, 1))) STRICT;
INSERT INTO "math_sources" VALUES('doc-58b9197efd52aaaaf2628f77','p',2,2,NULL,0);
INSERT INTO "math_sources" VALUES('doc-1e4f0c5c2e394387ce7165fe','p',1,1,NULL,1);
INSERT INTO "math_sources" VALUES('doc-0f819e0cfea434b82ffc8823','p',1,1,NULL,1);
INSERT INTO "math_sources" VALUES('doc-adf74e15920f0fb47c0a88f1','p',1,1,NULL,1);
INSERT INTO "math_sources" VALUES('doc-ed8581e68ef9d205cd12249f','p',1,1,NULL,1);
INSERT INTO "math_sources" VALUES('doc-f51aef9e079c43038da9b3d0','p',1,1,NULL,1);
INSERT INTO "math_sources" VALUES('doc-dbd8ffaf1480d8b94d29e9ae','p',1,1,NULL,1);
INSERT INTO "math_sources" VALUES('doc-6d5d225787c1ec2d34b50b21','p',2,2,NULL,1);
CREATE TABLE patches (
    patch_id TEXT PRIMARY KEY,
    document_id TEXT NOT NULL REFERENCES documents (document_id),
    created_at TEXT NOT NULL,
    author TEXT NOT NULL,
    session_id TEXT,
    base INTEGER NOT NULL,
    reason TEXT NOT NULL,
    operations TEXT NOT NULL,
    state TEXT NOT NULL,
    revision INTEGER,
    details TEXT NOT NULL,
    decided_at TEXT,
    decided_by TEXT
) STRICT;
INSERT INTO "patches" VALUES('patch-6c88bc51286db1b1bcceaa9d','doc-58b9197efd52aaaaf2628f77','2026-10-14T20:31:25.108611+00:00','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}','s',1,'Edit formula','[{"op":"replace_math","math":"m1","tex":"\\unknown{y}"}]','applied',2,'{}',NULL,NULL);
CREATE TABLE project_budgets (
    project_id TEXT PRIMARY KEY REFERENCES projects (project_id),
    main_tokens INTEGER NOT NULL CHECK (main_tokens BETWEEN 0 AND 1000000000000),
    updated_at TEXT NOT NULL
) STRICT;
CREATE TABLE project_macro_heads (
    project TEXT PRIMARY KEY,revision INTEGER NOT NULL) STRICT;
INSERT INTO "project_macro_heads" VALUES('p',6);
CREATE TABLE "project_macro_operations" (
    project TEXT NOT NULL, actor TEXT NOT NULL, operation TEXT NOT NULL,
    fingerprint TEXT NOT NULL
        CHECK (length(fingerprint) = 64 AND fingerprint NOT GLOB '*[^0-9a-f]*'),
    revision INTEGER NOT NULL CHECK (revision BETWEEN 0 AND 999999999),
    PRIMARY KEY(project,actor,operation)) STRICT;
INSERT INTO "project_macro_operations" VALUES('p','user:user','m0','0af3f261f2b65ca571033668f71d5c4c6cc2bb0c41ca466c2594a4783feb055a',1);
INSERT INTO "project_macro_operations" VALUES('p','user:user','m1','3acdbefa3b784e9367255baf32c3697f76e79ed81b9bf161e019824857cb2f33',2);
INSERT INTO "project_macro_operations" VALUES('p','user:user','m2','0c50163863abfac21ea659808605f902934c803f611af26d30b249dccbca64cc',3);
INSERT INTO "project_macro_operations" VALUES('p','user:user','m3','03b4e81d683f9fc50c41e8053f6db5cc401ff66c2b02539d18f67e4055a1ff08',4);
INSERT INTO "project_macro_operations" VALUES('p','user:user','m4','038aeb36a3aa65a6913cbcfc6397155952eaace7ff0a6e3858718bc1866a76cb',5);
INSERT INTO "project_macro_operations" VALUES('p','user:user','m5','2106e04042689d6fada5b07ffabcb7930fb4263ac8c9fce7619ea19184c30e03',6);
CREATE TABLE "project_macro_revisions" (
    project TEXT NOT NULL CHECK (length(CAST(project AS BLOB)) BETWEEN 1 AND 128),
    revision INTEGER NOT NULL CHECK (revision BETWEEN 1 AND 999999999),
    definitions TEXT NOT NULL
        CHECK (json_valid(definitions) AND length(CAST(definitions AS BLOB)) <= 16384),
    sha256 TEXT NOT NULL CHECK (length(sha256) = 64 AND sha256 NOT GLOB '*[^0-9a-f]*'),
    author TEXT NOT NULL CHECK (json_valid(author)),
    PRIMARY KEY(project,revision)) STRICT;
INSERT INTO "project_macro_revisions" VALUES('p',1,'{"\\F":"before","\\G":"g"}','3f7e170e38f582d93104d7334a16e98aa56d349eb2bddce1502e653fccf58d0a','{"kind":"user","user":"user","session_id":null,"run_id":null,"role":null,"model":null,"alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
INSERT INTO "project_macro_revisions" VALUES('p',2,'{"\\F":"after","\\G":"g"}','93a9ac94c13b2fd3068b3ecb395aa68cbd46ddeaf15ef07e2978039b35ec32fb','{"kind":"user","user":"user","session_id":null,"run_id":null,"role":null,"model":null,"alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
INSERT INTO "project_macro_revisions" VALUES('p',3,'{"\\F":"third"}','30eea47795ab01b9ae6346dc9e2725cf3e3ae71651fab537301d397257eb41c7','{"kind":"user","user":"user","session_id":null,"run_id":null,"role":null,"model":null,"alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
INSERT INTO "project_macro_revisions" VALUES('p',4,'{"\\F":"fourth","\\G":"g4"}','53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb','{"kind":"user","user":"user","session_id":null,"run_id":null,"role":null,"model":null,"alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
INSERT INTO "project_macro_revisions" VALUES('p',5,'{"\\F":"sixth","\\H":"h"}','6b86f5562310ef17edfdbb3129a5f698168be43b58d21f27fe48a2792d028ae2','{"kind":"user","user":"user","session_id":null,"run_id":null,"role":null,"model":null,"alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
INSERT INTO "project_macro_revisions" VALUES('p',6,'{"\\F":"fifth"}','d42ccf79826b21962e26d456dd3cb5ae21b8d52cd1e7bfb2b8ee70a33df80b33','{"kind":"user","user":"user","session_id":null,"run_id":null,"role":null,"model":null,"alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}');
CREATE TABLE projects (
    project_id TEXT PRIMARY KEY,
    profile TEXT NOT NULL,
    policy TEXT NOT NULL,
    default_environment_id TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
) STRICT;
INSERT INTO "projects" VALUES('p','minimal','sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa','p-default-bb3128df104b','2026-10-14T20:31:25.096354Z','2026-10-14T20:31:25.096550Z');
CREATE TABLE requests (
    project_id TEXT NOT NULL,
    actor TEXT NOT NULL,
    operation_id TEXT NOT NULL,
    fingerprint TEXT NOT NULL,
    result TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (project_id, actor, operation_id)
) STRICT;
INSERT INTO "requests" VALUES('p','session:s','pa1','807daf8bfc21fbde4e8e5e9202517592c2539eb9b712225ecd68251623a319f8','{"outcome":"applied","document_id":"doc-58b9197efd52aaaaf2628f77","revision":2,"base":1,"applied_to":1,"rebased":false,"patch_id":"patch-6c88bc51286db1b1bcceaa9d","changes":{"changed":["b1"],"moved":[],"added":[],"removed":[],"math_changed":["m1"],"math_added":[],"math_removed":[]},"normalized":{"converted":{},"kept":[]},"warnings":[],"conflicts":[],"unnamed":[],"message":null,"replayed":false}','2026-10-14T20:31:25.108773+00:00');
CREATE TABLE "response_macro_anchors" (
    source TEXT PRIMARY KEY,
    anchors TEXT NOT NULL
        CHECK (json_valid(anchors) AND length(CAST(anchors AS BLOB)) <= 16384)) STRICT;
INSERT INTO "response_macro_anchors" VALUES('response:finding-da4788c18fb518061f270269:r2:explanation','[{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99"},{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635"}]');
INSERT INTO "response_macro_anchors" VALUES('response:finding-5b46fc960bd07409ddc5e6d6:r2:explanation','[{"document":"doc-ed8581e68ef9d205cd12249f","revision":1,"sha256":"cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9"},{"document":"doc-f51aef9e079c43038da9b3d0","revision":1,"sha256":"4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820"}]');
INSERT INTO "response_macro_anchors" VALUES('response:finding-440cc2bad6a1de3ea75400d0:r2:explanation','[{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635"},{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3"}]');
INSERT INTO "response_macro_anchors" VALUES('response:finding-2035ab2709c5671355e3f59f:r2:explanation','[{"unknown":true}]');
CREATE TABLE response_macro_revisions (
    source TEXT NOT NULL,body_revision INTEGER NOT NULL,project_revision INTEGER NOT NULL,
    PRIMARY KEY(source,body_revision)) STRICT;
INSERT INTO "response_macro_revisions" VALUES('response:finding-da4788c18fb518061f270269:r2:explanation',1,3);
INSERT INTO "response_macro_revisions" VALUES('response:finding-5b46fc960bd07409ddc5e6d6:r2:explanation',1,3);
INSERT INTO "response_macro_revisions" VALUES('response:finding-440cc2bad6a1de3ea75400d0:r2:explanation',1,3);
INSERT INTO "response_macro_revisions" VALUES('response:finding-da4788c18fb518061f270269:r2:explanation',2,3);
INSERT INTO "response_macro_revisions" VALUES('response:finding-2035ab2709c5671355e3f59f:r2:explanation',2,3);
CREATE TABLE "response_math_sources" (
    source TEXT PRIMARY KEY CHECK (length(CAST(source AS BLOB)) BETWEEN 1 AND 128),
    finding_id TEXT NOT NULL CHECK (length(CAST(finding_id AS BLOB)) BETWEEN 1 AND 128),
    decision_revision INTEGER NOT NULL CHECK (decision_revision BETWEEN 1 AND 999999999),
    project TEXT NOT NULL CHECK (length(CAST(project AS BLOB)) BETWEEN 1 AND 128),
    session TEXT NOT NULL CHECK (length(CAST(session AS BLOB)) BETWEEN 1 AND 128),
    target INTEGER NOT NULL CHECK (target BETWEEN 0 AND 999999999),
    completed INTEGER NOT NULL DEFAULT 0 CHECK (completed BETWEEN 0 AND 999999999),
    retry_requested INTEGER NOT NULL DEFAULT 0 CHECK (retry_requested IN (0, 1)),
    blocked TEXT CHECK (blocked IS NULL OR length(CAST(blocked AS BLOB)) <= 4096),
    UNIQUE(finding_id,decision_revision),
    FOREIGN KEY(finding_id,decision_revision) REFERENCES review_transitions(finding_id,revision))
    STRICT;
INSERT INTO "response_math_sources" VALUES('response:finding-da4788c18fb518061f270269:r2:explanation','finding-da4788c18fb518061f270269',2,'p','s',2,2,1,NULL);
INSERT INTO "response_math_sources" VALUES('response:finding-5b46fc960bd07409ddc5e6d6:r2:explanation','finding-5b46fc960bd07409ddc5e6d6',2,'p','s',1,1,1,NULL);
INSERT INTO "response_math_sources" VALUES('response:finding-2035ab2709c5671355e3f59f:r2:explanation','finding-2035ab2709c5671355e3f59f',2,'p','s',2,2,1,NULL);
INSERT INTO "response_math_sources" VALUES('response:finding-440cc2bad6a1de3ea75400d0:r2:explanation','finding-440cc2bad6a1de3ea75400d0',2,'p','s',1,1,1,NULL);
CREATE TABLE review_artifact_cursors (
    project TEXT NOT NULL,session TEXT NOT NULL,cursor INTEGER NOT NULL,
    PRIMARY KEY(project,session)) STRICT;
CREATE TABLE review_calls (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,project TEXT NOT NULL,review_id TEXT NOT NULL,
    created REAL NOT NULL,input_tokens INTEGER,output_tokens INTEGER,resolved_model TEXT,
    estimated_tokens INTEGER NOT NULL,answered INTEGER NOT NULL DEFAULT 0,
    prompt_provenance TEXT) STRICT;
CREATE TABLE review_config (
    project TEXT NOT NULL,number INTEGER NOT NULL,payload TEXT NOT NULL,created REAL NOT NULL,
    PRIMARY KEY(project,number)) STRICT;
CREATE TABLE review_confirmation_targets (
    review_id TEXT NOT NULL REFERENCES review_runs(review_id),finding_id TEXT NOT NULL,
    revision INTEGER NOT NULL,PRIMARY KEY(review_id,finding_id)) STRICT;
INSERT INTO "review_confirmation_targets" VALUES('rev-65b5b0f9e36fdb1b38fab4ca','finding-da4788c18fb518061f270269',2);
CREATE TABLE review_events (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,project TEXT NOT NULL,session TEXT NOT NULL,
    kind TEXT NOT NULL,payload TEXT NOT NULL,created REAL NOT NULL) STRICT;
INSERT INTO "review_events" VALUES(1,'p','s','finding.transitioned','{"finding":"finding-fc52622e4f87078760aa6f5e","status":"open","revision":1,"actor":"platform:math"}',1000.0);
INSERT INTO "review_events" VALUES(2,'p','s','finding.transitioned','{"finding":"finding-e157e420507d284c5f22e341","status":"open","revision":1,"actor":"platform:math"}',1000.0);
INSERT INTO "review_events" VALUES(3,'p','s','finding.transitioned','{"finding":"finding-fc52622e4f87078760aa6f5e","status":"open","revision":2,"actor":"platform:math"}',1000.0);
INSERT INTO "review_events" VALUES(4,'p','s','finding.transitioned','{"finding":"finding-e157e420507d284c5f22e341","status":"open","revision":2,"actor":"platform:math"}',1000.0);
INSERT INTO "review_events" VALUES(5,'p','s','finding.transitioned','{"finding":"finding-fc52622e4f87078760aa6f5e","status":"open","revision":3,"actor":"platform:math"}',1000.0);
INSERT INTO "review_events" VALUES(6,'p','s','finding.transitioned','{"finding":"finding-e157e420507d284c5f22e341","status":"open","revision":3,"actor":"platform:math"}',1000.0);
INSERT INTO "review_events" VALUES(7,'p','s','review.dispatched','{"review":"rev-42cd1418d0397f536f335de6","type":"terminal","start":1,"end":9}',1000.0);
INSERT INTO "review_events" VALUES(8,'p','s','finding.transitioned','{"finding":"finding-da4788c18fb518061f270269","status":"open","revision":1,"actor":"review:rev-42cd1418d0397f536f335de6"}',1000.0);
INSERT INTO "review_events" VALUES(9,'p','s','finding.created','{"finding":"finding-da4788c18fb518061f270269","review":"rev-42cd1418d0397f536f335de6","severity":"fail"}',1000.0);
INSERT INTO "review_events" VALUES(10,'p','s','finding.transitioned','{"finding":"finding-5b46fc960bd07409ddc5e6d6","status":"open","revision":1,"actor":"review:rev-42cd1418d0397f536f335de6"}',1000.0);
INSERT INTO "review_events" VALUES(11,'p','s','finding.created','{"finding":"finding-5b46fc960bd07409ddc5e6d6","review":"rev-42cd1418d0397f536f335de6","severity":"fail"}',1000.0);
INSERT INTO "review_events" VALUES(12,'p','s','finding.transitioned','{"finding":"finding-2035ab2709c5671355e3f59f","status":"open","revision":1,"actor":"review:rev-42cd1418d0397f536f335de6"}',1000.0);
INSERT INTO "review_events" VALUES(13,'p','s','finding.created','{"finding":"finding-2035ab2709c5671355e3f59f","review":"rev-42cd1418d0397f536f335de6","severity":"fail"}',1000.0);
INSERT INTO "review_events" VALUES(14,'p','s','finding.transitioned','{"finding":"finding-440cc2bad6a1de3ea75400d0","status":"open","revision":1,"actor":"review:rev-42cd1418d0397f536f335de6"}',1000.0);
INSERT INTO "review_events" VALUES(15,'p','s','finding.created','{"finding":"finding-440cc2bad6a1de3ea75400d0","review":"rev-42cd1418d0397f536f335de6","severity":"fail"}',1000.0);
INSERT INTO "review_events" VALUES(16,'p','s','review.ended','{"review":"rev-42cd1418d0397f536f335de6","outcome":"findings"}',1000.0);
INSERT INTO "review_events" VALUES(17,'p','s','finding.transitioned','{"finding":"finding-da4788c18fb518061f270269","status":"claimed fixed","revision":2,"actor":"session:s"}',1000.0);
INSERT INTO "review_events" VALUES(18,'p','s','finding.transitioned','{"finding":"finding-5b46fc960bd07409ddc5e6d6","status":"open","revision":2,"actor":"session:s"}',1000.0);
INSERT INTO "review_events" VALUES(19,'p','s','finding.transitioned','{"finding":"finding-2035ab2709c5671355e3f59f","status":"open","revision":2,"actor":"session:s"}',1000.0);
INSERT INTO "review_events" VALUES(20,'p','s','finding.transitioned','{"finding":"finding-440cc2bad6a1de3ea75400d0","status":"open","revision":2,"actor":"session:s"}',1000.0);
INSERT INTO "review_events" VALUES(21,'p','s','finding.transitioned','{"finding":"finding-fc52622e4f87078760aa6f5e","status":"confirmed fixed","revision":4,"actor":"platform:math"}',1000.0);
INSERT INTO "review_events" VALUES(22,'p','s','finding.transitioned','{"finding":"finding-e157e420507d284c5f22e341","status":"confirmed fixed","revision":4,"actor":"platform:math"}',1000.0);
INSERT INTO "review_events" VALUES(23,'p','s','review.dispatched','{"review":"rev-65b5b0f9e36fdb1b38fab4ca","type":"confirmation","start":10,"end":9}',1000.0);
INSERT INTO "review_events" VALUES(24,'p','s','finding.transitioned','{"finding":"finding-da4788c18fb518061f270269","status":"inconclusive","revision":3,"actor":"review:rev-65b5b0f9e36fdb1b38fab4ca"}',1000.0);
INSERT INTO "review_events" VALUES(25,'p','s','review.ended','{"review":"rev-65b5b0f9e36fdb1b38fab4ca","outcome":"findings"}',1000.0);
INSERT INTO "review_events" VALUES(26,'p','s','review.dispatched','{"review":"rev-1d606daeb93532ef94420dbe","type":"terminal","start":10,"end":11}',1000.0);
INSERT INTO "review_events" VALUES(27,'p','s','finding.transitioned','{"finding":"finding-440cc2bad6a1de3ea75400d0","status":"open","revision":3,"actor":"review:rev-1d606daeb93532ef94420dbe"}',1000.0);
INSERT INTO "review_events" VALUES(28,'p','s','finding.transitioned','{"finding":"finding-440cc2bad6a1de3ea75400d0","status":"unaddressed","revision":4,"actor":"review:rev-1d606daeb93532ef94420dbe"}',1000.0);
INSERT INTO "review_events" VALUES(29,'p','s','review.ended','{"review":"rev-1d606daeb93532ef94420dbe","outcome":"findings"}',1000.0);
INSERT INTO "review_events" VALUES(30,'p','s','finding.transitioned','{"finding":"finding-917db304507211c7b1843d18","status":"open","revision":1,"actor":"platform:math"}',1000.0);
INSERT INTO "review_events" VALUES(31,'p','s','finding.transitioned','{"finding":"finding-f65c492ad291fed66c0bebfc","status":"open","revision":1,"actor":"platform:math"}',1000.0);
INSERT INTO "review_events" VALUES(32,'p','s','finding.transitioned','{"finding":"finding-fc52622e4f87078760aa6f5e","status":"open","revision":5,"actor":"platform:math"}',1000.0);
INSERT INTO "review_events" VALUES(33,'p','s','finding.transitioned','{"finding":"finding-e157e420507d284c5f22e341","status":"open","revision":5,"actor":"platform:math"}',1000.0);
INSERT INTO "review_events" VALUES(34,'p','s','finding.transitioned','{"finding":"finding-76a488db1f7ed0dbeefce52d","status":"open","revision":1,"actor":"platform:math"}',1000.0);
INSERT INTO "review_events" VALUES(35,'p','s','finding.transitioned','{"finding":"finding-3cd95b5b437e2f443a804203","status":"open","revision":1,"actor":"platform:math"}',1000.0);
INSERT INTO "review_events" VALUES(36,'p','s','finding.transitioned','{"finding":"finding-f65c492ad291fed66c0bebfc","status":"open","revision":2,"actor":"platform:math"}',1000.0);
INSERT INTO "review_events" VALUES(37,'p','s','finding.transitioned','{"finding":"finding-dd5709e9bc7427195c843f29","status":"open","revision":1,"actor":"platform:math"}',1000.0);
INSERT INTO "review_events" VALUES(38,'p','s','finding.transitioned','{"finding":"finding-c18690edcf3ea6b28d2346a6","status":"open","revision":1,"actor":"platform:math"}',1000.0);
CREATE TABLE "review_evidence" (
    evidence_id TEXT PRIMARY KEY CHECK (length(CAST(evidence_id AS BLOB)) BETWEEN 1 AND 128),
    review_id TEXT NOT NULL REFERENCES review_runs(review_id),
    ordinal INTEGER NOT NULL CHECK (ordinal >= 0),
    kind TEXT NOT NULL CHECK (length(CAST(kind AS BLOB)) BETWEEN 1 AND 32),
    locator TEXT NOT NULL
        CHECK (json_valid(locator) AND length(CAST(locator AS BLOB)) <= 4096),
    payload TEXT NOT NULL
        CHECK (json_valid(payload) AND length(CAST(payload AS BLOB)) <= 262144),
    sha256 TEXT NOT NULL CHECK (length(sha256) = 64 AND sha256 NOT GLOB '*[^0-9a-f]*'),
    complete INTEGER NOT NULL CHECK (complete IN (0, 1)),
    UNIQUE(review_id,ordinal)) STRICT;
INSERT INTO "review_evidence" VALUES('ev-7dd898ee4c2dd72cad459cb2','rev-42cd1418d0397f536f335de6',1,'document','{"document":"doc-58b9197efd52aaaaf2628f77","revision":1,"sha256":"7fcace58933d4f12f56947f2b6ecadd1f90f62a88419d1efe1735389d1c2d2b9","run":"r1"}','{"document":"doc-58b9197efd52aaaaf2628f77","revision":1,"sha256":"7fcace58933d4f12f56947f2b6ecadd1f90f62a88419d1efe1735389d1c2d2b9","author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"reason":"created","tombstone":false}','2120ca96a25a502668aee7a76e085722a7cf7931236e04a26eedc4510d4066c9',1);
INSERT INTO "review_evidence" VALUES('ev-4203724848b6f48ce5555327','rev-42cd1418d0397f536f335de6',2,'document','{"document":"doc-58b9197efd52aaaaf2628f77","revision":2,"sha256":"ac6576e1e89ad370183e2dea65ddc756024b91f6dcb350cc8639e091be739f6b","run":"r1"}','{"document":"doc-58b9197efd52aaaaf2628f77","revision":2,"sha256":"ac6576e1e89ad370183e2dea65ddc756024b91f6dcb350cc8639e091be739f6b","author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"reason":"Edit formula","tombstone":false}','2a4e3c5841a635f0b3da1236c27357931f6f0866ab18d1f2ce5a719a9afe5166',1);
INSERT INTO "review_evidence" VALUES('ev-ff50c7902a5bc81fd6345375','rev-42cd1418d0397f536f335de6',3,'document','{"document":"doc-1e4f0c5c2e394387ce7165fe","revision":1,"sha256":"6c2dc0ee0ced3db7079f1f94ee41a9721245d43cae77a69bec8814c6eb4c91ab","run":"r1"}','{"document":"doc-1e4f0c5c2e394387ce7165fe","revision":1,"sha256":"6c2dc0ee0ced3db7079f1f94ee41a9721245d43cae77a69bec8814c6eb4c91ab","author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"reason":"created","tombstone":false}','76080fe70410fb024b3d47d4cfffd489bef5747561e08c6a3f5c161e36b07f60',1);
INSERT INTO "review_evidence" VALUES('ev-69d841962ddc04d16e727ebf','rev-42cd1418d0397f536f335de6',4,'document','{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99","run":"r1"}','{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99","author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"reason":"created","tombstone":false}','f6901ae1e9130504c9d85e01cf39d51913ebe2cf66742e51840ecd29ddae973c',1);
INSERT INTO "review_evidence" VALUES('ev-e515db78eaaa911eaf1aba99','rev-42cd1418d0397f536f335de6',5,'document','{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635","run":"r1"}','{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635","author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"reason":"created","tombstone":false}','e117b4634ffb48360158bb088f37593c19c9454ad868d2033544fc301aa1bf92',1);
INSERT INTO "review_evidence" VALUES('ev-a9ae4b84c830fe41295ae6f7','rev-42cd1418d0397f536f335de6',6,'document','{"document":"doc-ed8581e68ef9d205cd12249f","revision":1,"sha256":"cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9","run":"r1"}','{"document":"doc-ed8581e68ef9d205cd12249f","revision":1,"sha256":"cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9","author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"reason":"created","tombstone":false}','9a813d784f388e0c4b78d9959b901e82e03d2284bc64cc5295eed740e35b4f04',1);
INSERT INTO "review_evidence" VALUES('ev-9369e0639f34743b55fd5030','rev-42cd1418d0397f536f335de6',7,'document','{"document":"doc-f51aef9e079c43038da9b3d0","revision":1,"sha256":"4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820","run":"r1"}','{"document":"doc-f51aef9e079c43038da9b3d0","revision":1,"sha256":"4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820","author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"reason":"created","tombstone":false}','670963449c5a9624965c5a35621db06b67adb1fa9fe7f4de32fd4043a54fa928',1);
INSERT INTO "review_evidence" VALUES('ev-8735794ce8173977dfa499f7','rev-42cd1418d0397f536f335de6',8,'document','{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3","run":"r1"}','{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3","author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"reason":"created","tombstone":false}','ed71f76be377c2af7bd8688a8864ad40c8758fa0e04efb3df68df143fb7b6e05',1);
INSERT INTO "review_evidence" VALUES('ev-af9fd62a059fa36a01e87e38','rev-42cd1418d0397f536f335de6',9,'transcript','{"run":"author-1","message":1}','{"role":"assistant","content":"The check gave 16."}','e272418555bb1e5ae71b87179c18469db905d61729a7450982dd3e489a8d0283',1);
INSERT INTO "review_evidence" VALUES('ev-1d7c57416d58cd8237e30e92','rev-65b5b0f9e36fdb1b38fab4ca',1,'document','{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99"}','{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99"}','b44de9768f1de0e8e2de2dfc6f51ff29edc0f54494507a614d5f388b3997ef55',1);
INSERT INTO "review_evidence" VALUES('ev-6d18bf643dd1426481366ea5','rev-65b5b0f9e36fdb1b38fab4ca',2,'finding','{"finding":"finding-da4788c18fb518061f270269","revision":2}','{"finding":"finding-da4788c18fb518061f270269","severity":"fail","category":"contradicting_value","statement":"Anchored statement.","anchors":[{"evidence":"ev-69d841962ddc04d16e727ebf","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99","run":"r1"},"sha256":"f6901ae1e9130504c9d85e01cf39d51913ebe2cf66742e51840ecd29ddae973c","complete":true},{"evidence":"ev-e515db78eaaa911eaf1aba99","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635","run":"r1"},"sha256":"e117b4634ffb48360158bb088f37593c19c9454ad868d2033544fc301aa1bf92","complete":true}],"remedy":null,"status":"claimed fixed","revision":2,"reflags":0,"supersedes":null,"response":{"reason":"Fixed $\\F$ here","payload":{"action":"fix","explanation":"Fixed $\\F$ here","anchors":[],"revisions":[{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99"}],"artifact_revisions":[],"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"body":{"source":"response:finding-da4788c18fb518061f270269:r2:explanation","finding":"finding-da4788c18fb518061f270269","response_revision":2,"revision":2,"body":"Edited $\\F + \\G$","sha256":"22521436510afa8d68f19b1a347f23544228a2c0cc22de3f29b4851a4f310af6","original_author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"held":null,"macro_context":{"project":"p","revision":4,"sha256":"53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb","macros":{"\\F":"fourth","\\G":"g4"},"anchors":[{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99"},{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635"}]}},"macro_context":{"project":"p","revision":4,"sha256":"53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb","macros":{"\\F":"agreed","\\G":"g4"},"known":true,"anchors":[{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99"},{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635"}],"problems":[],"held":false,"key":"1784b97d520c2ef47acea4e68e191515ce9596a36de51cb2c8983df13729d0a4"}}}','81fdd0411f941b9a61fbc964421701b72f1d6bafd36fe845f633eeac2350a165',1);
INSERT INTO "review_evidence" VALUES('ev-b8261560700f50f4e1138faa','rev-65b5b0f9e36fdb1b38fab4ca',3,'finding','{"finding":"finding-5b46fc960bd07409ddc5e6d6","revision":2}','{"finding":"finding-5b46fc960bd07409ddc5e6d6","severity":"fail","category":"contradicting_value","statement":"Anchored statement.","anchors":[{"evidence":"ev-a9ae4b84c830fe41295ae6f7","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-ed8581e68ef9d205cd12249f","revision":1,"sha256":"cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9","run":"r1"},"sha256":"9a813d784f388e0c4b78d9959b901e82e03d2284bc64cc5295eed740e35b4f04","complete":true},{"evidence":"ev-9369e0639f34743b55fd5030","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-f51aef9e079c43038da9b3d0","revision":1,"sha256":"4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820","run":"r1"},"sha256":"670963449c5a9624965c5a35621db06b67adb1fa9fe7f4de32fd4043a54fa928","complete":true}],"remedy":null,"status":"open","revision":2,"reflags":0,"supersedes":null,"response":{"reason":"Not so: $\\F$","payload":{"action":"rebut","explanation":"Not so: $\\F$","anchors":[],"revisions":[],"artifact_revisions":[],"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"body":{"source":"response:finding-5b46fc960bd07409ddc5e6d6:r2:explanation","finding":"finding-5b46fc960bd07409ddc5e6d6","response_revision":2,"revision":1,"body":"Not so: $\\F$","sha256":"8f81adb3d27478ae3ce0dbc859f644b230e6366968eaab1d34b395fd37fb5fca","original_author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"held":null,"macro_context":{"project":"p","revision":4,"sha256":"53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb","macros":{"\\F":"fourth","\\G":"g4"},"anchors":[{"document":"doc-ed8581e68ef9d205cd12249f","revision":1,"sha256":"cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9"},{"document":"doc-f51aef9e079c43038da9b3d0","revision":1,"sha256":"4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820"}]}},"macro_context":{"project":"p","revision":4,"sha256":"53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb","macros":{"\\F":"fourth","\\G":"g4"},"known":true,"anchors":[{"document":"doc-ed8581e68ef9d205cd12249f","revision":1,"sha256":"cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9"},{"document":"doc-f51aef9e079c43038da9b3d0","revision":1,"sha256":"4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820"}],"problems":["Conflicting anchored document macro contexts; checks are held"],"held":true,"key":"f2dd35817c032edf0c2921d7f3e69d527818a0013dbcadef6fc32c25766d0582"}}}','98f3ac5189881d3d3db5b0fd1ef84b4206011c5d257b622f4ee31e54e762612e',0);
INSERT INTO "review_evidence" VALUES('ev-fa0a1baac227f6c7ddad8728','rev-65b5b0f9e36fdb1b38fab4ca',4,'finding','{"finding":"finding-2035ab2709c5671355e3f59f","revision":2}','{"finding":"finding-2035ab2709c5671355e3f59f","severity":"fail","category":"contradicting_value","statement":"Anchored statement.","anchors":[{"evidence":"ev-69d841962ddc04d16e727ebf","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99","run":"r1"},"sha256":"f6901ae1e9130504c9d85e01cf39d51913ebe2cf66742e51840ecd29ddae973c","complete":true}],"remedy":null,"status":"open","revision":2,"reflags":0,"supersedes":null,"response":{"reason":"Legacy $\\F$","payload":{"action":"rebut","explanation":"Legacy $\\F$","anchors":[],"revisions":[],"artifact_revisions":[],"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"body":{"source":"response:finding-2035ab2709c5671355e3f59f:r2:explanation","finding":"finding-2035ab2709c5671355e3f59f","response_revision":2,"revision":2,"body":"Edited $\\F + \\G$","sha256":"22521436510afa8d68f19b1a347f23544228a2c0cc22de3f29b4851a4f310af6","original_author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"held":null,"macro_context":{"project":"p","revision":4,"sha256":"53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb","macros":{"\\F":"fourth","\\G":"g4"},"anchors":[{"unknown":true}]}},"macro_context":{"project":"p","revision":4,"sha256":"53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb","macros":{"\\F":"fourth","\\G":"g4"},"known":true,"anchors":[{"unknown":true}],"problems":["Anchored macro context is unknown; checks are held"],"held":true,"key":"4f12c2b85e10a8f78586a09d01b05c4eb0ae1d4a605d719208486d95c322968a"}}}','cd086b8071e5dd57d71401e1470a27e0450bb8001878793d11ea4b4133ede601',0);
INSERT INTO "review_evidence" VALUES('ev-15c7c61a988e36bac7efc31e','rev-65b5b0f9e36fdb1b38fab4ca',5,'finding','{"finding":"finding-440cc2bad6a1de3ea75400d0","revision":2}','{"finding":"finding-440cc2bad6a1de3ea75400d0","severity":"fail","category":"contradicting_value","statement":"Anchored statement.","anchors":[{"evidence":"ev-e515db78eaaa911eaf1aba99","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635","run":"r1"},"sha256":"e117b4634ffb48360158bb088f37593c19c9454ad868d2033544fc301aa1bf92","complete":true},{"evidence":"ev-8735794ce8173977dfa499f7","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3","run":"r1"},"sha256":"ed71f76be377c2af7bd8688a8864ad40c8758fa0e04efb3df68df143fb7b6e05","complete":true}],"remedy":null,"status":"open","revision":2,"reflags":0,"supersedes":null,"response":{"reason":"Reorder $\\F$","payload":{"action":"rebut","explanation":"Reorder $\\F$","anchors":[],"revisions":[],"artifact_revisions":[],"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"body":{"source":"response:finding-440cc2bad6a1de3ea75400d0:r2:explanation","finding":"finding-440cc2bad6a1de3ea75400d0","response_revision":2,"revision":1,"body":"Reorder $\\F$","sha256":"1fdfac3bc7e9978cfa3690af5ff0c07502ed6298f2794f3e5e315c5b4a8b1dfc","original_author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"held":null,"macro_context":{"project":"p","revision":4,"sha256":"53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb","macros":{"\\F":"fourth","\\G":"g4"},"anchors":[{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635"},{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3"}]}},"macro_context":{"project":"p","revision":4,"sha256":"53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb","macros":{"\\F":"agreed","\\G":"g4"},"known":true,"anchors":[{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635"},{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3"}],"problems":[],"held":false,"key":"120b165f5a6cbcf215960955a1be032417f1b2df53d574fe05ef60b47eb32f66"}}}','b65d2f8ed6e4f3e116b3aaecc99abd1ef0d8ac69597ff182f88329d55b3bd464',1);
INSERT INTO "review_evidence" VALUES('ev-715dd7f4c70ae3eafd46087f','rev-1d606daeb93532ef94420dbe',1,'document','{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99"}','{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99"}','b44de9768f1de0e8e2de2dfc6f51ff29edc0f54494507a614d5f388b3997ef55',1);
INSERT INTO "review_evidence" VALUES('ev-db347e05e3d422220b0821a8','rev-1d606daeb93532ef94420dbe',2,'transcript','{"run":"author-1","message":1}','{"role":"assistant","content":"Another message."}','c0db7bf969c34b589abaaf54410204269b59f0e2c8af1188f93067f0d02a534e',1);
INSERT INTO "review_evidence" VALUES('ev-7feefae7abc1aa0c395f164e','rev-1d606daeb93532ef94420dbe',3,'finding','{"finding":"finding-5b46fc960bd07409ddc5e6d6","revision":2}','{"finding":"finding-5b46fc960bd07409ddc5e6d6","severity":"fail","category":"contradicting_value","statement":"Anchored statement.","anchors":[{"evidence":"ev-a9ae4b84c830fe41295ae6f7","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-ed8581e68ef9d205cd12249f","revision":1,"sha256":"cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9","run":"r1"},"sha256":"9a813d784f388e0c4b78d9959b901e82e03d2284bc64cc5295eed740e35b4f04","complete":true},{"evidence":"ev-9369e0639f34743b55fd5030","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-f51aef9e079c43038da9b3d0","revision":1,"sha256":"4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820","run":"r1"},"sha256":"670963449c5a9624965c5a35621db06b67adb1fa9fe7f4de32fd4043a54fa928","complete":true}],"remedy":null,"status":"open","revision":2,"reflags":0,"supersedes":null,"response":{"reason":"Not so: $\\F$","payload":{"action":"rebut","explanation":"Not so: $\\F$","anchors":[],"revisions":[],"artifact_revisions":[],"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"body":{"source":"response:finding-5b46fc960bd07409ddc5e6d6:r2:explanation","finding":"finding-5b46fc960bd07409ddc5e6d6","response_revision":2,"revision":1,"body":"Not so: $\\F$","sha256":"8f81adb3d27478ae3ce0dbc859f644b230e6366968eaab1d34b395fd37fb5fca","original_author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"held":null,"macro_context":{"project":"p","revision":4,"sha256":"53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb","macros":{"\\F":"fourth","\\G":"g4"},"anchors":[{"document":"doc-ed8581e68ef9d205cd12249f","revision":1,"sha256":"cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9"},{"document":"doc-f51aef9e079c43038da9b3d0","revision":1,"sha256":"4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820"}]}},"macro_context":{"project":"p","revision":4,"sha256":"53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb","macros":{"\\F":"fourth","\\G":"g4"},"known":true,"anchors":[{"document":"doc-ed8581e68ef9d205cd12249f","revision":1,"sha256":"cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9"},{"document":"doc-f51aef9e079c43038da9b3d0","revision":1,"sha256":"4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820"}],"problems":["Conflicting anchored document macro contexts; checks are held"],"held":true,"key":"f2dd35817c032edf0c2921d7f3e69d527818a0013dbcadef6fc32c25766d0582"}}}','98f3ac5189881d3d3db5b0fd1ef84b4206011c5d257b622f4ee31e54e762612e',0);
INSERT INTO "review_evidence" VALUES('ev-1dce4c6c0d53b3b579304813','rev-1d606daeb93532ef94420dbe',4,'finding','{"finding":"finding-2035ab2709c5671355e3f59f","revision":2}','{"finding":"finding-2035ab2709c5671355e3f59f","severity":"fail","category":"contradicting_value","statement":"Anchored statement.","anchors":[{"evidence":"ev-69d841962ddc04d16e727ebf","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99","run":"r1"},"sha256":"f6901ae1e9130504c9d85e01cf39d51913ebe2cf66742e51840ecd29ddae973c","complete":true}],"remedy":null,"status":"open","revision":2,"reflags":0,"supersedes":null,"response":{"reason":"Legacy $\\F$","payload":{"action":"rebut","explanation":"Legacy $\\F$","anchors":[],"revisions":[],"artifact_revisions":[],"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"body":{"source":"response:finding-2035ab2709c5671355e3f59f:r2:explanation","finding":"finding-2035ab2709c5671355e3f59f","response_revision":2,"revision":2,"body":"Edited $\\F + \\G$","sha256":"22521436510afa8d68f19b1a347f23544228a2c0cc22de3f29b4851a4f310af6","original_author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"held":null,"macro_context":{"project":"p","revision":4,"sha256":"53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb","macros":{"\\F":"fourth","\\G":"g4"},"anchors":[{"unknown":true}]}},"macro_context":{"project":"p","revision":4,"sha256":"53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb","macros":{"\\F":"fourth","\\G":"g4"},"known":true,"anchors":[{"unknown":true}],"problems":["Anchored macro context is unknown; checks are held"],"held":true,"key":"4f12c2b85e10a8f78586a09d01b05c4eb0ae1d4a605d719208486d95c322968a"}}}','cd086b8071e5dd57d71401e1470a27e0450bb8001878793d11ea4b4133ede601',0);
INSERT INTO "review_evidence" VALUES('ev-6122792d5a2ca0bb9d973dcd','rev-1d606daeb93532ef94420dbe',5,'finding','{"finding":"finding-440cc2bad6a1de3ea75400d0","revision":2}','{"finding":"finding-440cc2bad6a1de3ea75400d0","severity":"fail","category":"contradicting_value","statement":"Anchored statement.","anchors":[{"evidence":"ev-e515db78eaaa911eaf1aba99","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635","run":"r1"},"sha256":"e117b4634ffb48360158bb088f37593c19c9454ad868d2033544fc301aa1bf92","complete":true},{"evidence":"ev-8735794ce8173977dfa499f7","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3","run":"r1"},"sha256":"ed71f76be377c2af7bd8688a8864ad40c8758fa0e04efb3df68df143fb7b6e05","complete":true}],"remedy":null,"status":"open","revision":2,"reflags":0,"supersedes":null,"response":{"reason":"Reorder $\\F$","payload":{"action":"rebut","explanation":"Reorder $\\F$","anchors":[],"revisions":[],"artifact_revisions":[],"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"body":{"source":"response:finding-440cc2bad6a1de3ea75400d0:r2:explanation","finding":"finding-440cc2bad6a1de3ea75400d0","response_revision":2,"revision":1,"body":"Reorder $\\F$","sha256":"1fdfac3bc7e9978cfa3690af5ff0c07502ed6298f2794f3e5e315c5b4a8b1dfc","original_author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"held":null,"macro_context":{"project":"p","revision":4,"sha256":"53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb","macros":{"\\F":"fourth","\\G":"g4"},"anchors":[{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635"},{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3"}]}},"macro_context":{"project":"p","revision":4,"sha256":"53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb","macros":{"\\F":"agreed","\\G":"g4"},"known":true,"anchors":[{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635"},{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3"}],"problems":[],"held":false,"key":"120b165f5a6cbcf215960955a1be032417f1b2df53d574fe05ef60b47eb32f66"}}}','b65d2f8ed6e4f3e116b3aaecc99abd1ef0d8ac69597ff182f88329d55b3bd464',1);
INSERT INTO "review_evidence" VALUES('ev-b2d2e3e0dc766a4b46e930a0','rev-1d606daeb93532ef94420dbe',6,'finding','{"finding":"finding-da4788c18fb518061f270269","revision":3}','{"finding":"finding-da4788c18fb518061f270269","severity":"fail","category":"contradicting_value","statement":"Anchored statement.","anchors":[{"evidence":"ev-69d841962ddc04d16e727ebf","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99","run":"r1"},"sha256":"f6901ae1e9130504c9d85e01cf39d51913ebe2cf66742e51840ecd29ddae973c","complete":true},{"evidence":"ev-e515db78eaaa911eaf1aba99","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635","run":"r1"},"sha256":"e117b4634ffb48360158bb088f37593c19c9454ad868d2033544fc301aa1bf92","complete":true}],"remedy":null,"status":"inconclusive","revision":3,"reflags":0,"supersedes":null,"response":{"reason":"Cannot tell.","payload":{"review":"rev-65b5b0f9e36fdb1b38fab4ca","anchors":[{"evidence":"ev-6d18bf643dd1426481366ea5","review":"rev-65b5b0f9e36fdb1b38fab4ca","locator":{"finding":"finding-da4788c18fb518061f270269","revision":2},"sha256":"81fdd0411f941b9a61fbc964421701b72f1d6bafd36fe845f633eeac2350a165","complete":true}],"decision":"inconclusive"}}}','fa48cf27854c766e00df6de34a1bab714101e7e9e68b82a6f01fab4772ea2cc0',1);
CREATE TABLE "review_feed" (
    seq INTEGER PRIMARY KEY AUTOINCREMENT, project TEXT NOT NULL, session TEXT NOT NULL,
    source_key TEXT NOT NULL CHECK (length(CAST(source_key AS BLOB)) BETWEEN 1 AND 1024),
    kind TEXT NOT NULL CHECK (length(CAST(kind AS BLOB)) BETWEEN 1 AND 32),
    locator TEXT NOT NULL
        CHECK (json_valid(locator) AND length(CAST(locator AS BLOB)) <= 4096),
    payload TEXT NOT NULL
        CHECK (json_valid(payload) AND length(CAST(payload AS BLOB)) <= 262144),
    sha256 TEXT NOT NULL CHECK (length(sha256) = 64 AND sha256 NOT GLOB '*[^0-9a-f]*'),
    complete INTEGER NOT NULL CHECK (complete IN (0, 1)),
    characters INTEGER NOT NULL CHECK (characters >= 0),
    structural INTEGER NOT NULL CHECK (structural >= 0),
    artifacts INTEGER NOT NULL CHECK (artifacts >= 0),
    cells INTEGER NOT NULL CHECK (cells >= 0),
    effects INTEGER NOT NULL CHECK (effects IN (0, 1)),
    created REAL NOT NULL, UNIQUE(project,session,source_key)) STRICT;
INSERT INTO "review_feed" VALUES(1,'p','s','document:doc-58b9197efd52aaaaf2628f77:1','document','{"document":"doc-58b9197efd52aaaaf2628f77","revision":1,"sha256":"7fcace58933d4f12f56947f2b6ecadd1f90f62a88419d1efe1735389d1c2d2b9","run":"r1"}','{"document":"doc-58b9197efd52aaaaf2628f77","revision":1,"sha256":"7fcace58933d4f12f56947f2b6ecadd1f90f62a88419d1efe1735389d1c2d2b9","author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"reason":"created","tombstone":false}','2120ca96a25a502668aee7a76e085722a7cf7931236e04a26eedc4510d4066c9',1,24,0,0,0,1,1000.0);
INSERT INTO "review_feed" VALUES(2,'p','s','document:doc-58b9197efd52aaaaf2628f77:2','document','{"document":"doc-58b9197efd52aaaaf2628f77","revision":2,"sha256":"ac6576e1e89ad370183e2dea65ddc756024b91f6dcb350cc8639e091be739f6b","run":"r1"}','{"document":"doc-58b9197efd52aaaaf2628f77","revision":2,"sha256":"ac6576e1e89ad370183e2dea65ddc756024b91f6dcb350cc8639e091be739f6b","author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"reason":"Edit formula","tombstone":false}','2a4e3c5841a635f0b3da1236c27357931f6f0866ab18d1f2ce5a719a9afe5166',1,1,0,0,0,1,1000.0);
INSERT INTO "review_feed" VALUES(3,'p','s','document:doc-1e4f0c5c2e394387ce7165fe:1','document','{"document":"doc-1e4f0c5c2e394387ce7165fe","revision":1,"sha256":"6c2dc0ee0ced3db7079f1f94ee41a9721245d43cae77a69bec8814c6eb4c91ab","run":"r1"}','{"document":"doc-1e4f0c5c2e394387ce7165fe","revision":1,"sha256":"6c2dc0ee0ced3db7079f1f94ee41a9721245d43cae77a69bec8814c6eb4c91ab","author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"reason":"created","tombstone":false}','76080fe70410fb024b3d47d4cfffd489bef5747561e08c6a3f5c161e36b07f60',1,43,0,0,0,1,1000.0);
INSERT INTO "review_feed" VALUES(4,'p','s','document:doc-0f819e0cfea434b82ffc8823:1','document','{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99","run":"r1"}','{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99","author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"reason":"created","tombstone":false}','f6901ae1e9130504c9d85e01cf39d51913ebe2cf66742e51840ecd29ddae973c',1,45,0,0,0,1,1000.0);
INSERT INTO "review_feed" VALUES(5,'p','s','document:doc-adf74e15920f0fb47c0a88f1:1','document','{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635","run":"r1"}','{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635","author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"reason":"created","tombstone":false}','e117b4634ffb48360158bb088f37593c19c9454ad868d2033544fc301aa1bf92',1,45,0,0,0,1,1000.0);
INSERT INTO "review_feed" VALUES(6,'p','s','document:doc-ed8581e68ef9d205cd12249f:1','document','{"document":"doc-ed8581e68ef9d205cd12249f","revision":1,"sha256":"cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9","run":"r1"}','{"document":"doc-ed8581e68ef9d205cd12249f","revision":1,"sha256":"cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9","author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"reason":"created","tombstone":false}','9a813d784f388e0c4b78d9959b901e82e03d2284bc64cc5295eed740e35b4f04',1,42,0,0,0,1,1000.0);
INSERT INTO "review_feed" VALUES(7,'p','s','document:doc-f51aef9e079c43038da9b3d0:1','document','{"document":"doc-f51aef9e079c43038da9b3d0","revision":1,"sha256":"4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820","run":"r1"}','{"document":"doc-f51aef9e079c43038da9b3d0","revision":1,"sha256":"4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820","author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"reason":"created","tombstone":false}','670963449c5a9624965c5a35621db06b67adb1fa9fe7f4de32fd4043a54fa928',1,42,0,0,0,1,1000.0);
INSERT INTO "review_feed" VALUES(8,'p','s','document:doc-dbd8ffaf1480d8b94d29e9ae:1','document','{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3","run":"r1"}','{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3","author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"reason":"created","tombstone":false}','ed71f76be377c2af7bd8688a8864ad40c8758fa0e04efb3df68df143fb7b6e05',1,47,0,0,0,1,1000.0);
INSERT INTO "review_feed" VALUES(9,'p','s','m1','transcript','{"run":"author-1","message":1}','{"role":"assistant","content":"The check gave 16."}','e272418555bb1e5ae71b87179c18469db905d61729a7450982dd3e489a8d0283',1,0,0,0,0,0,1000.0);
INSERT INTO "review_feed" VALUES(10,'p','s','response:finding-da4788c18fb518061f270269:2:doc-0f819e0cfea434b82ffc8823:1','document','{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99"}','{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99"}','b44de9768f1de0e8e2de2dfc6f51ff29edc0f54494507a614d5f388b3997ef55',1,0,0,0,0,0,1000.0);
INSERT INTO "review_feed" VALUES(11,'p','s','m2','transcript','{"run":"author-1","message":1}','{"role":"assistant","content":"Another message."}','c0db7bf969c34b589abaaf54410204269b59f0e2c8af1188f93067f0d02a534e',1,0,0,0,0,0,1000.0);
CREATE TABLE review_findings (
    finding_id TEXT PRIMARY KEY,project TEXT NOT NULL,session TEXT NOT NULL,review_id TEXT,
    severity TEXT NOT NULL,category TEXT NOT NULL,statement TEXT NOT NULL,anchors TEXT NOT NULL,
    remedy TEXT,status TEXT NOT NULL,revision INTEGER NOT NULL,reflags INTEGER NOT NULL DEFAULT 0,
    dedupe TEXT NOT NULL,supersedes TEXT,created REAL NOT NULL,
    origin TEXT NOT NULL DEFAULT 'review',math_check_id TEXT REFERENCES math_jobs(check_id),
    CHECK((origin='review' AND review_id IS NOT NULL AND math_check_id IS NULL AND category!='math')
       OR (origin='math' AND review_id IS NULL AND math_check_id IS NOT NULL
           AND category='math' AND severity='warn'))) STRICT;
INSERT INTO "review_findings" VALUES('finding-fc52622e4f87078760aa6f5e','p','s',NULL,'warn','math','A saved formula was rejected by the configured math renderer: Unknown command','[{"check":"math-f4d01318b3533f2235bcf545","locator":{"document":"doc-58b9197efd52aaaaf2628f77","revision":2},"block":"b1","math":"m1","sha256":"ac6576e1e89ad370183e2dea65ddc756024b91f6dcb350cc8639e091be739f6b","complete":true}]','x','open',5,1,'c351cb2660c132864f586c96dcf5b653ac2ebe762d05d2b7cb49ee855fb9344e',NULL,1000.0,'math','math-f4d01318b3533f2235bcf545');
INSERT INTO "review_findings" VALUES('finding-e157e420507d284c5f22e341','p','s',NULL,'warn','math','A saved formula was rejected by the configured math renderer: Unknown command','[{"check":"math-f4d01318b3533f2235bcf545","locator":{"document":"doc-58b9197efd52aaaaf2628f77","revision":2},"block":"b1","math":"m2","sha256":"ac6576e1e89ad370183e2dea65ddc756024b91f6dcb350cc8639e091be739f6b","complete":true}]','x','open',5,1,'db1c77681ba429ed771b322b4106b356f1ed7733f95c30d66260d2b5b32792bc',NULL,1000.0,'math','math-f4d01318b3533f2235bcf545');
INSERT INTO "review_findings" VALUES('finding-da4788c18fb518061f270269','p','s','rev-42cd1418d0397f536f335de6','fail','contradicting_value','Anchored statement.','[{"evidence":"ev-69d841962ddc04d16e727ebf","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99","run":"r1"},"sha256":"f6901ae1e9130504c9d85e01cf39d51913ebe2cf66742e51840ecd29ddae973c","complete":true},{"evidence":"ev-e515db78eaaa911eaf1aba99","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635","run":"r1"},"sha256":"e117b4634ffb48360158bb088f37593c19c9454ad868d2033544fc301aa1bf92","complete":true}]',NULL,'inconclusive',3,0,'04b22c4f2fc732396e957c170b1f0f53995541640aa18c23fa3193c46b99f387',NULL,1000.0,'review',NULL);
INSERT INTO "review_findings" VALUES('finding-5b46fc960bd07409ddc5e6d6','p','s','rev-42cd1418d0397f536f335de6','fail','contradicting_value','Anchored statement.','[{"evidence":"ev-a9ae4b84c830fe41295ae6f7","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-ed8581e68ef9d205cd12249f","revision":1,"sha256":"cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9","run":"r1"},"sha256":"9a813d784f388e0c4b78d9959b901e82e03d2284bc64cc5295eed740e35b4f04","complete":true},{"evidence":"ev-9369e0639f34743b55fd5030","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-f51aef9e079c43038da9b3d0","revision":1,"sha256":"4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820","run":"r1"},"sha256":"670963449c5a9624965c5a35621db06b67adb1fa9fe7f4de32fd4043a54fa928","complete":true}]',NULL,'open',2,0,'a44273b4082b7e5b52e6a1e86d7bc46c245d4250eae222a8426c4202faf7c1fd',NULL,1000.0,'review',NULL);
INSERT INTO "review_findings" VALUES('finding-2035ab2709c5671355e3f59f','p','s','rev-42cd1418d0397f536f335de6','fail','contradicting_value','Anchored statement.','[{"evidence":"ev-69d841962ddc04d16e727ebf","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99","run":"r1"},"sha256":"f6901ae1e9130504c9d85e01cf39d51913ebe2cf66742e51840ecd29ddae973c","complete":true}]',NULL,'open',2,0,'293745cbee75875556dbe612b7275fa8f9813acabc96438f433da7589944df5f',NULL,1000.0,'review',NULL);
INSERT INTO "review_findings" VALUES('finding-440cc2bad6a1de3ea75400d0','p','s','rev-1d606daeb93532ef94420dbe','fail','contradicting_value','Anchored statement.','[{"evidence":"ev-8735794ce8173977dfa499f7","review":"rev-1d606daeb93532ef94420dbe","locator":{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3","run":"r1"},"sha256":"ed71f76be377c2af7bd8688a8864ad40c8758fa0e04efb3df68df143fb7b6e05","complete":true},{"evidence":"ev-e515db78eaaa911eaf1aba99","review":"rev-1d606daeb93532ef94420dbe","locator":{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635","run":"r1"},"sha256":"e117b4634ffb48360158bb088f37593c19c9454ad868d2033544fc301aa1bf92","complete":true}]',NULL,'unaddressed',4,2,'964a2d9ccd2e79746f5344de80ad6701e800534224114b67f1c6e65a0d12a60a',NULL,1000.0,'review',NULL);
INSERT INTO "review_findings" VALUES('finding-917db304507211c7b1843d18','p','s',NULL,'warn','math','A saved formula was rejected by the configured math renderer: Unknown command','[{"check":"math-b59ccb1495d1d5e8aae71190","locator":{"document":"doc-6d5d225787c1ec2d34b50b21","revision":1},"block":"b2","math":"m1","sha256":"79d8e00656390250b526b51dc6b4999ed42b809483609b7572bed89b3bdbb4a9","complete":true}]','x','open',1,0,'1c1bf939b1b54a2ae6a3b2d3e7544b47ba056d738639e4f34f7b542cc60f2cd3',NULL,1000.0,'math','math-b59ccb1495d1d5e8aae71190');
INSERT INTO "review_findings" VALUES('finding-f65c492ad291fed66c0bebfc','p','s',NULL,'warn','math','A saved formula was rejected by the configured math renderer: Unknown command','[{"check":"math-7762893baa2559a0c1f6af96","locator":{"document":"doc-6d5d225787c1ec2d34b50b21","revision":2,"comment":"cmt-c4fce9bb05f36a81283a26a4","body_revision":1},"block":"b1","math":"m1","sha256":"496550ffe147968e6d256bea2d07983848a5de00c020023ea51db07418bbce42","complete":true}]','x','open',2,0,'2818dd9b89985f788f097c7515f7116cd5dbaa4deee8200328a729f21bace2cd',NULL,1000.0,'math','math-7762893baa2559a0c1f6af96');
INSERT INTO "review_findings" VALUES('finding-76a488db1f7ed0dbeefce52d','p','s',NULL,'warn','math','A saved formula was rejected by the configured math renderer: Unknown command','[{"check":"math-104a8d905459fea011090c5a","locator":{"document":"doc-1e4f0c5c2e394387ce7165fe","revision":1},"block":"b2","math":"m1","sha256":"6c2dc0ee0ced3db7079f1f94ee41a9721245d43cae77a69bec8814c6eb4c91ab","complete":true}]','x','open',1,0,'c2faca5543c9f17fef49f3798704dc0c4dcd0f5fd9fd742078875ce5755451f8',NULL,1000.0,'math','math-104a8d905459fea011090c5a');
INSERT INTO "review_findings" VALUES('finding-3cd95b5b437e2f443a804203','p','s',NULL,'warn','math','A saved formula was rejected by the configured math renderer: Unknown command','[{"check":"math-1300bb97f6f90b0096106700","locator":{"document":"doc-1e4f0c5c2e394387ce7165fe","revision":1,"comment":"cmt-924da581199378bcff722140","body_revision":1},"block":"b1","math":"m1","sha256":"bc77b524efd01ebf2286358d6ca594b228ded4f097152d0bf63edc4a52c79f5f","complete":true}]','x','open',1,0,'52686c03bd8ad793c14848302fdef76015ef68bcf97efe08b7d8638291056739',NULL,1000.0,'math','math-1300bb97f6f90b0096106700');
INSERT INTO "review_findings" VALUES('finding-dd5709e9bc7427195c843f29','p','s',NULL,'warn','math','A saved formula was rejected by the configured math renderer: Unknown command','[{"check":"math-b741b94af44bab1010cc993b","locator":{"finding":"finding-da4788c18fb518061f270269","response_revision":2,"field":"explanation","body_revision":2},"block":"b1","math":"m1","sha256":"22521436510afa8d68f19b1a347f23544228a2c0cc22de3f29b4851a4f310af6","complete":true}]','x','open',1,0,'973540ad93a88b1415ba05fca26345c20a44a6d6e251199820bfbd11dc2c5a97',NULL,1000.0,'math','math-b741b94af44bab1010cc993b');
INSERT INTO "review_findings" VALUES('finding-c18690edcf3ea6b28d2346a6','p','s',NULL,'warn','math','A saved formula was rejected by the configured math renderer: Unknown command','[{"check":"math-68552ac718d6b1250e181062","locator":{"finding":"finding-440cc2bad6a1de3ea75400d0","response_revision":2,"field":"explanation","body_revision":1},"block":"b1","math":"m1","sha256":"1fdfac3bc7e9978cfa3690af5ff0c07502ed6298f2794f3e5e315c5b4a8b1dfc","complete":true}]','x','open',1,0,'fca5c066a29f70fb8b3c46e08a15f0ffd492f9459113ca6a966bb53eba6b685d',NULL,1000.0,'math','math-68552ac718d6b1250e181062');
CREATE TABLE review_grants (
    review_id TEXT NOT NULL REFERENCES review_runs(review_id),
    evidence_id TEXT NOT NULL REFERENCES review_evidence(evidence_id),
    ordinal INTEGER NOT NULL,PRIMARY KEY(review_id,evidence_id),
    UNIQUE(review_id,ordinal)) STRICT;
INSERT INTO "review_grants" VALUES('rev-65b5b0f9e36fdb1b38fab4ca','ev-69d841962ddc04d16e727ebf',6);
INSERT INTO "review_grants" VALUES('rev-65b5b0f9e36fdb1b38fab4ca','ev-e515db78eaaa911eaf1aba99',7);
INSERT INTO "review_grants" VALUES('rev-65b5b0f9e36fdb1b38fab4ca','ev-a9ae4b84c830fe41295ae6f7',8);
INSERT INTO "review_grants" VALUES('rev-65b5b0f9e36fdb1b38fab4ca','ev-9369e0639f34743b55fd5030',9);
INSERT INTO "review_grants" VALUES('rev-65b5b0f9e36fdb1b38fab4ca','ev-8735794ce8173977dfa499f7',10);
INSERT INTO "review_grants" VALUES('rev-1d606daeb93532ef94420dbe','ev-a9ae4b84c830fe41295ae6f7',7);
INSERT INTO "review_grants" VALUES('rev-1d606daeb93532ef94420dbe','ev-9369e0639f34743b55fd5030',8);
INSERT INTO "review_grants" VALUES('rev-1d606daeb93532ef94420dbe','ev-69d841962ddc04d16e727ebf',9);
INSERT INTO "review_grants" VALUES('rev-1d606daeb93532ef94420dbe','ev-e515db78eaaa911eaf1aba99',10);
INSERT INTO "review_grants" VALUES('rev-1d606daeb93532ef94420dbe','ev-8735794ce8173977dfa499f7',11);
INSERT INTO "review_grants" VALUES('rev-1d606daeb93532ef94420dbe','ev-6d18bf643dd1426481366ea5',12);
CREATE TABLE "review_macro_pins" (
    review_id TEXT NOT NULL, finding_id TEXT NOT NULL,
    revision INTEGER NOT NULL CHECK (revision BETWEEN 0 AND 999999999),
    sha256 TEXT NOT NULL CHECK (length(sha256) = 64 AND sha256 NOT GLOB '*[^0-9a-f]*'),
    PRIMARY KEY(review_id,finding_id)) STRICT;
INSERT INTO "review_macro_pins" VALUES('rev-65b5b0f9e36fdb1b38fab4ca','finding-da4788c18fb518061f270269',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb');
INSERT INTO "review_macro_pins" VALUES('rev-65b5b0f9e36fdb1b38fab4ca','finding-5b46fc960bd07409ddc5e6d6',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb');
INSERT INTO "review_macro_pins" VALUES('rev-65b5b0f9e36fdb1b38fab4ca','finding-2035ab2709c5671355e3f59f',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb');
INSERT INTO "review_macro_pins" VALUES('rev-65b5b0f9e36fdb1b38fab4ca','finding-440cc2bad6a1de3ea75400d0',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb');
INSERT INTO "review_macro_pins" VALUES('rev-1d606daeb93532ef94420dbe','finding-5b46fc960bd07409ddc5e6d6',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb');
INSERT INTO "review_macro_pins" VALUES('rev-1d606daeb93532ef94420dbe','finding-2035ab2709c5671355e3f59f',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb');
INSERT INTO "review_macro_pins" VALUES('rev-1d606daeb93532ef94420dbe','finding-440cc2bad6a1de3ea75400d0',4,'53d115473f3ad7648c51e66782b84e92af21dd30de21bb3d38e0eee5d34968cb');
CREATE TABLE review_notices (
    finding_id TEXT NOT NULL,revision INTEGER NOT NULL,project TEXT NOT NULL,
    session TEXT NOT NULL,
    claimed_run TEXT,claim_until REAL,delivered_run TEXT,
    PRIMARY KEY(finding_id,revision)) STRICT;
INSERT INTO "review_notices" VALUES('finding-da4788c18fb518061f270269',1,'p','s',NULL,NULL,NULL);
INSERT INTO "review_notices" VALUES('finding-5b46fc960bd07409ddc5e6d6',1,'p','s',NULL,NULL,NULL);
INSERT INTO "review_notices" VALUES('finding-2035ab2709c5671355e3f59f',1,'p','s',NULL,NULL,NULL);
INSERT INTO "review_notices" VALUES('finding-440cc2bad6a1de3ea75400d0',1,'p','s',NULL,NULL,NULL);
INSERT INTO "review_notices" VALUES('finding-5b46fc960bd07409ddc5e6d6',2,'p','s',NULL,NULL,NULL);
INSERT INTO "review_notices" VALUES('finding-2035ab2709c5671355e3f59f',2,'p','s',NULL,NULL,NULL);
INSERT INTO "review_notices" VALUES('finding-440cc2bad6a1de3ea75400d0',2,'p','s',NULL,NULL,NULL);
INSERT INTO "review_notices" VALUES('finding-440cc2bad6a1de3ea75400d0',3,'p','s',NULL,NULL,NULL);
CREATE TABLE review_operations (
    project TEXT NOT NULL,actor TEXT NOT NULL,operation_id TEXT NOT NULL,
    fingerprint TEXT NOT NULL,result TEXT NOT NULL,
    PRIMARY KEY(project,actor,operation_id)) STRICT;
INSERT INTO "review_operations" VALUES('p','review:rev-42cd1418d0397f536f335de6','f-agreed','ec51757507d3daec0efa498004d44a9308ec0994e643819b8af99a51084977a1','{"finding_id":"finding-da4788c18fb518061f270269","status":"open","revision":1,"reflags":0}');
INSERT INTO "review_operations" VALUES('p','review:rev-42cd1418d0397f536f335de6','f-conflict','3e2b1308d034f500912af5bca7159ef71a5c31a0dd674f6e614364b14613c638','{"finding_id":"finding-5b46fc960bd07409ddc5e6d6","status":"open","revision":1,"reflags":0}');
INSERT INTO "review_operations" VALUES('p','review:rev-42cd1418d0397f536f335de6','f-legacy','e2c91b64762b274977133aa146d926532496e778d532db0d8fa858e9f356556a','{"finding_id":"finding-2035ab2709c5671355e3f59f","status":"open","revision":1,"reflags":0}');
INSERT INTO "review_operations" VALUES('p','review:rev-42cd1418d0397f536f335de6','f-reorder','c006b5d3527646ad9ece975c33b08a0ac62d4b5d05c0407b74c0247344e1dd0d','{"finding_id":"finding-440cc2bad6a1de3ea75400d0","status":"open","revision":1,"reflags":0}');
INSERT INTO "review_operations" VALUES('p','session:s','resp-agreed','d213b0dd58bbcca9b3c1823e609207a9dd2646c0278ef7d6a3bb24355dd3c434','{"finding_id":"finding-da4788c18fb518061f270269","status":"claimed fixed","revision":2,"reflags":0}');
INSERT INTO "review_operations" VALUES('p','session:s','resp-conflict','a687f743faff225f82f2708f250d5b1ed1b93224676d3eebf0b53883c89dfbcd','{"finding_id":"finding-5b46fc960bd07409ddc5e6d6","status":"open","revision":2,"reflags":0}');
INSERT INTO "review_operations" VALUES('p','session:s','resp-legacy','cd6a64e36af790c8ccdf2e36b019b908b661ad4d1e4727b32fd1ac2aa21eea89','{"finding_id":"finding-2035ab2709c5671355e3f59f","status":"open","revision":2,"reflags":0}');
INSERT INTO "review_operations" VALUES('p','session:s','resp-reorder','03948f3ffa63079e8dd4c74805f5b1abd049a83a23992411c26ee85453cbc144','{"finding_id":"finding-440cc2bad6a1de3ea75400d0","status":"open","revision":2,"reflags":0}');
INSERT INTO "review_operations" VALUES('p','session:s','edit-finding-da4788c18fb518061f270269','690d9ff423a9d9728673babea755c383f04bfcfe879f5e709e72a6a583c30416','{"source":"response:finding-da4788c18fb518061f270269:r2:explanation","finding":"finding-da4788c18fb518061f270269","response_revision":2,"revision":2,"body":"Edited $\\F + \\G$","sha256":"22521436510afa8d68f19b1a347f23544228a2c0cc22de3f29b4851a4f310af6","original_author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"held":null}');
INSERT INTO "review_operations" VALUES('p','session:s','edit-finding-2035ab2709c5671355e3f59f','3bde0ab879ab17d654019df8db9535774817261be0da3be2d6f7df6d653fdb5e','{"source":"response:finding-2035ab2709c5671355e3f59f:r2:explanation","finding":"finding-2035ab2709c5671355e3f59f","response_revision":2,"revision":2,"body":"Edited $\\F + \\G$","sha256":"22521436510afa8d68f19b1a347f23544228a2c0cc22de3f29b4851a4f310af6","original_author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null},"held":null}');
INSERT INTO "review_operations" VALUES('p','review:rev-65b5b0f9e36fdb1b38fab4ca','decide-agreed','ac8f959d6e174ae57d6f92d96d8bed6252bd6328b41a232acbed9d902cd694d0','{"finding_id":"finding-da4788c18fb518061f270269","status":"inconclusive","revision":3,"reflags":0}');
INSERT INTO "review_operations" VALUES('p','review:rev-1d606daeb93532ef94420dbe','decide-reorder','f8ef80e9beb4061a3ab4e6ab45cf7e973390904a291dc52077bb01f21f525f60','{"finding_id":"finding-440cc2bad6a1de3ea75400d0","status":"open","revision":3,"reflags":1}');
INSERT INTO "review_operations" VALUES('p','review:rev-1d606daeb93532ef94420dbe','f-reorder-again','4cf998e45088cdbef95e1915123e75bcc7d8f664246d3696cbf617b0a616f232','{"finding_id":"finding-440cc2bad6a1de3ea75400d0","status":"unaddressed","revision":4,"reflags":2}');
CREATE TABLE review_reads (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    review_id TEXT NOT NULL REFERENCES review_runs(review_id),
    evidence_id TEXT NOT NULL REFERENCES review_evidence(evidence_id),locator TEXT NOT NULL,
    sha256 TEXT NOT NULL,created REAL NOT NULL) STRICT;
INSERT INTO "review_reads" VALUES(1,'rev-65b5b0f9e36fdb1b38fab4ca','ev-1d7c57416d58cd8237e30e92','{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99","block":null,"start":0,"returned_characters":48,"total_characters":48}','b44de9768f1de0e8e2de2dfc6f51ff29edc0f54494507a614d5f388b3997ef55',1000.0);
INSERT INTO "review_reads" VALUES(2,'rev-65b5b0f9e36fdb1b38fab4ca','ev-6d18bf643dd1426481366ea5','{"finding":"finding-da4788c18fb518061f270269","revision":2,"block":null,"start":0,"returned_characters":3230,"total_characters":3230}','81fdd0411f941b9a61fbc964421701b72f1d6bafd36fe845f633eeac2350a165',1000.0);
INSERT INTO "review_reads" VALUES(3,'rev-65b5b0f9e36fdb1b38fab4ca','ev-b8261560700f50f4e1138faa','{"finding":"finding-5b46fc960bd07409ddc5e6d6","revision":2,"block":null,"start":0,"returned_characters":3142,"total_characters":3142}','98f3ac5189881d3d3db5b0fd1ef84b4206011c5d257b622f4ee31e54e762612e',1000.0);
INSERT INTO "review_reads" VALUES(4,'rev-65b5b0f9e36fdb1b38fab4ca','ev-fa0a1baac227f6c7ddad8728','{"finding":"finding-2035ab2709c5671355e3f59f","revision":2,"block":null,"start":0,"returned_characters":2307,"total_characters":2307}','cd086b8071e5dd57d71401e1470a27e0450bb8001878793d11ea4b4133ede601',1000.0);
INSERT INTO "review_reads" VALUES(5,'rev-65b5b0f9e36fdb1b38fab4ca','ev-15c7c61a988e36bac7efc31e','{"finding":"finding-440cc2bad6a1de3ea75400d0","revision":2,"block":null,"start":0,"returned_characters":3080,"total_characters":3080}','b65d2f8ed6e4f3e116b3aaecc99abd1ef0d8ac69597ff182f88329d55b3bd464',1000.0);
INSERT INTO "review_reads" VALUES(6,'rev-65b5b0f9e36fdb1b38fab4ca','ev-69d841962ddc04d16e727ebf','{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99","run":"r1","block":null,"start":0,"returned_characters":48,"total_characters":48}','f6901ae1e9130504c9d85e01cf39d51913ebe2cf66742e51840ecd29ddae973c',1000.0);
INSERT INTO "review_reads" VALUES(7,'rev-65b5b0f9e36fdb1b38fab4ca','ev-e515db78eaaa911eaf1aba99','{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635","run":"r1","block":null,"start":0,"returned_characters":48,"total_characters":48}','e117b4634ffb48360158bb088f37593c19c9454ad868d2033544fc301aa1bf92',1000.0);
INSERT INTO "review_reads" VALUES(8,'rev-65b5b0f9e36fdb1b38fab4ca','ev-a9ae4b84c830fe41295ae6f7','{"document":"doc-ed8581e68ef9d205cd12249f","revision":1,"sha256":"cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9","run":"r1","block":null,"start":0,"returned_characters":45,"total_characters":45}','9a813d784f388e0c4b78d9959b901e82e03d2284bc64cc5295eed740e35b4f04',1000.0);
INSERT INTO "review_reads" VALUES(9,'rev-65b5b0f9e36fdb1b38fab4ca','ev-9369e0639f34743b55fd5030','{"document":"doc-f51aef9e079c43038da9b3d0","revision":1,"sha256":"4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820","run":"r1","block":null,"start":0,"returned_characters":45,"total_characters":45}','670963449c5a9624965c5a35621db06b67adb1fa9fe7f4de32fd4043a54fa928',1000.0);
INSERT INTO "review_reads" VALUES(10,'rev-65b5b0f9e36fdb1b38fab4ca','ev-8735794ce8173977dfa499f7','{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3","run":"r1","block":null,"start":0,"returned_characters":50,"total_characters":50}','ed71f76be377c2af7bd8688a8864ad40c8758fa0e04efb3df68df143fb7b6e05',1000.0);
INSERT INTO "review_reads" VALUES(11,'rev-1d606daeb93532ef94420dbe','ev-715dd7f4c70ae3eafd46087f','{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99","block":null,"start":0,"returned_characters":48,"total_characters":48}','b44de9768f1de0e8e2de2dfc6f51ff29edc0f54494507a614d5f388b3997ef55',1000.0);
INSERT INTO "review_reads" VALUES(12,'rev-1d606daeb93532ef94420dbe','ev-db347e05e3d422220b0821a8','{"run":"author-1","message":1,"block":null,"start":0,"returned_characters":49,"total_characters":49}','c0db7bf969c34b589abaaf54410204269b59f0e2c8af1188f93067f0d02a534e',1000.0);
INSERT INTO "review_reads" VALUES(13,'rev-1d606daeb93532ef94420dbe','ev-7feefae7abc1aa0c395f164e','{"finding":"finding-5b46fc960bd07409ddc5e6d6","revision":2,"block":null,"start":0,"returned_characters":3142,"total_characters":3142}','98f3ac5189881d3d3db5b0fd1ef84b4206011c5d257b622f4ee31e54e762612e',1000.0);
INSERT INTO "review_reads" VALUES(14,'rev-1d606daeb93532ef94420dbe','ev-1dce4c6c0d53b3b579304813','{"finding":"finding-2035ab2709c5671355e3f59f","revision":2,"block":null,"start":0,"returned_characters":2307,"total_characters":2307}','cd086b8071e5dd57d71401e1470a27e0450bb8001878793d11ea4b4133ede601',1000.0);
INSERT INTO "review_reads" VALUES(15,'rev-1d606daeb93532ef94420dbe','ev-6122792d5a2ca0bb9d973dcd','{"finding":"finding-440cc2bad6a1de3ea75400d0","revision":2,"block":null,"start":0,"returned_characters":3080,"total_characters":3080}','b65d2f8ed6e4f3e116b3aaecc99abd1ef0d8ac69597ff182f88329d55b3bd464',1000.0);
INSERT INTO "review_reads" VALUES(16,'rev-1d606daeb93532ef94420dbe','ev-b2d2e3e0dc766a4b46e930a0','{"finding":"finding-da4788c18fb518061f270269","revision":3,"block":null,"start":0,"returned_characters":1254,"total_characters":1254}','fa48cf27854c766e00df6de34a1bab714101e7e9e68b82a6f01fab4772ea2cc0',1000.0);
INSERT INTO "review_reads" VALUES(17,'rev-1d606daeb93532ef94420dbe','ev-a9ae4b84c830fe41295ae6f7','{"document":"doc-ed8581e68ef9d205cd12249f","revision":1,"sha256":"cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9","run":"r1","block":null,"start":0,"returned_characters":45,"total_characters":45}','9a813d784f388e0c4b78d9959b901e82e03d2284bc64cc5295eed740e35b4f04',1000.0);
INSERT INTO "review_reads" VALUES(18,'rev-1d606daeb93532ef94420dbe','ev-9369e0639f34743b55fd5030','{"document":"doc-f51aef9e079c43038da9b3d0","revision":1,"sha256":"4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820","run":"r1","block":null,"start":0,"returned_characters":45,"total_characters":45}','670963449c5a9624965c5a35621db06b67adb1fa9fe7f4de32fd4043a54fa928',1000.0);
INSERT INTO "review_reads" VALUES(19,'rev-1d606daeb93532ef94420dbe','ev-69d841962ddc04d16e727ebf','{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99","run":"r1","block":null,"start":0,"returned_characters":48,"total_characters":48}','f6901ae1e9130504c9d85e01cf39d51913ebe2cf66742e51840ecd29ddae973c',1000.0);
INSERT INTO "review_reads" VALUES(20,'rev-1d606daeb93532ef94420dbe','ev-e515db78eaaa911eaf1aba99','{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635","run":"r1","block":null,"start":0,"returned_characters":48,"total_characters":48}','e117b4634ffb48360158bb088f37593c19c9454ad868d2033544fc301aa1bf92',1000.0);
INSERT INTO "review_reads" VALUES(21,'rev-1d606daeb93532ef94420dbe','ev-8735794ce8173977dfa499f7','{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3","run":"r1","block":null,"start":0,"returned_characters":50,"total_characters":50}','ed71f76be377c2af7bd8688a8864ad40c8758fa0e04efb3df68df143fb7b6e05',1000.0);
INSERT INTO "review_reads" VALUES(22,'rev-1d606daeb93532ef94420dbe','ev-6d18bf643dd1426481366ea5','{"finding":"finding-da4788c18fb518061f270269","revision":2,"block":null,"start":0,"returned_characters":3230,"total_characters":3230}','81fdd0411f941b9a61fbc964421701b72f1d6bafd36fe845f633eeac2350a165',1000.0);
CREATE TABLE review_records (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    review_id TEXT NOT NULL REFERENCES review_runs(review_id),
    kind TEXT NOT NULL,payload TEXT NOT NULL,created REAL NOT NULL) STRICT;
INSERT INTO "review_records" VALUES(1,'rev-42cd1418d0397f536f335de6','finding','{"finding_id":"finding-da4788c18fb518061f270269","status":"open","revision":1,"reflags":0}',1000.0);
INSERT INTO "review_records" VALUES(2,'rev-42cd1418d0397f536f335de6','finding','{"finding_id":"finding-5b46fc960bd07409ddc5e6d6","status":"open","revision":1,"reflags":0}',1000.0);
INSERT INTO "review_records" VALUES(3,'rev-42cd1418d0397f536f335de6','finding','{"finding_id":"finding-2035ab2709c5671355e3f59f","status":"open","revision":1,"reflags":0}',1000.0);
INSERT INTO "review_records" VALUES(4,'rev-42cd1418d0397f536f335de6','finding','{"finding_id":"finding-440cc2bad6a1de3ea75400d0","status":"open","revision":1,"reflags":0}',1000.0);
INSERT INTO "review_records" VALUES(5,'rev-1d606daeb93532ef94420dbe','finding','{"finding_id":"finding-440cc2bad6a1de3ea75400d0","status":"unaddressed","revision":4,"reflags":2}',1000.0);
CREATE TABLE "review_response_bodies" (
    source TEXT NOT NULL CHECK (length(CAST(source AS BLOB)) BETWEEN 1 AND 128),
    finding_id TEXT NOT NULL CHECK (length(CAST(finding_id AS BLOB)) BETWEEN 1 AND 128),
    decision_revision INTEGER NOT NULL CHECK (decision_revision BETWEEN 1 AND 999999999),
    revision INTEGER NOT NULL CHECK (revision BETWEEN 1 AND 999999999),
    body TEXT NOT NULL CHECK (length(CAST(body AS BLOB)) <= 32768),
    sha256 TEXT NOT NULL CHECK (length(sha256) = 64 AND sha256 NOT GLOB '*[^0-9a-f]*'),
    block_map TEXT NOT NULL
        CHECK (json_valid(block_map) AND length(CAST(block_map AS BLOB)) <= 16777216),
    author TEXT NOT NULL
        CHECK (json_valid(author) AND length(CAST(author AS BLOB)) <= 8192),
    owners TEXT NOT NULL
        CHECK (json_valid(owners) AND length(CAST(owners AS BLOB)) <= 16777216),
    next_block INTEGER NOT NULL CHECK (next_block BETWEEN 0 AND 999999999),
    next_span INTEGER NOT NULL CHECK (next_span BETWEEN 0 AND 999999999),
    identity_floor INTEGER NOT NULL CHECK (identity_floor BETWEEN 1 AND revision),
    held TEXT CHECK (held IS NULL OR length(CAST(held AS BLOB)) <= 4096),
    PRIMARY KEY(source,revision),
    FOREIGN KEY(finding_id,decision_revision) REFERENCES review_transitions(finding_id,revision))
    STRICT;
INSERT INTO "review_response_bodies" VALUES('response:finding-da4788c18fb518061f270269:r2:explanation','finding-da4788c18fb518061f270269',2,1,'Fixed $\F$ here','7d3423f86984a470f1a769d75230ce802593fd649e3cfd210710edfeee83bf0b','{"profile":"ss-markdown-2","blocks":[{"id":"b1","kind":"paragraph","parent":null,"lines":[0,1],"start":0,"end":15,"hash":"7d3423f86984a470f1a769d75230ce802593fd649e3cfd210710edfeee83bf0b","status":"added","structural":null,"attrs":{},"spans":[{"id":"m1","kind":"inline","hash":"366584274fbf870007b1f943904f3abeb1009ebf1c4e14e09051b64ed44a96d2","status":"added"}]}],"removed":[],"removed_spans":[],"identity_floor":1}','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}','{"b1":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}}}',1,1,1,NULL);
INSERT INTO "review_response_bodies" VALUES('response:finding-5b46fc960bd07409ddc5e6d6:r2:explanation','finding-5b46fc960bd07409ddc5e6d6',2,1,'Not so: $\F$','8f81adb3d27478ae3ce0dbc859f644b230e6366968eaab1d34b395fd37fb5fca','{"profile":"ss-markdown-2","blocks":[{"id":"b1","kind":"paragraph","parent":null,"lines":[0,1],"start":0,"end":12,"hash":"8f81adb3d27478ae3ce0dbc859f644b230e6366968eaab1d34b395fd37fb5fca","status":"added","structural":null,"attrs":{},"spans":[{"id":"m1","kind":"inline","hash":"366584274fbf870007b1f943904f3abeb1009ebf1c4e14e09051b64ed44a96d2","status":"added"}]}],"removed":[],"removed_spans":[],"identity_floor":1}','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}','{"b1":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}}}',1,1,1,NULL);
INSERT INTO "review_response_bodies" VALUES('response:finding-2035ab2709c5671355e3f59f:r2:explanation','finding-2035ab2709c5671355e3f59f',2,1,'Legacy $\F$','87456495ae7a5ad905798bc8a5005cf8e8d1389df8a1c48602199acb6fd00a32','{"profile":"ss-markdown-2","blocks":[{"id":"b1","kind":"paragraph","parent":null,"lines":[0,1],"start":0,"end":11,"hash":"87456495ae7a5ad905798bc8a5005cf8e8d1389df8a1c48602199acb6fd00a32","status":"added","structural":null,"attrs":{},"spans":[{"id":"m1","kind":"inline","hash":"366584274fbf870007b1f943904f3abeb1009ebf1c4e14e09051b64ed44a96d2","status":"added"}]}],"removed":[],"removed_spans":[],"identity_floor":1}','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}','{"b1":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}}}',1,1,1,NULL);
INSERT INTO "review_response_bodies" VALUES('response:finding-440cc2bad6a1de3ea75400d0:r2:explanation','finding-440cc2bad6a1de3ea75400d0',2,1,'Reorder $\F$','1fdfac3bc7e9978cfa3690af5ff0c07502ed6298f2794f3e5e315c5b4a8b1dfc','{"profile":"ss-markdown-2","blocks":[{"id":"b1","kind":"paragraph","parent":null,"lines":[0,1],"start":0,"end":12,"hash":"1fdfac3bc7e9978cfa3690af5ff0c07502ed6298f2794f3e5e315c5b4a8b1dfc","status":"added","structural":null,"attrs":{},"spans":[{"id":"m1","kind":"inline","hash":"366584274fbf870007b1f943904f3abeb1009ebf1c4e14e09051b64ed44a96d2","status":"added"}]}],"removed":[],"removed_spans":[],"identity_floor":1}','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}','{"b1":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}}}',1,1,1,NULL);
INSERT INTO "review_response_bodies" VALUES('response:finding-da4788c18fb518061f270269:r2:explanation','finding-da4788c18fb518061f270269',2,2,'Edited $\F + \G$','22521436510afa8d68f19b1a347f23544228a2c0cc22de3f29b4851a4f310af6','{"profile":"ss-markdown-2","blocks":[{"id":"b1","kind":"paragraph","parent":null,"lines":[0,1],"start":0,"end":16,"hash":"22521436510afa8d68f19b1a347f23544228a2c0cc22de3f29b4851a4f310af6","status":"changed","structural":null,"attrs":{},"spans":[{"id":"m1","kind":"inline","hash":"3cef1f1a5baa8b88f1ef063dc4adaadafb40d74af93d29f75f3d70954c0b84f0","status":"changed"}]}],"removed":[],"removed_spans":[],"identity_floor":1}','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}','{"b1":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}}}',1,1,1,NULL);
INSERT INTO "review_response_bodies" VALUES('response:finding-2035ab2709c5671355e3f59f:r2:explanation','finding-2035ab2709c5671355e3f59f',2,2,'Edited $\F + \G$','22521436510afa8d68f19b1a347f23544228a2c0cc22de3f29b4851a4f310af6','{"profile":"ss-markdown-2","blocks":[{"id":"b1","kind":"paragraph","parent":null,"lines":[0,1],"start":0,"end":16,"hash":"22521436510afa8d68f19b1a347f23544228a2c0cc22de3f29b4851a4f310af6","status":"changed","structural":null,"attrs":{},"spans":[{"id":"m1","kind":"inline","hash":"3cef1f1a5baa8b88f1ef063dc4adaadafb40d74af93d29f75f3d70954c0b84f0","status":"changed"}]}],"removed":[],"removed_spans":[],"identity_floor":1}','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}','{"b1":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}}}',1,1,1,NULL);
CREATE TABLE "review_response_discovery" (
    transition_seq INTEGER PRIMARY KEY,
    finding_id TEXT NOT NULL CHECK (length(CAST(finding_id AS BLOB)) BETWEEN 1 AND 128),
    decision_revision INTEGER NOT NULL CHECK (decision_revision BETWEEN 1 AND 999999999),
    reason TEXT NOT NULL CHECK (length(CAST(reason AS BLOB)) <= 4096),
    UNIQUE(finding_id,decision_revision),
    FOREIGN KEY(finding_id,decision_revision) REFERENCES review_transitions(finding_id,revision))
    STRICT;
CREATE TABLE "review_response_pins" (
    review_id TEXT NOT NULL REFERENCES review_runs(review_id),
    finding_id TEXT NOT NULL CHECK (length(CAST(finding_id AS BLOB)) BETWEEN 1 AND 128),
    decision_revision INTEGER NOT NULL CHECK (decision_revision BETWEEN 1 AND 999999999),
    body_revision INTEGER NOT NULL CHECK (body_revision BETWEEN 0 AND 999999999),
    sha256 TEXT NOT NULL CHECK (length(sha256) = 64 AND sha256 NOT GLOB '*[^0-9a-f]*'),
    PRIMARY KEY(review_id,finding_id),
    FOREIGN KEY(finding_id,decision_revision) REFERENCES review_transitions(finding_id,revision))
    STRICT;
INSERT INTO "review_response_pins" VALUES('rev-65b5b0f9e36fdb1b38fab4ca','finding-da4788c18fb518061f270269',2,2,'22521436510afa8d68f19b1a347f23544228a2c0cc22de3f29b4851a4f310af6');
INSERT INTO "review_response_pins" VALUES('rev-65b5b0f9e36fdb1b38fab4ca','finding-5b46fc960bd07409ddc5e6d6',2,1,'8f81adb3d27478ae3ce0dbc859f644b230e6366968eaab1d34b395fd37fb5fca');
INSERT INTO "review_response_pins" VALUES('rev-65b5b0f9e36fdb1b38fab4ca','finding-2035ab2709c5671355e3f59f',2,2,'22521436510afa8d68f19b1a347f23544228a2c0cc22de3f29b4851a4f310af6');
INSERT INTO "review_response_pins" VALUES('rev-65b5b0f9e36fdb1b38fab4ca','finding-440cc2bad6a1de3ea75400d0',2,1,'1fdfac3bc7e9978cfa3690af5ff0c07502ed6298f2794f3e5e315c5b4a8b1dfc');
INSERT INTO "review_response_pins" VALUES('rev-1d606daeb93532ef94420dbe','finding-5b46fc960bd07409ddc5e6d6',2,1,'8f81adb3d27478ae3ce0dbc859f644b230e6366968eaab1d34b395fd37fb5fca');
INSERT INTO "review_response_pins" VALUES('rev-1d606daeb93532ef94420dbe','finding-2035ab2709c5671355e3f59f',2,2,'22521436510afa8d68f19b1a347f23544228a2c0cc22de3f29b4851a4f310af6');
INSERT INTO "review_response_pins" VALUES('rev-1d606daeb93532ef94420dbe','finding-440cc2bad6a1de3ea75400d0',2,1,'1fdfac3bc7e9978cfa3690af5ff0c07502ed6298f2794f3e5e315c5b4a8b1dfc');
CREATE TABLE review_runs (
    review_id TEXT PRIMARY KEY,project TEXT NOT NULL,session TEXT NOT NULL,kind TEXT NOT NULL,
    author_run TEXT NOT NULL,owner TEXT NOT NULL,state TEXT NOT NULL,start_seq INTEGER NOT NULL,
    end_seq INTEGER NOT NULL,created REAL NOT NULL,ended REAL,lease_until REAL,
    alias TEXT,resolved_model TEXT,rubric TEXT NOT NULL,config TEXT NOT NULL,
    config_revision TEXT NOT NULL,classifier TEXT NOT NULL,summary TEXT NOT NULL DEFAULT '',
    cap_reached INTEGER NOT NULL DEFAULT 0,input_tokens INTEGER NOT NULL DEFAULT 0,
    output_tokens INTEGER NOT NULL DEFAULT 0,estimated_tokens INTEGER NOT NULL DEFAULT 0,
    calls INTEGER NOT NULL DEFAULT 0,coverage_complete INTEGER NOT NULL,
    confirmation_key TEXT) STRICT;
INSERT INTO "review_runs" VALUES('rev-42cd1418d0397f536f335de6','p','s','terminal','author-1','owner','findings',1,9,1000.0,1000.0,NULL,'reviewer',NULL,'sandbox-consistency-1','{"enabled":true,"min_interval_seconds":120.0,"text_characters":2000,"artifact_revisions":3,"kernel_cells":40,"kernel_interval_seconds":1800.0,"terminal_hold":true,"interrupt_severity":"fail","response_rounds":2,"max_reflags":2,"max_findings":10,"max_turns":12,"time_seconds":120.0,"max_input_chars":150000,"max_output_chars":16000,"token_budget":64000,"calls_per_hour":60}','5c9903ae5c2b60db53d380e7ed642161ee9c2ce7de74065648cbac7ba2dc1b1c','{}','Original review',0,0,0,0,0,1,NULL);
INSERT INTO "review_runs" VALUES('rev-65b5b0f9e36fdb1b38fab4ca','p','s','confirmation','author-1','owner','findings',10,9,1000.0,1000.0,NULL,'reviewer',NULL,'sandbox-consistency-1','{"enabled":true,"min_interval_seconds":120.0,"text_characters":2000,"artifact_revisions":3,"kernel_cells":40,"kernel_interval_seconds":1800.0,"terminal_hold":true,"interrupt_severity":"fail","response_rounds":2,"max_reflags":2,"max_findings":10,"max_turns":12,"time_seconds":120.0,"max_input_chars":150000,"max_output_chars":16000,"token_budget":64000,"calls_per_hour":60}','5c9903ae5c2b60db53d380e7ed642161ee9c2ce7de74065648cbac7ba2dc1b1c','{}','Confirmation',0,0,0,0,0,0,'20250573e43b88a117ea444ac026632b4a9ddd05f030181ab190cbfe6022bf61');
INSERT INTO "review_runs" VALUES('rev-1d606daeb93532ef94420dbe','p','s','terminal','author-1','owner','findings',10,11,1000.0,1000.0,NULL,'reviewer',NULL,'sandbox-consistency-1','{"enabled":true,"min_interval_seconds":120.0,"text_characters":2000,"artifact_revisions":3,"kernel_cells":40,"kernel_interval_seconds":1800.0,"terminal_hold":true,"interrupt_severity":"fail","response_rounds":2,"max_reflags":2,"max_findings":10,"max_turns":12,"time_seconds":120.0,"max_input_chars":150000,"max_output_chars":16000,"token_budget":64000,"calls_per_hour":60}','5c9903ae5c2b60db53d380e7ed642161ee9c2ce7de74065648cbac7ba2dc1b1c','{}','Second review',0,0,0,0,0,0,NULL);
CREATE TABLE review_transitions (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    finding_id TEXT NOT NULL REFERENCES review_findings(finding_id),
    revision INTEGER NOT NULL,status TEXT NOT NULL,actor TEXT NOT NULL,reason TEXT NOT NULL,
    payload TEXT NOT NULL,created REAL NOT NULL,UNIQUE(finding_id,revision)) STRICT;
INSERT INTO "review_transitions" VALUES(1,'finding-fc52622e4f87078760aa6f5e',1,'open','platform:math','Unknown command','{"check":"math-c58332d069b276776d8206e1","anchors":[{"check":"math-c58332d069b276776d8206e1","locator":{"document":"doc-58b9197efd52aaaaf2628f77","revision":1},"block":"b1","math":"m1","sha256":"7fcace58933d4f12f56947f2b6ecadd1f90f62a88419d1efe1735389d1c2d2b9","complete":true}],"owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"action":"mechanical_rejection"}',1000.0);
INSERT INTO "review_transitions" VALUES(2,'finding-e157e420507d284c5f22e341',1,'open','platform:math','Unknown command','{"check":"math-c58332d069b276776d8206e1","anchors":[{"check":"math-c58332d069b276776d8206e1","locator":{"document":"doc-58b9197efd52aaaaf2628f77","revision":1},"block":"b1","math":"m2","sha256":"7fcace58933d4f12f56947f2b6ecadd1f90f62a88419d1efe1735389d1c2d2b9","complete":true}],"owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"action":"mechanical_rejection"}',1000.0);
INSERT INTO "review_transitions" VALUES(3,'finding-fc52622e4f87078760aa6f5e',2,'open','platform:math','Unknown command','{"check":"math-50b2cd794ed66f760f8186a0","anchors":[{"check":"math-50b2cd794ed66f760f8186a0","locator":{"document":"doc-58b9197efd52aaaaf2628f77","revision":2},"block":"b1","math":"m1","sha256":"ac6576e1e89ad370183e2dea65ddc756024b91f6dcb350cc8639e091be739f6b","complete":true}],"action":"mechanical_reflag","previous_session":"s","previous_owner_revision":1,"block_edit_proven":true,"owner":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}}}',1000.0);
INSERT INTO "review_transitions" VALUES(4,'finding-e157e420507d284c5f22e341',2,'open','platform:math','Unknown command','{"check":"math-50b2cd794ed66f760f8186a0","anchors":[{"check":"math-50b2cd794ed66f760f8186a0","locator":{"document":"doc-58b9197efd52aaaaf2628f77","revision":2},"block":"b1","math":"m2","sha256":"ac6576e1e89ad370183e2dea65ddc756024b91f6dcb350cc8639e091be739f6b","complete":true}],"action":"mechanical_reflag","previous_session":"s","previous_owner_revision":1,"block_edit_proven":true,"owner":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}}}',1000.0);
INSERT INTO "review_transitions" VALUES(5,'finding-fc52622e4f87078760aa6f5e',3,'open','platform:math','Unknown command','{"check":"math-be63c39f5fbc76967857983f","anchors":[{"check":"math-be63c39f5fbc76967857983f","locator":{"document":"doc-58b9197efd52aaaaf2628f77","revision":2},"block":"b1","math":"m1","sha256":"ac6576e1e89ad370183e2dea65ddc756024b91f6dcb350cc8639e091be739f6b","complete":true}],"action":"mechanical_dependency_refresh","previous_session":"s","previous_owner_revision":2,"block_edit_proven":false,"owner":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}}}',1000.0);
INSERT INTO "review_transitions" VALUES(6,'finding-e157e420507d284c5f22e341',3,'open','platform:math','Unknown command','{"check":"math-be63c39f5fbc76967857983f","anchors":[{"check":"math-be63c39f5fbc76967857983f","locator":{"document":"doc-58b9197efd52aaaaf2628f77","revision":2},"block":"b1","math":"m2","sha256":"ac6576e1e89ad370183e2dea65ddc756024b91f6dcb350cc8639e091be739f6b","complete":true}],"action":"mechanical_dependency_refresh","previous_session":"s","previous_owner_revision":2,"block_edit_proven":false,"owner":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}}}',1000.0);
INSERT INTO "review_transitions" VALUES(7,'finding-da4788c18fb518061f270269',1,'open','review:rev-42cd1418d0397f536f335de6','Reviewer raised this finding.','{"review":"rev-42cd1418d0397f536f335de6","assessment":{"review_id":"rev-42cd1418d0397f536f335de6","severity":"fail","category":"contradicting_value","statement":"Anchored statement.","anchors":[{"evidence":"ev-69d841962ddc04d16e727ebf","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99","run":"r1"},"sha256":"f6901ae1e9130504c9d85e01cf39d51913ebe2cf66742e51840ecd29ddae973c","complete":true},{"evidence":"ev-e515db78eaaa911eaf1aba99","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635","run":"r1"},"sha256":"e117b4634ffb48360158bb088f37593c19c9454ad868d2033544fc301aa1bf92","complete":true}],"remedy":null}}',1000.0);
INSERT INTO "review_transitions" VALUES(8,'finding-5b46fc960bd07409ddc5e6d6',1,'open','review:rev-42cd1418d0397f536f335de6','Reviewer raised this finding.','{"review":"rev-42cd1418d0397f536f335de6","assessment":{"review_id":"rev-42cd1418d0397f536f335de6","severity":"fail","category":"contradicting_value","statement":"Anchored statement.","anchors":[{"evidence":"ev-a9ae4b84c830fe41295ae6f7","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-ed8581e68ef9d205cd12249f","revision":1,"sha256":"cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9","run":"r1"},"sha256":"9a813d784f388e0c4b78d9959b901e82e03d2284bc64cc5295eed740e35b4f04","complete":true},{"evidence":"ev-9369e0639f34743b55fd5030","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-f51aef9e079c43038da9b3d0","revision":1,"sha256":"4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820","run":"r1"},"sha256":"670963449c5a9624965c5a35621db06b67adb1fa9fe7f4de32fd4043a54fa928","complete":true}],"remedy":null}}',1000.0);
INSERT INTO "review_transitions" VALUES(9,'finding-2035ab2709c5671355e3f59f',1,'open','review:rev-42cd1418d0397f536f335de6','Reviewer raised this finding.','{"review":"rev-42cd1418d0397f536f335de6","assessment":{"review_id":"rev-42cd1418d0397f536f335de6","severity":"fail","category":"contradicting_value","statement":"Anchored statement.","anchors":[{"evidence":"ev-69d841962ddc04d16e727ebf","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99","run":"r1"},"sha256":"f6901ae1e9130504c9d85e01cf39d51913ebe2cf66742e51840ecd29ddae973c","complete":true}],"remedy":null}}',1000.0);
INSERT INTO "review_transitions" VALUES(10,'finding-440cc2bad6a1de3ea75400d0',1,'open','review:rev-42cd1418d0397f536f335de6','Reviewer raised this finding.','{"review":"rev-42cd1418d0397f536f335de6","assessment":{"review_id":"rev-42cd1418d0397f536f335de6","severity":"fail","category":"contradicting_value","statement":"Anchored statement.","anchors":[{"evidence":"ev-e515db78eaaa911eaf1aba99","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635","run":"r1"},"sha256":"e117b4634ffb48360158bb088f37593c19c9454ad868d2033544fc301aa1bf92","complete":true},{"evidence":"ev-8735794ce8173977dfa499f7","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3","run":"r1"},"sha256":"ed71f76be377c2af7bd8688a8864ad40c8758fa0e04efb3df68df143fb7b6e05","complete":true}],"remedy":null}}',1000.0);
INSERT INTO "review_transitions" VALUES(11,'finding-da4788c18fb518061f270269',2,'claimed fixed','session:s','Fixed $\F$ here','{"action":"fix","explanation":"Fixed $\\F$ here","anchors":[],"revisions":[{"document":"doc-0f819e0cfea434b82ffc8823","revision":1,"sha256":"165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99"}],"artifact_revisions":[],"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}}',1000.0);
INSERT INTO "review_transitions" VALUES(12,'finding-5b46fc960bd07409ddc5e6d6',2,'open','session:s','Not so: $\F$','{"action":"rebut","explanation":"Not so: $\\F$","anchors":[],"revisions":[],"artifact_revisions":[],"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}}',1000.0);
INSERT INTO "review_transitions" VALUES(13,'finding-2035ab2709c5671355e3f59f',2,'open','session:s','Legacy $\F$','{"action":"rebut","explanation":"Legacy $\\F$","anchors":[],"revisions":[],"artifact_revisions":[],"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}}',1000.0);
INSERT INTO "review_transitions" VALUES(14,'finding-440cc2bad6a1de3ea75400d0',2,'open','session:s','Reorder $\F$','{"action":"rebut","explanation":"Reorder $\\F$","anchors":[],"revisions":[],"artifact_revisions":[],"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}}',1000.0);
INSERT INTO "review_transitions" VALUES(15,'finding-fc52622e4f87078760aa6f5e',4,'confirmed fixed','platform:math','The exact current formula was accepted by the configured renderer.','{"check":"math-ef2c3ae78cbce2dee9b77890","document_revision":2,"action":"mechanical_accept"}',1000.0);
INSERT INTO "review_transitions" VALUES(16,'finding-e157e420507d284c5f22e341',4,'confirmed fixed','platform:math','The exact current formula was accepted by the configured renderer.','{"check":"math-ef2c3ae78cbce2dee9b77890","document_revision":2,"action":"mechanical_accept"}',1000.0);
INSERT INTO "review_transitions" VALUES(17,'finding-da4788c18fb518061f270269',3,'inconclusive','review:rev-65b5b0f9e36fdb1b38fab4ca','Cannot tell.','{"review":"rev-65b5b0f9e36fdb1b38fab4ca","anchors":[{"evidence":"ev-6d18bf643dd1426481366ea5","review":"rev-65b5b0f9e36fdb1b38fab4ca","locator":{"finding":"finding-da4788c18fb518061f270269","revision":2},"sha256":"81fdd0411f941b9a61fbc964421701b72f1d6bafd36fe845f633eeac2350a165","complete":true}],"decision":"inconclusive"}',1000.0);
INSERT INTO "review_transitions" VALUES(18,'finding-440cc2bad6a1de3ea75400d0',3,'open','review:rev-1d606daeb93532ef94420dbe','The rebuttal does not hold.','{"review":"rev-1d606daeb93532ef94420dbe","anchors":[{"evidence":"ev-6122792d5a2ca0bb9d973dcd","review":"rev-1d606daeb93532ef94420dbe","locator":{"finding":"finding-440cc2bad6a1de3ea75400d0","revision":2},"sha256":"b65d2f8ed6e4f3e116b3aaecc99abd1ef0d8ac69597ff182f88329d55b3bd464","complete":true}],"decision":"reject_rebuttal"}',1000.0);
INSERT INTO "review_transitions" VALUES(19,'finding-440cc2bad6a1de3ea75400d0',4,'unaddressed','review:rev-1d606daeb93532ef94420dbe','Anchored statement.','{"review":"rev-1d606daeb93532ef94420dbe","anchors":[{"evidence":"ev-8735794ce8173977dfa499f7","review":"rev-1d606daeb93532ef94420dbe","locator":{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3","run":"r1"},"sha256":"ed71f76be377c2af7bd8688a8864ad40c8758fa0e04efb3df68df143fb7b6e05","complete":true},{"evidence":"ev-e515db78eaaa911eaf1aba99","review":"rev-1d606daeb93532ef94420dbe","locator":{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635","run":"r1"},"sha256":"e117b4634ffb48360158bb088f37593c19c9454ad868d2033544fc301aa1bf92","complete":true}],"previous_assessment":{"review_id":"rev-42cd1418d0397f536f335de6","severity":"fail","category":"contradicting_value","statement":"Anchored statement.","anchors":[{"evidence":"ev-e515db78eaaa911eaf1aba99","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635","run":"r1"},"sha256":"e117b4634ffb48360158bb088f37593c19c9454ad868d2033544fc301aa1bf92","complete":true},{"evidence":"ev-8735794ce8173977dfa499f7","review":"rev-42cd1418d0397f536f335de6","locator":{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3","run":"r1"},"sha256":"ed71f76be377c2af7bd8688a8864ad40c8758fa0e04efb3df68df143fb7b6e05","complete":true}],"remedy":null},"assessment":{"review_id":"rev-1d606daeb93532ef94420dbe","severity":"fail","category":"contradicting_value","statement":"Anchored statement.","anchors":[{"evidence":"ev-8735794ce8173977dfa499f7","review":"rev-1d606daeb93532ef94420dbe","locator":{"document":"doc-dbd8ffaf1480d8b94d29e9ae","revision":1,"sha256":"1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3","run":"r1"},"sha256":"ed71f76be377c2af7bd8688a8864ad40c8758fa0e04efb3df68df143fb7b6e05","complete":true},{"evidence":"ev-e515db78eaaa911eaf1aba99","review":"rev-1d606daeb93532ef94420dbe","locator":{"document":"doc-adf74e15920f0fb47c0a88f1","revision":1,"sha256":"950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635","run":"r1"},"sha256":"e117b4634ffb48360158bb088f37593c19c9454ad868d2033544fc301aa1bf92","complete":true}],"remedy":null}}',1000.0);
INSERT INTO "review_transitions" VALUES(20,'finding-917db304507211c7b1843d18',1,'open','platform:math','Unknown command','{"check":"math-b59ccb1495d1d5e8aae71190","anchors":[{"check":"math-b59ccb1495d1d5e8aae71190","locator":{"document":"doc-6d5d225787c1ec2d34b50b21","revision":1},"block":"b2","math":"m1","sha256":"79d8e00656390250b526b51dc6b4999ed42b809483609b7572bed89b3bdbb4a9","complete":true}],"owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"action":"mechanical_rejection"}',1000.0);
INSERT INTO "review_transitions" VALUES(21,'finding-f65c492ad291fed66c0bebfc',1,'open','platform:math','Unknown command','{"check":"math-e79382c1c1593b3b340b5757","anchors":[{"check":"math-e79382c1c1593b3b340b5757","locator":{"document":"doc-6d5d225787c1ec2d34b50b21","revision":1,"comment":"cmt-c4fce9bb05f36a81283a26a4","body_revision":1},"block":"b1","math":"m1","sha256":"496550ffe147968e6d256bea2d07983848a5de00c020023ea51db07418bbce42","complete":true}],"owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"action":"mechanical_rejection"}',1000.0);
INSERT INTO "review_transitions" VALUES(22,'finding-fc52622e4f87078760aa6f5e',5,'open','platform:math','Unknown command','{"check":"math-f4d01318b3533f2235bcf545","anchors":[{"check":"math-f4d01318b3533f2235bcf545","locator":{"document":"doc-58b9197efd52aaaaf2628f77","revision":2},"block":"b1","math":"m1","sha256":"ac6576e1e89ad370183e2dea65ddc756024b91f6dcb350cc8639e091be739f6b","complete":true}],"action":"mechanical_dependency_refresh","previous_session":"s","previous_owner_revision":2,"block_edit_proven":false,"owner":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}}}',1000.0);
INSERT INTO "review_transitions" VALUES(23,'finding-e157e420507d284c5f22e341',5,'open','platform:math','Unknown command','{"check":"math-f4d01318b3533f2235bcf545","anchors":[{"check":"math-f4d01318b3533f2235bcf545","locator":{"document":"doc-58b9197efd52aaaaf2628f77","revision":2},"block":"b1","math":"m2","sha256":"ac6576e1e89ad370183e2dea65ddc756024b91f6dcb350cc8639e091be739f6b","complete":true}],"action":"mechanical_dependency_refresh","previous_session":"s","previous_owner_revision":2,"block_edit_proven":false,"owner":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}}}',1000.0);
INSERT INTO "review_transitions" VALUES(24,'finding-76a488db1f7ed0dbeefce52d',1,'open','platform:math','Unknown command','{"check":"math-104a8d905459fea011090c5a","anchors":[{"check":"math-104a8d905459fea011090c5a","locator":{"document":"doc-1e4f0c5c2e394387ce7165fe","revision":1},"block":"b2","math":"m1","sha256":"6c2dc0ee0ced3db7079f1f94ee41a9721245d43cae77a69bec8814c6eb4c91ab","complete":true}],"owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"action":"mechanical_rejection"}',1000.0);
INSERT INTO "review_transitions" VALUES(25,'finding-3cd95b5b437e2f443a804203',1,'open','platform:math','Unknown command','{"check":"math-1300bb97f6f90b0096106700","anchors":[{"check":"math-1300bb97f6f90b0096106700","locator":{"document":"doc-1e4f0c5c2e394387ce7165fe","revision":1,"comment":"cmt-924da581199378bcff722140","body_revision":1},"block":"b1","math":"m1","sha256":"bc77b524efd01ebf2286358d6ca594b228ded4f097152d0bf63edc4a52c79f5f","complete":true}],"owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"action":"mechanical_rejection"}',1000.0);
INSERT INTO "review_transitions" VALUES(26,'finding-f65c492ad291fed66c0bebfc',2,'open','platform:math','Unknown command','{"check":"math-7762893baa2559a0c1f6af96","anchors":[{"check":"math-7762893baa2559a0c1f6af96","locator":{"document":"doc-6d5d225787c1ec2d34b50b21","revision":2,"comment":"cmt-c4fce9bb05f36a81283a26a4","body_revision":1},"block":"b1","math":"m1","sha256":"496550ffe147968e6d256bea2d07983848a5de00c020023ea51db07418bbce42","complete":true}],"action":"mechanical_dependency_refresh","previous_session":"s","previous_owner_revision":1,"block_edit_proven":false,"owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}}}',1000.0);
INSERT INTO "review_transitions" VALUES(27,'finding-dd5709e9bc7427195c843f29',1,'open','platform:math','Unknown command','{"check":"math-b741b94af44bab1010cc993b","anchors":[{"check":"math-b741b94af44bab1010cc993b","locator":{"finding":"finding-da4788c18fb518061f270269","response_revision":2,"field":"explanation","body_revision":2},"block":"b1","math":"m1","sha256":"22521436510afa8d68f19b1a347f23544228a2c0cc22de3f29b4851a4f310af6","complete":true}],"owner":{"revision":2,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"action":"mechanical_rejection"}',1000.0);
INSERT INTO "review_transitions" VALUES(28,'finding-c18690edcf3ea6b28d2346a6',1,'open','platform:math','Unknown command','{"check":"math-68552ac718d6b1250e181062","anchors":[{"check":"math-68552ac718d6b1250e181062","locator":{"finding":"finding-440cc2bad6a1de3ea75400d0","response_revision":2,"field":"explanation","body_revision":1},"block":"b1","math":"m1","sha256":"1fdfac3bc7e9978cfa3690af5ff0c07502ed6298f2794f3e5e315c5b4a8b1dfc","complete":true}],"owner":{"revision":1,"author":{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}},"action":"mechanical_rejection"}',1000.0);
CREATE TABLE review_windows (
    project TEXT NOT NULL,session TEXT NOT NULL,watermark INTEGER NOT NULL DEFAULT 0,
    document_cursor INTEGER NOT NULL DEFAULT 0,last_dispatch REAL,retry_end INTEGER,
    failures INTEGER NOT NULL DEFAULT 0,requested INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY(project,session)) STRICT;
INSERT INTO "review_windows" VALUES('p','s',11,16,1000.0,NULL,0,0);
CREATE TABLE revisions (
    document_id TEXT NOT NULL REFERENCES documents (document_id),
    number INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    author TEXT NOT NULL,
    accepted_by TEXT,
    session_id TEXT,
    base INTEGER,
    parent INTEGER,
    reason TEXT NOT NULL,
    operations TEXT NOT NULL,
    patch_id TEXT,
    text TEXT NOT NULL,
    sha256 TEXT NOT NULL,
    tombstone INTEGER NOT NULL,
    normalized TEXT NOT NULL,
    warnings TEXT NOT NULL,
    block_map TEXT NOT NULL,
    parser TEXT NOT NULL,
    PRIMARY KEY (document_id, number)
) STRICT;
INSERT INTO "revisions" VALUES('doc-58b9197efd52aaaaf2628f77',1,'2026-10-14T20:31:25.100033+00:00','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',NULL,'s',NULL,NULL,'created','[{"op":"create"}]',NULL,'$\unknown{x}$ $\F$

Other.
','7fcace58933d4f12f56947f2b6ecadd1f90f62a88419d1efe1735389d1c2d2b9',0,'{"converted":{},"kept":[]}','[]','{"profile":"ss-markdown-2","blocks":[{"id":"b1","kind":"paragraph","parent":null,"lines":[0,1],"start":0,"end":18,"hash":"61b15e6d86515dffc40f074a8259320ca0347aabfbfbfda5c042a0d7e8176089","status":"added","structural":null,"attrs":{},"spans":[{"id":"m1","kind":"inline","hash":"d5110e8bd1c630479dad4362a3a62a68cb37f33eac2b618d3dcbe4d6cfc833f0","status":"added"},{"id":"m2","kind":"inline","hash":"366584274fbf870007b1f943904f3abeb1009ebf1c4e14e09051b64ed44a96d2","status":"added"}]},{"id":"b2","kind":"paragraph","parent":null,"lines":[2,3],"start":20,"end":26,"hash":"053a32f025d58ba6cd785295dfe89c970672c21114b94ce393fc1ae1a8b21a57","status":"added","structural":null,"attrs":{},"spans":[]}],"removed":[],"removed_spans":[]}','{"profile":"ss-markdown-2","markdown-it-py":"4.2.0","mdit-py-plugins":"0.6.1"}');
INSERT INTO "revisions" VALUES('doc-58b9197efd52aaaaf2628f77',2,'2026-10-14T20:31:25.108131+00:00','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',NULL,'s',1,1,'Edit formula','[{"op":"replace_math","math":"m1","tex":"\\unknown{y}"}]','patch-6c88bc51286db1b1bcceaa9d','$\unknown{y}$ $\F$

Other.
','ac6576e1e89ad370183e2dea65ddc756024b91f6dcb350cc8639e091be739f6b',0,'{"converted":{},"kept":[]}','[]','{"profile":"ss-markdown-2","blocks":[{"id":"b1","kind":"paragraph","parent":null,"lines":[0,1],"start":0,"end":18,"hash":"bd71014bd50198a5eb479809237371559924557d86b620ba18b4615b3c87977c","status":"changed","structural":null,"attrs":{},"spans":[{"id":"m1","kind":"inline","hash":"5da61edb7f5eedafe2f2f22c425faa581cce96e647f74f32b4e84757c6d10ab5","status":"changed"},{"id":"m2","kind":"inline","hash":"366584274fbf870007b1f943904f3abeb1009ebf1c4e14e09051b64ed44a96d2","status":"kept"}]},{"id":"b2","kind":"paragraph","parent":null,"lines":[2,3],"start":20,"end":26,"hash":"053a32f025d58ba6cd785295dfe89c970672c21114b94ce393fc1ae1a8b21a57","status":"kept","structural":null,"attrs":{},"spans":[]}],"removed":[],"removed_spans":[]}','{"profile":"ss-markdown-2","markdown-it-py":"4.2.0","mdit-py-plugins":"0.6.1"}');
INSERT INTO "revisions" VALUES('doc-1e4f0c5c2e394387ce7165fe',1,'2026-10-14T20:31:25.115420+00:00','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',NULL,'s',NULL,NULL,'created','[{"op":"create"}]',NULL,'---
macros:
  ''\F'': ''document''
---

$\F + \G$
','6c2dc0ee0ced3db7079f1f94ee41a9721245d43cae77a69bec8814c6eb4c91ab',0,'{"converted":{},"kept":[]}','[]','{"profile":"ss-markdown-2","blocks":[{"id":"b1","kind":"front_matter","parent":null,"lines":[0,4],"start":0,"end":34,"hash":"5ce5a23ecacec39c381690f0b85b13ae285ff7717f5d877b1b06e4de4c422211","status":"added","structural":null,"attrs":{},"spans":[]},{"id":"b2","kind":"paragraph","parent":null,"lines":[5,6],"start":36,"end":45,"hash":"f37dece42e696d14350c6467a977683fb37dfc87c4ddfaa727a489c7572fca51","status":"added","structural":null,"attrs":{},"spans":[{"id":"m1","kind":"inline","hash":"3cef1f1a5baa8b88f1ef063dc4adaadafb40d74af93d29f75f3d70954c0b84f0","status":"added"}]}],"removed":[],"removed_spans":[]}','{"profile":"ss-markdown-2","markdown-it-py":"4.2.0","mdit-py-plugins":"0.6.1"}');
INSERT INTO "revisions" VALUES('doc-0f819e0cfea434b82ffc8823',1,'2026-10-14T20:31:25.121406+00:00','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',NULL,'s',NULL,NULL,'created','[{"op":"create"}]',NULL,'---
macros:
  ''\F'': ''agreed''
---

Evidence one.
','165104db36542a30dc8a6fce681af727ab620d1bcd3d327137cf37700e474b99',0,'{"converted":{},"kept":[]}','[]','{"profile":"ss-markdown-2","blocks":[{"id":"b1","kind":"front_matter","parent":null,"lines":[0,4],"start":0,"end":32,"hash":"09c3f85e88c309a813b033790d76d137e4465e93c1d0be16a413e555c3aad409","status":"added","structural":null,"attrs":{},"spans":[]},{"id":"b2","kind":"paragraph","parent":null,"lines":[5,6],"start":34,"end":47,"hash":"5c08beca8a1160360bed033cecb3654b0c812f439d3e942ffaedf945dd7e6de0","status":"added","structural":null,"attrs":{},"spans":[]}],"removed":[],"removed_spans":[]}','{"profile":"ss-markdown-2","markdown-it-py":"4.2.0","mdit-py-plugins":"0.6.1"}');
INSERT INTO "revisions" VALUES('doc-adf74e15920f0fb47c0a88f1',1,'2026-10-14T20:31:25.122228+00:00','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',NULL,'s',NULL,NULL,'created','[{"op":"create"}]',NULL,'---
macros:
  ''\F'': ''agreed''
---

Evidence two.
','950210db706557baf2504ca29985b543fa8204556902898b3f1be7707cc34635',0,'{"converted":{},"kept":[]}','[]','{"profile":"ss-markdown-2","blocks":[{"id":"b1","kind":"front_matter","parent":null,"lines":[0,4],"start":0,"end":32,"hash":"09c3f85e88c309a813b033790d76d137e4465e93c1d0be16a413e555c3aad409","status":"added","structural":null,"attrs":{},"spans":[]},{"id":"b2","kind":"paragraph","parent":null,"lines":[5,6],"start":34,"end":47,"hash":"7476ffad47623d8f25b1b2a803cfd1a8d55f7b577934688c2c22ca119f300b94","status":"added","structural":null,"attrs":{},"spans":[]}],"removed":[],"removed_spans":[]}','{"profile":"ss-markdown-2","markdown-it-py":"4.2.0","mdit-py-plugins":"0.6.1"}');
INSERT INTO "revisions" VALUES('doc-ed8581e68ef9d205cd12249f',1,'2026-10-14T20:31:25.123009+00:00','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',NULL,'s',NULL,NULL,'created','[{"op":"create"}]',NULL,'---
macros:
  ''\F'': ''one''
---

Conflict one.
','cf3937bb3d86ae0f1426e27bfd8e73f0c6d56f16c1c4612850fa150fe92c95b9',0,'{"converted":{},"kept":[]}','[]','{"profile":"ss-markdown-2","blocks":[{"id":"b1","kind":"front_matter","parent":null,"lines":[0,4],"start":0,"end":29,"hash":"5574fa215fa17c71b42b4a175d617bedea4e8528e5c979ebd3ee8f6079bb8a50","status":"added","structural":null,"attrs":{},"spans":[]},{"id":"b2","kind":"paragraph","parent":null,"lines":[5,6],"start":31,"end":44,"hash":"2cb6058a8f6158a8e8987049cd0a340cc1bb1d0bec0b0e2d57b0dc275a6ade82","status":"added","structural":null,"attrs":{},"spans":[]}],"removed":[],"removed_spans":[]}','{"profile":"ss-markdown-2","markdown-it-py":"4.2.0","mdit-py-plugins":"0.6.1"}');
INSERT INTO "revisions" VALUES('doc-f51aef9e079c43038da9b3d0',1,'2026-10-14T20:31:25.123760+00:00','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',NULL,'s',NULL,NULL,'created','[{"op":"create"}]',NULL,'---
macros:
  ''\F'': ''two''
---

Conflict two.
','4fe24421496c1f74fb8620f8c78b9278ea0aba16fa3b6a1aefa0bcc0fed7e820',0,'{"converted":{},"kept":[]}','[]','{"profile":"ss-markdown-2","blocks":[{"id":"b1","kind":"front_matter","parent":null,"lines":[0,4],"start":0,"end":29,"hash":"11d2a3657011eab5e87ce86318cb8da7fc5ddba1b989d1109e03d0a472d94748","status":"added","structural":null,"attrs":{},"spans":[]},{"id":"b2","kind":"paragraph","parent":null,"lines":[5,6],"start":31,"end":44,"hash":"46413852031aa46e1323fcbc092cfa19076edece893710f08e0338f59b914ad9","status":"added","structural":null,"attrs":{},"spans":[]}],"removed":[],"removed_spans":[]}','{"profile":"ss-markdown-2","markdown-it-py":"4.2.0","mdit-py-plugins":"0.6.1"}');
INSERT INTO "revisions" VALUES('doc-dbd8ffaf1480d8b94d29e9ae',1,'2026-10-14T20:31:25.124515+00:00','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',NULL,'s',NULL,NULL,'created','[{"op":"create"}]',NULL,'---
macros:
  ''\F'': ''agreed''
---

Evidence three.
','1430a1db000d98b960f13059c117c735e928b5e66225774741428d390fdfadf3',0,'{"converted":{},"kept":[]}','[]','{"profile":"ss-markdown-2","blocks":[{"id":"b1","kind":"front_matter","parent":null,"lines":[0,4],"start":0,"end":32,"hash":"09c3f85e88c309a813b033790d76d137e4465e93c1d0be16a413e555c3aad409","status":"added","structural":null,"attrs":{},"spans":[]},{"id":"b2","kind":"paragraph","parent":null,"lines":[5,6],"start":34,"end":49,"hash":"e456bc3db005d3b7fb1f4239d5d7aa5a63767187c9be18ad772e4f39b1d89acc","status":"added","structural":null,"attrs":{},"spans":[]}],"removed":[],"removed_spans":[]}','{"profile":"ss-markdown-2","markdown-it-py":"4.2.0","mdit-py-plugins":"0.6.1"}');
INSERT INTO "revisions" VALUES('doc-6d5d225787c1ec2d34b50b21',1,'2026-10-14T20:31:25.227222+00:00','{"kind":"agent","user":null,"session_id":"s","run_id":"r1","role":"main","model":"scripted","alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',NULL,'s',NULL,NULL,'created','[{"op":"create"}]',NULL,'---
macros:
  ''\F'': ''first''
---

$\F$ text
','79d8e00656390250b526b51dc6b4999ed42b809483609b7572bed89b3bdbb4a9',0,'{"converted":{},"kept":[]}','[]','{"profile":"ss-markdown-2","blocks":[{"id":"b1","kind":"front_matter","parent":null,"lines":[0,4],"start":0,"end":31,"hash":"1696fec8d4d046330fd902447e84976d206880c1faf1fedeff4f296d04eb7334","status":"added","structural":null,"attrs":{},"spans":[]},{"id":"b2","kind":"paragraph","parent":null,"lines":[5,6],"start":33,"end":42,"hash":"db053261e68ac8c193507965dcac93f757c0afef26da7fee85097f4c6e4b1da1","status":"added","structural":null,"attrs":{},"spans":[{"id":"m1","kind":"inline","hash":"366584274fbf870007b1f943904f3abeb1009ebf1c4e14e09051b64ed44a96d2","status":"added"}]}],"removed":[],"removed_spans":[]}','{"profile":"ss-markdown-2","markdown-it-py":"4.2.0","mdit-py-plugins":"0.6.1"}');
INSERT INTO "revisions" VALUES('doc-6d5d225787c1ec2d34b50b21',2,'2026-10-14T20:31:25.236243+00:00','{"kind":"user","user":"user","session_id":null,"run_id":null,"role":null,"model":null,"alias":null,"tool_call":null,"import_id":null,"service":null,"worker_binding":null,"environment_id":null,"incarnation":null,"execution_id":null,"attempt_id":null}',NULL,NULL,1,1,'FM','[{"op":"save"}]',NULL,'---
macros:
  ''\F'': ''second''
---

$\F\F$ text
','c56f5531026421f165cf043a7ca89a86bc400cf14d99b02b27bb6e804968b49a',0,'{"converted":{},"kept":[]}','[]','{"profile":"ss-markdown-2","blocks":[{"id":"b1","kind":"front_matter","parent":null,"lines":[0,4],"start":0,"end":32,"hash":"3065679b3e0ce9f4984c8c6f95e2625b217fe31db57597615ddc8fc43282aec0","status":"changed","structural":null,"attrs":{},"spans":[]},{"id":"b2","kind":"paragraph","parent":null,"lines":[5,6],"start":34,"end":45,"hash":"e8b655944d7036e32086221eed290fe7047034204da49ba048b1bfa2f43f1cb5","status":"changed","structural":null,"attrs":{},"spans":[{"id":"m1","kind":"inline","hash":"2001d62c5b168382df9dc0f0697432a6d0edfb7b1e6d0c82c2cae1761cea6f28","status":"changed"}]}],"removed":[],"removed_spans":[]}','{"profile":"ss-markdown-2","markdown-it-py":"4.2.0","mdit-py-plugins":"0.6.1"}');
CREATE TABLE run_cancels (
    project_id TEXT NOT NULL,
    session_id TEXT NOT NULL,
    run TEXT NOT NULL CHECK (length(CAST(run AS BLOB)) BETWEEN 1 AND 256),
    requested_at TEXT NOT NULL,
    PRIMARY KEY (project_id, session_id, run),
    FOREIGN KEY (project_id, session_id) REFERENCES sessions (project_id, session_id)
) STRICT;
CREATE TABLE run_events (
    project_id TEXT NOT NULL,
    session_id TEXT NOT NULL,
    run TEXT NOT NULL CHECK (length(CAST(run AS BLOB)) BETWEEN 1 AND 256),
    seq INTEGER NOT NULL CHECK (seq BETWEEN 1 AND 999999999),
    at TEXT NOT NULL,
    kind TEXT NOT NULL CHECK (kind IN
        ('started', 'user', 'model', 'assistant', 'tool', 'notice', 'waiting', 'stopped')),
    data TEXT NOT NULL CHECK (json_valid(data) AND json_type(data) = 'object'
        AND length(CAST(data AS BLOB)) <= 65536),
    PRIMARY KEY (project_id, session_id, run, seq),
    FOREIGN KEY (project_id, session_id) REFERENCES sessions (project_id, session_id)
) STRICT;
CREATE TABLE run_leases (
    project_id TEXT NOT NULL,
    session_id TEXT NOT NULL,
    run TEXT NOT NULL CHECK (length(CAST(run AS BLOB)) BETWEEN 1 AND 256),
    holder TEXT NOT NULL CHECK (length(CAST(holder AS BLOB)) BETWEEN 1 AND 128),
    started_at TEXT NOT NULL,
    renewed_at REAL NOT NULL,
    PRIMARY KEY (project_id, session_id),
    FOREIGN KEY (project_id, session_id) REFERENCES sessions (project_id, session_id)
) STRICT;
CREATE TABLE runs (
    project_id TEXT NOT NULL,
    session_id TEXT NOT NULL,
    name TEXT NOT NULL,
    run_id TEXT NOT NULL,
    started_at TEXT NOT NULL,
    record TEXT NOT NULL,
    PRIMARY KEY (project_id, session_id, name),
    FOREIGN KEY (project_id, session_id) REFERENCES sessions (project_id, session_id)
) STRICT;
CREATE TABLE service_heartbeat (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    holder TEXT NOT NULL CHECK (length(CAST(holder AS BLOB)) BETWEEN 1 AND 128),
    renewed_at REAL NOT NULL
) STRICT;
CREATE TABLE session_messages (
    number INTEGER PRIMARY KEY,
    message_id TEXT NOT NULL UNIQUE CHECK (length(CAST(message_id AS BLOB)) BETWEEN 1 AND 128),
    project_id TEXT NOT NULL,
    session_id TEXT NOT NULL,
    text TEXT NOT NULL CHECK (length(CAST(text AS BLOB)) BETWEEN 1 AND 65536),
    author TEXT NOT NULL CHECK (length(CAST(author AS BLOB)) BETWEEN 1 AND 128),
    created_at TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('queued', 'delivered', 'refused', 'held')),
    run TEXT CHECK (run IS NULL OR length(CAST(run AS BLOB)) BETWEEN 1 AND 256),
    offered TEXT CHECK (offered IS NULL OR length(CAST(offered AS BLOB)) BETWEEN 1 AND 256),
    reason TEXT CHECK (reason IS NULL OR length(CAST(reason AS BLOB)) <= 1024),
    updated_at TEXT NOT NULL,
    CHECK ((state = 'delivered') = (run IS NOT NULL)),
    FOREIGN KEY (project_id, session_id) REFERENCES sessions (project_id, session_id)
) STRICT;
CREATE TABLE "session_plan_projections" (
    project TEXT NOT NULL, session TEXT NOT NULL, kind TEXT NOT NULL, id TEXT NOT NULL,
    record TEXT NOT NULL
        CHECK (json_valid(record) AND length(CAST(record AS BLOB)) <= 81920),
    bytes INTEGER NOT NULL CHECK (bytes = length(CAST(record AS BLOB)) + 512),
    PRIMARY KEY(project,session,kind,id)) STRICT;
CREATE TABLE "session_plan_records" (
    project TEXT NOT NULL, session TEXT NOT NULL, kind TEXT NOT NULL, id TEXT NOT NULL,
    number INTEGER NOT NULL CHECK (number >= 0), key TEXT NOT NULL,
    record TEXT NOT NULL
        CHECK (json_valid(record) AND length(CAST(record AS BLOB)) <= 81920),
    bytes INTEGER NOT NULL CHECK (bytes = length(CAST(record AS BLOB)) + 512),
    PRIMARY KEY(project,session,kind,id,number)) STRICT;
CREATE TABLE sessions (
    project_id TEXT NOT NULL REFERENCES projects (project_id),
    session_id TEXT NOT NULL,
    environment_id TEXT NOT NULL,
    dedicated INTEGER NOT NULL CHECK (dedicated IN (0, 1)),
    opened_at TEXT NOT NULL,
    closed_at TEXT,
    kernel_notice_lifetime TEXT,
    PRIMARY KEY (project_id, session_id)
) STRICT;
INSERT INTO "sessions" VALUES('p','s','p-default-bb3128df104b',0,'2026-10-14T20:31:25.096550Z',NULL,'kns-1e7a134eb931c99fccca6d39');
CREATE UNIQUE INDEX documents_names
    ON documents (project_id, coalesce(session_id, ''), name) WHERE deleted = 0;
CREATE INDEX patches_documents ON patches (document_id, created_at);
CREATE INDEX events_projects ON events (project_id, seq);
CREATE TRIGGER revisions_no_update BEFORE UPDATE ON revisions
BEGIN SELECT RAISE(ABORT, 'revisions are immutable'); END;
CREATE TRIGGER revisions_no_delete BEFORE DELETE ON revisions
BEGIN SELECT RAISE(ABORT, 'revisions are append-only'); END;
CREATE TRIGGER events_no_update BEFORE UPDATE ON events
BEGIN SELECT RAISE(ABORT, 'events are immutable'); END;
CREATE TRIGGER events_no_delete BEFORE DELETE ON events
BEGIN SELECT RAISE(ABORT, 'events are append-only'); END;
CREATE INDEX annotation_pending ON annotation_requests(project_id,session_id,state);
CREATE TRIGGER document_macro_pins_update BEFORE UPDATE ON document_macro_pins
BEGIN SELECT RAISE(ABORT,'macro revisions and pins are immutable'); END;
CREATE TRIGGER document_macro_pins_delete BEFORE DELETE ON document_macro_pins
BEGIN SELECT RAISE(ABORT,'macro revisions and pins are immutable'); END;
CREATE TRIGGER response_macro_revisions_update BEFORE UPDATE ON response_macro_revisions
BEGIN SELECT RAISE(ABORT,'macro revisions and pins are immutable'); END;
CREATE TRIGGER response_macro_revisions_delete BEFORE DELETE ON response_macro_revisions
BEGIN SELECT RAISE(ABORT,'macro revisions and pins are immutable'); END;
CREATE INDEX artifact_revisions_project ON artifact_revisions(project);
CREATE TRIGGER artifact_revisions_no_update BEFORE UPDATE ON artifact_revisions
BEGIN SELECT RAISE(ABORT,'artifacts are immutable'); END;
CREATE TRIGGER artifact_revisions_no_delete BEFORE DELETE ON artifact_revisions
BEGIN SELECT RAISE(ABORT,'artifacts are immutable'); END;
CREATE UNIQUE INDEX review_one_running
    ON review_runs(project,session) WHERE state='running';
CREATE INDEX review_findings_scope ON review_findings(project,session,created);
CREATE TRIGGER review_grants_update BEFORE UPDATE ON review_grants
BEGIN SELECT RAISE(ABORT, 'review evidence/history is immutable'); END;
CREATE TRIGGER review_grants_delete BEFORE DELETE ON review_grants
BEGIN SELECT RAISE(ABORT, 'review evidence/history is immutable'); END;
CREATE TRIGGER review_confirmation_targets_update BEFORE UPDATE ON review_confirmation_targets
BEGIN SELECT RAISE(ABORT, 'review evidence/history is immutable'); END;
CREATE TRIGGER review_confirmation_targets_delete BEFORE DELETE ON review_confirmation_targets
BEGIN SELECT RAISE(ABORT, 'review evidence/history is immutable'); END;
CREATE TRIGGER review_reads_update BEFORE UPDATE ON review_reads
BEGIN SELECT RAISE(ABORT, 'review evidence/history is immutable'); END;
CREATE TRIGGER review_reads_delete BEFORE DELETE ON review_reads
BEGIN SELECT RAISE(ABORT, 'review evidence/history is immutable'); END;
CREATE TRIGGER review_records_update BEFORE UPDATE ON review_records
BEGIN SELECT RAISE(ABORT, 'review evidence/history is immutable'); END;
CREATE TRIGGER review_records_delete BEFORE DELETE ON review_records
BEGIN SELECT RAISE(ABORT, 'review evidence/history is immutable'); END;
CREATE TRIGGER review_transitions_update BEFORE UPDATE ON review_transitions
BEGIN SELECT RAISE(ABORT, 'review evidence/history is immutable'); END;
CREATE TRIGGER review_transitions_delete BEFORE DELETE ON review_transitions
BEGIN SELECT RAISE(ABORT, 'review evidence/history is immutable'); END;
CREATE TRIGGER review_config_update BEFORE UPDATE ON review_config
BEGIN SELECT RAISE(ABORT, 'review evidence/history is immutable'); END;
CREATE TRIGGER review_config_delete BEFORE DELETE ON review_config
BEGIN SELECT RAISE(ABORT, 'review evidence/history is immutable'); END;
CREATE TRIGGER review_events_update BEFORE UPDATE ON review_events
BEGIN SELECT RAISE(ABORT, 'review evidence/history is immutable'); END;
CREATE TRIGGER review_events_delete BEFORE DELETE ON review_events
BEGIN SELECT RAISE(ABORT, 'review evidence/history is immutable'); END;
CREATE TRIGGER review_calls_prompt_immutable BEFORE UPDATE OF prompt_provenance ON review_calls
BEGIN SELECT RAISE(ABORT, 'review prompt input is immutable'); END;
CREATE TRIGGER runs_no_update BEFORE UPDATE ON runs
BEGIN SELECT RAISE(ABORT, 'run records are written once'); END;
CREATE TRIGGER runs_no_delete BEFORE DELETE ON runs
BEGIN SELECT RAISE(ABORT, 'run records are written once'); END;
CREATE TRIGGER annotation_threads_update BEFORE UPDATE ON annotation_threads
BEGIN SELECT RAISE(ABORT, 'annotations are append-only'); END;
CREATE TRIGGER annotation_threads_delete BEFORE DELETE ON annotation_threads
BEGIN SELECT RAISE(ABORT, 'annotations are append-only'); END;
CREATE TRIGGER annotation_entries_update BEFORE UPDATE ON annotation_entries
BEGIN SELECT RAISE(ABORT, 'annotations are append-only'); END;
CREATE TRIGGER annotation_entries_delete BEFORE DELETE ON annotation_entries
BEGIN SELECT RAISE(ABORT, 'annotations are append-only'); END;
CREATE TRIGGER annotation_body_revisions_update BEFORE UPDATE ON annotation_body_revisions
BEGIN SELECT RAISE(ABORT,'body revisions are immutable'); END;
CREATE TRIGGER annotation_body_revisions_delete BEFORE DELETE ON annotation_body_revisions
BEGIN SELECT RAISE(ABORT,'body revisions are immutable'); END;
CREATE TRIGGER review_response_bodies_update BEFORE UPDATE ON review_response_bodies
BEGIN SELECT RAISE(ABORT,'response source and pins are immutable'); END;
CREATE TRIGGER review_response_bodies_delete BEFORE DELETE ON review_response_bodies
BEGIN SELECT RAISE(ABORT,'response source and pins are immutable'); END;
CREATE TRIGGER review_response_pins_update BEFORE UPDATE ON review_response_pins
BEGIN SELECT RAISE(ABORT,'response source and pins are immutable'); END;
CREATE TRIGGER review_response_pins_delete BEFORE DELETE ON review_response_pins
BEGIN SELECT RAISE(ABORT,'response source and pins are immutable'); END;
CREATE INDEX math_revision ON math_jobs(document,revision);
CREATE UNIQUE INDEX math_one_running
    ON math_jobs(document) WHERE state='running';
CREATE INDEX math_observation_span ON math_observations(block,span,check_id);
CREATE TRIGGER math_observations_update BEFORE UPDATE ON math_observations
BEGIN SELECT RAISE(ABORT,'math observations are immutable'); END;
CREATE TRIGGER math_observations_delete BEFORE DELETE ON math_observations
BEGIN SELECT RAISE(ABORT,'math observations are immutable'); END;
CREATE TRIGGER project_macro_revisions_update BEFORE UPDATE ON project_macro_revisions
BEGIN SELECT RAISE(ABORT,'macro revisions and pins are immutable'); END;
CREATE TRIGGER project_macro_revisions_delete BEFORE DELETE ON project_macro_revisions
BEGIN SELECT RAISE(ABORT,'macro revisions and pins are immutable'); END;
CREATE TRIGGER math_macro_pins_update BEFORE UPDATE ON math_macro_pins
BEGIN SELECT RAISE(ABORT,'macro revisions and pins are immutable'); END;
CREATE TRIGGER math_macro_pins_delete BEFORE DELETE ON math_macro_pins
BEGIN SELECT RAISE(ABORT,'macro revisions and pins are immutable'); END;
CREATE TRIGGER response_macro_anchors_update BEFORE UPDATE ON response_macro_anchors
BEGIN SELECT RAISE(ABORT,'macro revisions and pins are immutable'); END;
CREATE TRIGGER response_macro_anchors_delete BEFORE DELETE ON response_macro_anchors
BEGIN SELECT RAISE(ABORT,'macro revisions and pins are immutable'); END;
CREATE TRIGGER math_macro_contexts_update BEFORE UPDATE ON math_macro_contexts
BEGIN SELECT RAISE(ABORT,'macro revisions and pins are immutable'); END;
CREATE TRIGGER math_macro_contexts_delete BEFORE DELETE ON math_macro_contexts
BEGIN SELECT RAISE(ABORT,'macro revisions and pins are immutable'); END;
CREATE TRIGGER review_macro_pins_update BEFORE UPDATE ON review_macro_pins
BEGIN SELECT RAISE(ABORT,'macro revisions and pins are immutable'); END;
CREATE TRIGGER review_macro_pins_delete BEFORE DELETE ON review_macro_pins
BEGIN SELECT RAISE(ABORT,'macro revisions and pins are immutable'); END;
CREATE INDEX artifact_events_project ON artifact_events(project,seq);
CREATE TRIGGER artifact_events_no_update BEFORE UPDATE ON artifact_events
BEGIN SELECT RAISE(ABORT,'artifacts are immutable'); END;
CREATE TRIGGER artifact_events_no_delete BEFORE DELETE ON artifact_events
BEGIN SELECT RAISE(ABORT,'artifacts are immutable'); END;
CREATE INDEX review_feed_scope ON review_feed(project,session,seq);
CREATE TRIGGER review_feed_update BEFORE UPDATE ON review_feed
BEGIN SELECT RAISE(ABORT, 'review evidence/history is immutable'); END;
CREATE TRIGGER review_feed_delete BEFORE DELETE ON review_feed
BEGIN SELECT RAISE(ABORT, 'review evidence/history is immutable'); END;
CREATE TRIGGER review_evidence_update BEFORE UPDATE ON review_evidence
BEGIN SELECT RAISE(ABORT, 'review evidence/history is immutable'); END;
CREATE TRIGGER review_evidence_delete BEFORE DELETE ON review_evidence
BEGIN SELECT RAISE(ABORT, 'review evidence/history is immutable'); END;
CREATE INDEX session_plan_keys ON session_plan_records(project,session,kind,id,key,number);
CREATE TRIGGER session_plan_records_no_update BEFORE UPDATE ON session_plan_records
BEGIN SELECT RAISE(ABORT,'session-plan history is immutable'); END;
CREATE TRIGGER session_plan_records_no_delete BEFORE DELETE ON session_plan_records
BEGIN SELECT RAISE(ABORT,'session-plan history is immutable'); END;
CREATE VIEW math_job_scope AS
    SELECT j.check_id,s.project,NULL AS session FROM math_jobs j
    JOIN math_sources s USING(document)
    UNION ALL SELECT j.check_id,f.project,f.session FROM math_jobs j JOIN math_response_jobs r
    USING(check_id) JOIN response_math_sources s ON s.source=r.source JOIN review_findings f
    ON f.finding_id=s.finding_id WHERE j.document IS NULL AND s.project=f.project
    AND s.session=f.session;
CREATE VIEW math_current_checks AS
    SELECT j.check_id,j.document AS source,j.revision FROM math_jobs j
    JOIN documents d ON d.document_id=j.document
    WHERE NOT EXISTS(SELECT 1 FROM math_comment_jobs c WHERE c.check_id=j.check_id)
    AND d.head=j.revision AND j.rowid=(SELECT max(k.rowid) FROM math_jobs k
    WHERE k.document=j.document AND k.revision=d.head AND NOT EXISTS
    (SELECT 1 FROM math_comment_jobs c WHERE c.check_id=k.check_id))
    UNION ALL
    SELECT j.check_id,'comment:'||c.entry_id,j.revision FROM math_jobs j
    JOIN math_comment_jobs c USING(check_id) JOIN documents d ON d.document_id=j.document
    JOIN comment_math_sources s ON s.entry_id=c.entry_id
    JOIN annotation_body_revisions b ON b.entry_id=c.entry_id AND b.revision=j.revision
    JOIN annotation_entries original ON original.entry_id=c.entry_id
    JOIN annotation_threads t ON t.thread_id=original.thread_id
    WHERE t.document_id=j.document AND s.document=j.document AND s.project=d.project_id
    AND original.kind IN ('create','reply')
    AND s.target=j.revision AND d.head=c.macro_revision AND b.history_entry=(
      SELECT e.entry_id FROM annotation_entries e WHERE e.thread_id=original.thread_id
      AND (e.entry_id=original.entry_id OR (e.kind='edit' AND original.number=1)
      OR (e.kind='edit_body' AND json_extract(e.payload,'$.entry')=original.entry_id))
      ORDER BY e.number DESC LIMIT 1)
    AND j.rowid=(SELECT max(k.rowid) FROM math_jobs k JOIN math_comment_jobs x
    USING(check_id) WHERE x.entry_id=c.entry_id AND k.revision=j.revision
    AND x.macro_revision=c.macro_revision) UNION ALL
    SELECT j.check_id,r.source,j.revision FROM math_jobs j JOIN math_response_jobs r
    USING(check_id) JOIN response_math_sources s ON s.source=r.source
    JOIN review_findings f ON f.finding_id=s.finding_id
    JOIN review_response_bodies b ON b.source=s.source AND b.revision=j.revision
    WHERE j.document IS NULL AND f.origin='review' AND s.project=f.project AND s.session=f.session
    AND b.finding_id=s.finding_id AND b.decision_revision=s.decision_revision
    AND s.target=j.revision AND j.source_sha256=b.sha256
    AND j.rowid=(SELECT max(k.rowid) FROM math_jobs k JOIN math_response_jobs x USING(check_id)
                WHERE x.source=r.source AND k.revision=j.revision);
CREATE TRIGGER artifact_revisions_check BEFORE INSERT ON artifact_revisions WHEN NOT (NEW.number >= 1 AND json_valid(NEW.record) AND length(CAST(NEW.record AS BLOB)) <= 16384) BEGIN SELECT RAISE(ABORT, 'CHECK constraint failed: artifact_revisions'); END;
CREATE INDEX session_messages_by_state ON session_messages (project_id, session_id, state, number);
CREATE TRIGGER session_messages_kept BEFORE DELETE ON session_messages
BEGIN SELECT RAISE(ABORT, 'messages are kept'); END;
CREATE TRIGGER run_events_no_update BEFORE UPDATE ON run_events
BEGIN SELECT RAISE(ABORT, 'run events are written once'); END;
CREATE TRIGGER run_events_no_delete BEFORE DELETE ON run_events
BEGIN SELECT RAISE(ABORT, 'run events are written once'); END;
CREATE INDEX run_events_by_kind ON run_events (project_id, kind, run);
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('artifact_events',0);
INSERT INTO "sqlite_sequence" VALUES('review_feed',11);
INSERT INTO "sqlite_sequence" VALUES('events',20);
INSERT INTO "sqlite_sequence" VALUES('review_transitions',28);
INSERT INTO "sqlite_sequence" VALUES('review_events',38);
INSERT INTO "sqlite_sequence" VALUES('review_records',5);
INSERT INTO "sqlite_sequence" VALUES('review_reads',22);
COMMIT;
